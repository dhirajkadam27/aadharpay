import 'package:aadharpayv3/screens/name.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';

class PrivacyPolicy extends StatefulWidget {
  const PrivacyPolicy({super.key});

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy> {
  final user = Hive.box('User');
  bool lang = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(top: 30, bottom: 50),
            child: SvgPicture.asset(
              'assets/logo.svg',
              width: 220,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: Text(
              lang ? "प्राइवेसी पॉलिसी" : "Privacy Policy",
              style: TextStyle(
                  fontFamily: lang ? 'MExtraBold' : 'ExtraBold',
                  color: Colors.white,
                  fontSize: 25),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 15,
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: Text(
              lang
                  ? "सभी गोपनीयता नीति पढ़ें और नियम और शर्तों को स्वीकार करें"
                  : "Read all the privacy policy and accept the terms and conditions",
              style: TextStyle(
                  fontFamily: lang ? 'MMedium' : 'Medium',
                  color: const Color(0xffC0C0C0),
                  fontSize: 15),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: InkWell(
              onTap: () {
                FirebaseAuth.instance
                    .authStateChanges()
                    .listen((User? user) async {
                  if (user == null) {
                    print('User is currently signed out!');
                  } else {
                    await GoogleSignIn().disconnect();
                    FirebaseAuth.instance.signOut();
                  }
                });
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => const Name()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: const Color(0xff00CE19),
                    borderRadius: BorderRadius.circular(5)),
                child: Text(
                  lang ? "कंटीन्यू" : "Contiune",
                  style: TextStyle(
                      fontFamily: lang ? 'MExtraBold' : 'ExtraBold',
                      color: const Color(0xff1F222A),
                      fontSize: 18),
                ),
              ),
            ),
          )
        ],
      )),
    );
  }
}
