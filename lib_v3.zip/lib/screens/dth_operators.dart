import 'package:aadharpayv3/screens/prepaid.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

class DthOperators extends StatefulWidget {
  const DthOperators({super.key});

  @override
  State<DthOperators> createState() => _DthOperatorsState();
}

class _DthOperatorsState extends State<DthOperators> {
  TextEditingController numController = TextEditingController();
  List<Contact> contacts = [];
  List<Contact> contactscheck = [];
  List<Contact> contactsFilter = [];
  final user = Hive.box('User');
  bool lang = false;
  @override
  void initState() {
    super.initState();
    sync();
    getContact();
  }

  void getContact() async {
    if (await FlutterContacts.requestPermission()) {
      contacts = await FlutterContacts.getContacts(
          withProperties: true, withPhoto: true);
      print(contacts);
      contactsFilter = contacts;
      setState(() {});
    }
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    void filterSearchResults(String query) {
      contactscheck.clear();
      for (var item in contacts) {
        if (item.phones.first.number
            .toString()
            .replaceAll(" ", "")
            .contains(query.toString())) {
          setState(() {
            contactscheck.add(item);
          });
        }
        setState(() {
          contactsFilter = contactscheck;
        });
      }

      return;
    }

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.20,
                  alignment: Alignment.center,
                  child: Row(children: [
                    const Icon(
                      Icons.keyboard_arrow_left,
                      size: 35,
                      color: Color(0xff497CFF),
                    ),
                    Text(
                      lang ? "पीछे" : "back",
                      style: TextStyle(
                          fontSize: 15,
                          color: const Color(0xff497CFF),
                          fontFamily: lang ? 'MBold' : 'Bold'),
                    ),
                  ]),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.20,
                alignment: Alignment.center,
                child: Text(
                  lang ? "मोबाइल" : "TV",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontFamily: lang ? 'MBold' : 'Bold'),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.20,
                alignment: Alignment.center,
              )
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Container(
            margin: const EdgeInsets.only(top: 2),
            padding:
                const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
            color: const Color(0xff262C3A),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.network(
                          "https://dmx246cm6p7k8.cloudfront.net/content/images/circular-operator-logos/bills/AIRT00000NAT87.webp",
                          width: 40,
                          height: 40,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Airtel Digital Tv",
                          style: TextStyle(
                              fontFamily: 'Bold',
                              color: Colors.white,
                              fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ]),
          ),
          Container(
            margin: const EdgeInsets.only(top: 2),
            padding:
                const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
            color: const Color(0xff262C3A),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.network(
                          "https://dmx246cm6p7k8.cloudfront.net/content/images/circular-operator-logos/bills/VIDEOCON0NAT01.webp",
                          width: 40,
                          height: 40,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Videocon D2h",
                          style: TextStyle(
                              fontFamily: 'Bold',
                              color: Colors.white,
                              fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ]),
          ),
          Container(
            margin: const EdgeInsets.only(top: 2),
            padding:
                const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
            color: const Color(0xff262C3A),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.network(
                          "https://dmx246cm6p7k8.cloudfront.net/content/images/circular-operator-logos/bills/DISH00000NAT01.webp",
                          width: 40,
                          height: 40,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Dish Tv",
                          style: TextStyle(
                              fontFamily: 'Bold',
                              color: Colors.white,
                              fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ]),
          ),
          Container(
            margin: const EdgeInsets.only(top: 2),
            padding:
                const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
            color: const Color(0xff262C3A),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.network(
                          "https://dmx246cm6p7k8.cloudfront.net/content/images/circular-operator-logos/bills/SUND00000NAT02.webp",
                          width: 40,
                          height: 40,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Sun Direct",
                          style: TextStyle(
                              fontFamily: 'Bold',
                              color: Colors.white,
                              fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ]),
          ),
          Container(
            margin: const EdgeInsets.only(top: 2),
            padding:
                const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
            color: const Color(0xff262C3A),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.network(
                          "https://dmx246cm6p7k8.cloudfront.net/content/images/circular-operator-logos/bills/tata-play.webp",
                          width: 40,
                          height: 40,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Tata Play",
                          style: TextStyle(
                              fontFamily: 'Bold',
                              color: Colors.white,
                              fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ]),
          ),
        ],
      )),
    );
  }
}
