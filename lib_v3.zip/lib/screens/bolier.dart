import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';

class Bolier extends StatefulWidget {
  const Bolier({super.key});

  @override
  State<Bolier> createState() => _BolierState();
}

class _BolierState extends State<Bolier> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return const Scaffold(
      backgroundColor: Color(0xff181A20),
    );
  }
}
