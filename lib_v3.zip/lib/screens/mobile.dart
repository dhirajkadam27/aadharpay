import 'dart:convert';
import 'dart:io';

import 'package:aadharpayv3/screens/prepaid.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:http/http.dart' as http;

class Mobile extends StatefulWidget {
  const Mobile({super.key});

  @override
  State<Mobile> createState() => _MobileState();
}

class _MobileState extends State<Mobile> {
  TextEditingController numController = TextEditingController();
  List<Contact> contacts = [];
  List<Contact> contactscheck = [];
  List<Contact> contactsFilter = [];
  final user = Hive.box('User');
  bool loader = false;
  bool lang = false;
  @override
  void initState() {
    super.initState();
    sync();
    getContact();
  }

  void getContact() async {
    if (await FlutterContacts.requestPermission()) {
      contacts = await FlutterContacts.getContacts(
          withProperties: true, withPhoto: true);
      print(contacts);
      contactsFilter = contacts;
      setState(() {});
    }
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    void filterSearchResults(String query) {
      contactscheck.clear();
      for (var item in contacts) {
        if (item.phones.first.number
            .toString()
            .replaceAll(" ", "")
            .contains(query.toString())) {
          setState(() {
            contactscheck.add(item);
          });
        }
        setState(() {
          contactsFilter = contactscheck;
        });
      }

      return;
    }

    Future fetchOperator(num) async {
      try {
        final fetch = await http.get(Uri.parse(
            'https://mydukanpe.com/aadharpay/api/v4/mobile_operator.php?num=' +
                num));

        if (fetch.statusCode == 200) {
          List response = json.decode(fetch.body);
          if (response[0]['opr'] == "UNKNOWN") {
            setState(() {
              loader = false;
            });
            showoperators(context, num);
          } else {
            setState(() {
              loader = false;
            });
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => Prepaid(
                      opr: response[0]['opr'],
                      img: response[0]['img'],
                      region: response[0]['region'],
                      name: response[0]['name'],
                      num: num,
                    )));
          }
        } else {
          setState(() {
            loader = false;
          });
          showerror(context, "Something went wrong");
        }
      } on SocketException catch (_) {
        setState(() {
          loader = false;
        });
        showerror(context, "Internet is not connected");
      }
    }

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      alignment: Alignment.center,
                      child: Row(children: [
                        const Icon(
                          Icons.keyboard_arrow_left,
                          size: 35,
                          color: Color(0xff497CFF),
                        ),
                        Text(
                          lang ? "पीछे" : "back",
                          style: TextStyle(
                              fontSize: 15,
                              color: const Color(0xff497CFF),
                              fontFamily: lang ? 'MBold' : 'Bold'),
                        ),
                      ]),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.20,
                    alignment: Alignment.center,
                    child: Text(
                      lang ? "मोबाइल" : "Mobile",
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.white,
                          fontFamily: lang ? 'MBold' : 'Bold'),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.20,
                    alignment: Alignment.center,
                  )
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      height: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0xff262C3A)),
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      alignment: Alignment.center,
                      child: const Text(
                        "+91",
                        style: TextStyle(
                            fontSize: 17,
                            color: Colors.white,
                            fontFamily: 'Bold'),
                      )),
                  const SizedBox(
                    width: 20,
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width * 0.50,
                      height: 50,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0xff262C3A)),
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: TextField(
                        onChanged: ((value) {
                          filterSearchResults(value);
                        }),
                        keyboardType: TextInputType.number,
                        controller: numController,
                        style: const TextStyle(
                            fontSize: 17,
                            color: Colors.white,
                            fontFamily: 'Bold'),
                        decoration: const InputDecoration(
                            hintStyle: TextStyle(
                                fontSize: 17,
                                color: Colors.white,
                                fontFamily: 'Bold'),
                            border: InputBorder.none,
                            hintText: '00000 00000',
                            fillColor: Colors.white),
                      )),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              Expanded(
                child: (contactsFilter) == null
                    ? const Text("")
                    : (contactsFilter.isEmpty)
                        ? ListTile(
                            leading: const CircleAvatar(
                                backgroundColor: Color(0xff497CFF),
                                child: Icon(
                                  Icons.person,
                                  color: Colors.white,
                                )),
                            title: const Text(
                              "New Number",
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.white,
                                  fontFamily: 'Bold'),
                            ),
                            subtitle: Text(
                              numController.text,
                              style: const TextStyle(
                                  fontSize: 13,
                                  color: Color(0xffC0C0C0),
                                  fontFamily: 'Bold'),
                            ),
                            onTap: () {
                              if (numController.text.length > 9) {
                                setState(() {
                                  loader = true;
                                });
                                fetchOperator(numController.text);
                              }
                            })
                        : ListView.builder(
                            itemCount: contactsFilter.length,
                            itemBuilder: (BuildContext context, int index) {
                              Uint8List? image = contactsFilter[index].photo;
                              String num = (contactsFilter[index]
                                      .phones
                                      .isNotEmpty)
                                  ? (contactsFilter[index].phones.first.number)
                                  : "--";
                              return ListTile(
                                  leading: (contactsFilter[index].photo == null)
                                      ? const CircleAvatar(
                                          child: Icon(Icons.person))
                                      : CircleAvatar(
                                          backgroundImage: MemoryImage(image!)),
                                  title: Text(
                                    "${contactsFilter[index].name.first} ${contactsFilter[index].name.last}",
                                    style: const TextStyle(
                                        fontSize: 13,
                                        color: Colors.white,
                                        fontFamily: 'Bold'),
                                  ),
                                  subtitle: Text(
                                    num,
                                    style: const TextStyle(
                                        fontSize: 13,
                                        color: Color(0xffC0C0C0),
                                        fontFamily: 'Bold'),
                                  ),
                                  onTap: () {
                                    if (contactsFilter[index]
                                        .phones
                                        .isNotEmpty) {
                                      setState(() {
                                        loader = true;
                                      });
                                      print(num.replaceAll(" ", ""));
                                      fetchOperator(num.replaceAll(" ", ""));
                                    }
                                  });
                            },
                          ),
              )
            ],
          ),
          loader
              ? Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0xff181A20).withOpacity(0.3),
                  child: const Center(
                      child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Color(0xff497CFF),
                    ),
                  )),
                )
              : const Text(""),
        ],
      )),
    );
  }

  showoperators(context, num) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return Material(
              color: Colors.white.withOpacity(0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0x4d0097A7),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) => Prepaid(
                                  opr: '650',
                                  img:
                                      'https://s3-ap-southeast-1.amazonaws.com/bsy/iportal/images/airtel-logo-white-text-vertical.jpg',
                                  region: '14',
                                  name: "Airtel Prepaid",
                                  num: num,
                                )));
                      },
                      child: Container(
                        padding: const EdgeInsets.only(
                            left: 15, right: 15, top: 10, bottom: 10),
                        color: const Color(0xff181A20),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(100),
                                    child: Image.network(
                                      "https://s3-ap-southeast-1.amazonaws.com/bsy/iportal/images/airtel-logo-white-text-vertical.jpg",
                                      width: 40,
                                      height: 40,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(
                                      "Airtel Prepaid",
                                      style: TextStyle(
                                          fontFamily: 'Bold',
                                          color: Colors.white,
                                          fontSize: 13),
                                    ),
                                  ),
                                ],
                              ),
                            ]),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) => Prepaid(
                                  opr: '652',
                                  img:
                                      "https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Reliance_Jio_Logo_%28October_2015%29.svg/640px-Reliance_Jio_Logo_%28October_2015%29.svg.png",
                                  region: '13',
                                  name: "Jio Prepaid",
                                  num: num,
                                )));
                      },
                      child: Container(
                        padding: const EdgeInsets.only(
                            left: 15, right: 15, top: 10, bottom: 10),
                        color: const Color(0xff181A20),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(100),
                                    child: Image.network(
                                      "https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Reliance_Jio_Logo_%28October_2015%29.svg/640px-Reliance_Jio_Logo_%28October_2015%29.svg.png",
                                      width: 40,
                                      height: 40,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(
                                      "Jio Prepaid",
                                      style: TextStyle(
                                          fontFamily: 'Bold',
                                          color: Colors.white,
                                          fontSize: 13),
                                    ),
                                  ),
                                ],
                              ),
                            ]),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) => Prepaid(
                                  opr: '653',
                                  img:
                                      "https://images.news18.com/ibnlive/uploads/2021/05/1621421812_vi_logo.jpg?im=FitAndFill,width=1200,height=1200",
                                  region: '8',
                                  name: "Vi Prepaid",
                                  num: num,
                                )));
                      },
                      child: Container(
                        padding: const EdgeInsets.only(
                            left: 15, right: 15, top: 10, bottom: 10),
                        color: const Color(0xff181A20),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(100),
                                    child: Image.network(
                                      "https://images.news18.com/ibnlive/uploads/2021/05/1621421812_vi_logo.jpg?im=FitAndFill,width=1200,height=1200",
                                      width: 40,
                                      height: 40,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(
                                      "VI Prepaid",
                                      style: TextStyle(
                                          fontFamily: 'Bold',
                                          color: Colors.white,
                                          fontSize: 13),
                                    ),
                                  ),
                                ],
                              ),
                            ]),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) => Prepaid(
                                  opr: '651',
                                  img:
                                      "https://4.bp.blogspot.com/-aEu_Y9121Aw/TkKgwHoKsEI/AAAAAAAAANo/8C5E6ZmCQhk/s1600/bsnl-logo.jpg",
                                  region: '14',
                                  name: "BSNL",
                                  num: num,
                                )));
                      },
                      child: Container(
                        padding: const EdgeInsets.only(
                            left: 15, right: 15, top: 10, bottom: 10),
                        color: const Color(0xff181A20),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(100),
                                    child: Image.network(
                                      "https://4.bp.blogspot.com/-aEu_Y9121Aw/TkKgwHoKsEI/AAAAAAAAANo/8C5E6ZmCQhk/s1600/bsnl-logo.jpg",
                                      width: 40,
                                      height: 40,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Text(
                                      "BSNL Prepaid",
                                      style: TextStyle(
                                          fontFamily: 'Bold',
                                          color: Colors.white,
                                          fontSize: 13),
                                    ),
                                  ),
                                ],
                              ),
                            ]),
                      ),
                    ),
                  ],
                ),
              ));
        });
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
