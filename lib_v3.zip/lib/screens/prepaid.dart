import 'dart:convert';
import 'dart:io';

import 'package:aadharpayv3/screens/prepaid_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';

class Prepaid extends StatefulWidget {
  String opr;
  String region;
  String num;
  String img;
  String name;
  Prepaid(
      {super.key,
      required this.opr,
      required this.region,
      required this.img,
      required this.name,
      required this.num});

  @override
  State<Prepaid> createState() => _PrepaidState();
}

class _PrepaidState extends State<Prepaid> {
  List response = [];
  bool loader = true;
  final user = Hive.box('User');
  bool lang = false;

  Future fetchPlans() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v4/prepaid_plans.php?opr=${widget.opr}&region=${widget.region}&num=${widget.num}'));

      if (fetch.statusCode == 200) {
        response = json.decode(fetch.body);
        if (response.isEmpty) {
          showerror(context, "Invaild mobile number");
        }
        setState(() {
          loader = false;
        });
        return response;
      } else {
        setState(() {
          loader = false;
        });
        showerror(context, "Something went wrong");
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
      });
      showerror(context, "Internet is not connected");
    }
  }

  @override
  void initState() {
    super.initState();
    sync();
    fetchPlans();
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return DefaultTabController(
      length: response.length,
      child: Scaffold(
        backgroundColor: const Color(0xff181A20),
        body: SafeArea(
            child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.20,
                        alignment: Alignment.center,
                        child: Row(children: [
                          const Icon(
                            Icons.keyboard_arrow_left,
                            size: 35,
                            color: Color(0xff497CFF),
                          ),
                          Text(
                            lang ? "पीछे" : "back",
                            style: TextStyle(
                                fontSize: 15,
                                color: const Color(0xff497CFF),
                                fontFamily: lang ? 'MBold' : 'Bold'),
                          ),
                        ]),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      alignment: Alignment.center,
                      child: Text(
                        lang ? "मोबाइल" : "Mobile",
                        style: TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                            fontFamily: lang ? 'MBold' : 'Bold'),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      alignment: Alignment.center,
                    )
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.05,
                    ),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(100),
                      child: Image.network(
                        widget.img,
                        width: 50,
                        height: 50,
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.name,
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontFamily: 'Bold'),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "${widget.num}",
                          style: TextStyle(
                              fontSize: 15,
                              color: Color(0xffC0C0C0),
                              fontFamily: 'SemiBold'),
                        )
                      ],
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                response.isNotEmpty
                    ? Container(
                        margin: const EdgeInsets.only(top: 20),
                        width: MediaQuery.of(context).size.width,
                        child: TabBar(
                            indicatorWeight: 4,
                            indicatorColor: const Color(0xff00CE19),
                            isScrollable: true,
                            tabs: <Widget>[
                              for (var i = 0; i < response.length; i++) ...[
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 15, bottom: 15),
                                  child: Text(
                                    response[i]['type'],
                                    style: const TextStyle(
                                        fontSize: 15,
                                        color: Colors.white,
                                        fontFamily: 'Bold'),
                                  ),
                                )
                              ]
                            ]),
                      )
                    : const Text(""),
                response.isNotEmpty
                    ? Expanded(
                        child: TabBarView(children: [
                        for (var i = 0; i < response.length; i++) ...[
                          ListView(
                            children: [
                              for (var j = 0;
                                  j < response[i]['data'].length;
                                  j++) ...[
                                InkWell(
                                  onTap: () {
                                    Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => PrepaidView(
                                            val:
                                                response[i]['data'][j]['Validity'] != null
                                                    ? response[i]['data'][j]
                                                        ['Validity']
                                                    : '',
                                            decs: utf8.decode(base64.decode(
                                                response[i]['data'][j]
                                                    ['decs'])),
                                            data: response[i]['data'][j]['Data'] != null
                                                ? response[i]['data'][j]['Data']
                                                : '',
                                            dis: 2,
                                            rs: response[i]['data'][j]['rs'],
                                            name: widget.name,
                                            img: widget.img,
                                            num: widget.num)));
                                  
                                  },
                                  child: Container(
                                    decoration: const BoxDecoration(
                                        color: Color(0xff262C3A),
                                        border: Border(
                                            bottom: BorderSide(
                                          width: 1,
                                          color: Color(0xff121212),
                                        ))),
                                    padding: const EdgeInsets.only(
                                        top: 5, bottom: 10),
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.75,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              response[i]['data'][j]
                                                          ['Validity'] !=
                                                      null
                                                  ? Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        response[i]['data'][j]
                                                            ['Validity'],
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    185,
                                                                    185,
                                                                    185)),
                                                      ),
                                                    )
                                                  : const Text(""),
                                              response[i]['data'][j]['Data'] !=
                                                      null
                                                  ? Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        response[i]['data'][j]
                                                            ['Data'],
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    185,
                                                                    185,
                                                                    185)),
                                                      ),
                                                    )
                                                  : const Text(""),
                                              utf8.decode(base64.decode(
                                                          response[i]['data'][j]
                                                              ['decs'])) !=
                                                      null
                                                  ? Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        utf8.decode(base64
                                                            .decode(response[i]
                                                                    ['data'][j]
                                                                ['decs'])),
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    185,
                                                                    185,
                                                                    185)),
                                                      ))
                                                  : const Text(""),
                                              TextButton(
                                                  onPressed: () {},
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Colors.black,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 12, top: 5),
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 6,
                                                            bottom: 6,
                                                            left: 10,
                                                            right: 10),
                                                    child: const Text(
                                                      "Show More",
                                                      style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.white),
                                                    ),
                                                  ))
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.25,
                                          height: 100,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              response[i]['data'][j]['rs'] !=
                                                      null
                                                  ? Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              bottom: 3),
                                                      child: Text(
                                                        "₹${response[i]['data'][j]['rs']}",
                                                        style: const TextStyle(
                                                            fontSize: 18,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            decoration:
                                                                TextDecoration
                                                                    .lineThrough,
                                                            decorationColor:
                                                                Color(
                                                                    0xff00CE19),
                                                            decorationThickness:
                                                                3),
                                                      ),
                                                    )
                                                  : const Text(""),
                                              Text(
                                                "₹${(response[i]['data'][j]['rs'] - response[i]['data'][j]['rs'] * 2 / 100).toStringAsFixed(2)}",
                                                style: const TextStyle(
                                                  fontSize: 18,
                                                  color: Color(0xff00CE19),
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.25,
                                                margin: const EdgeInsets.only(
                                                    top: 3),
                                                child: ClipPath(
                                                  clipper: discountClip(),
                                                  child: Container(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 6,
                                                            bottom: 6,
                                                            left: 15,
                                                            right: 5),
                                                    color:
                                                        const Color(0xff00CE19),
                                                    child: Text(
                                                      "₹${(response[i]['data'][j]['rs'] * 2 / 100).toStringAsFixed(2)} OFF",
                                                      style: const TextStyle(
                                                        fontSize: 10,
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ]
                            ],
                          ),
                        ]
                      ]))
                    : const Text(""),
              ],
            ),
            loader
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: const Color(0xff181A20).withOpacity(0.3),
                    child: const Center(
                        child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xff497CFF),
                      ),
                    )),
                  )
                : const Text(""),
          ],
        )),
      ),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    setState(() {
                                      loader = true;
                                    });
                                    fetchPlans();
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}

class discountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}
