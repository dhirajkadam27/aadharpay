import 'package:aadharpayv3/screens/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';

class Response extends StatefulWidget {
  String num;
  double amu;
  String status;
  String type;
  String date;
  String time;
  String tranid;
  Response(
      {super.key,
      required this.num,
      required this.amu,
      required this.status,
      required this.type,
      required this.date,
      required this.time,
      required this.tranid});

  @override
  State<Response> createState() => _ResponseState();
}

class _ResponseState extends State<Response> {
  TextEditingController nameController = TextEditingController();
  final user = Hive.box('User');
  bool lang = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: widget.status == "PENDING"
            ? Color.fromARGB(255, 210, 143, 0)
            : widget.status == "FAILED"
                ? Color.fromARGB(255, 255, 63, 63)
                : const Color(0xff00BF63),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 140,
            color: widget.status == "PENDING"
                ? Color.fromARGB(255, 210, 143, 0)
                : widget.status == "FAILED"
                    ? Color.fromARGB(255, 255, 63, 63)
                    : const Color(0xff00BF63),
            child: Row(
              children: [
                const SizedBox(
                  width: 20,
                ),
                SizedBox(
                  width: 100,
                  height: 100,
                  child: Stack(children: [
                    Center(
                      child: Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white.withOpacity(0.3)),
                      ),
                    ),
                    Center(
                      child: Container(
                        width: 75,
                        height: 75,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white.withOpacity(0.6)),
                      ),
                    ),
                    Center(
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white.withOpacity(1)),
                        child: widget.status == "PENDING"
                            ? const Center(
                                child: Text(
                                  "?",
                                  style: TextStyle(
                                      fontSize: 25,
                                      color: Color.fromARGB(255, 210, 143, 0),
                                      fontFamily: 'Bold'),
                                ),
                              )
                            : widget.status == "FAILED"
                                ? const Center(
                                    child: Text(
                                      "X",
                                      style: TextStyle(
                                          fontSize: 25,
                                          color:
                                              Color.fromARGB(255, 255, 63, 63),
                                          fontFamily: 'Bold'),
                                    ),
                                  )
                                : const Icon(Icons.done_rounded,
                                    size: 40, color: Color(0xff00BF63)),
                      ),
                    )
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${widget.status}",
                          style: const TextStyle(
                              fontFamily: 'Bold',
                              fontSize: 25,
                              color: Colors.white),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        SizedBox(
                          width: 200,
                          child: Text(
                            "Transaction ${widget.status}",
                            style: const TextStyle(
                                fontFamily: 'SemiBold',
                                fontSize: 10,
                                color: Colors.white),
                          ),
                        )
                      ]),
                )
              ],
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          Padding(
            padding:
                EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.05),
            child: Column(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.90,
                  child: Text(
                    "${widget.type} Recharge",
                    style: const TextStyle(
                      fontFamily: 'Bold',
                      fontSize: 15,
                      color: Colors.white,
                    ),
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.90,
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: const Color(0xff121212),
                        width: 1.0,
                      ),
                    ),
                  ),
                  child: Text(
                    "${widget.num}",
                    style: TextStyle(
                      fontFamily: 'SemiBold',
                      fontSize: 20,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.40,
                    child: Text(
                      "Transaction ID",
                      style: TextStyle(
                        fontFamily: 'Bold',
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: const Color(0xff121212),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Text(
                      "${widget.tranid}",
                      style: TextStyle(
                        fontFamily: 'SemiBold',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.40,
                    child: Text(
                      "Amount",
                      style: TextStyle(
                        fontFamily: 'Bold',
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: const Color(0xff121212),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Text(
                      "${widget.amu}",
                      style: TextStyle(
                        fontFamily: 'SemiBold',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.40,
                    child: Text(
                      "Date",
                      style: TextStyle(
                        fontFamily: 'Bold',
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: const Color(0xff121212),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Text(
                      "${widget.date}",
                      style: TextStyle(
                        fontFamily: 'SemiBold',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.40,
                    child: Text(
                      "Time",
                      style: TextStyle(
                        fontFamily: 'Bold',
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.40,
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: const Color(0xff121212),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Text(
                      "${widget.time}",
                      style: TextStyle(
                        fontFamily: 'SemiBold',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
          const SizedBox(
            height: 30,
          ),
        ],
      )),
    );
  }
}
