import 'dart:convert';
import 'dart:io';

import 'package:aadharpayv3/screens/home.dart';
import 'package:aadharpayv3/screens/upi.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';

class Name extends StatefulWidget {
  const Name({super.key});

  @override
  State<Name> createState() => _NameState();
}

class _NameState extends State<Name> {
  TextEditingController nameController = TextEditingController();
  final user = Hive.box('User');
  bool lang = false;
  bool google_sign_completed = false;
  String email = "";
  String photo = "";
  bool loader = true;
  @override
  void initState() {
    super.initState();
    googleLogin();
    sync();
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  Future billFetch() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v4/sign.php?name=${nameController.text}&email=${email}'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          setState(() {
            loader = false;
            nameController.text = "";
          });
          user.put("user1", "Y");
          user.put("user_id1", reponse['id']);
          user.put("user_name1", reponse['name']);
          user.put("user_email1", email);
          user.put("user_photo1", photo);

          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => const UpiApps()));
        } else if (reponse['success'] == "F") {
          setState(() {
            loader = false;
            nameController.text = "";
          });
          showerror(context, reponse['msg']);
        } else if (reponse['success'] == "N") {
          setState(() {
            loader = false;
            nameController.text = "";
          });
          showerror(context, reponse['msg']);
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        setState(() {
          loader = false;
          nameController.text = "";
        });
        showerror(context, "Something went wrong");
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
        nameController.text = "";
      });
      showerror(context, "Interner is not Connected");
    }
  }

  googleLogin() async {
    print("googleLogin method Called");
    GoogleSignIn _googleSignIn = GoogleSignIn();
    try {
      var reslut = await _googleSignIn.signIn();
      if (reslut == null) {
        return;
      }

      final userData = await reslut.authentication;
      final credential = GoogleAuthProvider.credential(
          accessToken: userData.accessToken, idToken: userData.idToken);
      var finalResult =
          await FirebaseAuth.instance.signInWithCredential(credential);
      setState(() {
        google_sign_completed = true;
        email = reslut.email;
        photo = reslut.photoUrl!;
        nameController.text = reslut.displayName!;
        loader = false;
      });
      if (reslut.displayName == null) {
        showerror(context, "Something went wrong");
      }
    } catch (error) {
      showerror(context, "Something went wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                alignment: Alignment.center,
                margin: const EdgeInsets.only(top: 30, bottom: 50),
                child: SvgPicture.asset(
                  'assets/logo.svg',
                  width: 220,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05,
                ),
                child: Text(
                  lang ? "नाम" : "Name",
                  style: TextStyle(
                      fontFamily: lang ? 'MExtraBold' : 'ExtraBold',
                      color: Colors.white,
                      fontSize: 25),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  top: 10,
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05,
                ),
                child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: const Color(0xff262C3A)),
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: TextField(
                      controller: nameController,
                      style: const TextStyle(
                          fontSize: 17,
                          color: Colors.white,
                          fontFamily: 'Bold'),
                      decoration: InputDecoration(
                          hintStyle: TextStyle(
                              fontSize: 17,
                              color: Colors.white,
                              fontFamily: lang ? 'MBold' : 'Bold'),
                          border: InputBorder.none,
                          hintText:
                              lang ? 'अपना नाम दर्ज करें' : 'Enter Your Name',
                          fillColor: Colors.white),
                    )),
              ),
              Padding(
                padding: EdgeInsets.only(
                  top: 30,
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05,
                ),
                child: InkWell(
                  onTap: () {
                    billFetch();
                  },
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: const Color(0xff00CE19),
                        borderRadius: BorderRadius.circular(5)),
                    child: Text(
                      lang ? "कंटीन्यू" : "Contiune",
                      style: TextStyle(
                          fontFamily: lang ? 'MExtraBold' : 'ExtraBold',
                          color: const Color(0xff1F222A),
                          fontSize: 18),
                    ),
                  ),
                ),
              )
            ],
          ),
          loader
              ? Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0xff181A20).withOpacity(0.3),
                  child: const Center(
                      child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Color(0xff497CFF),
                    ),
                  )),
                )
              : const Text(""),
        ],
      )),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    googleLogin();
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
