import 'dart:convert';
import 'dart:io';

import 'package:aadharpayv3/screens/proccessing.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:upi_india/upi_india.dart';

import 'home.dart';

class PrepaidView extends StatefulWidget {
  String val;
  String data;
  int rs;
  String decs;
  int dis;
  String img;
  String name;
  String num;
  PrepaidView(
      {super.key,
      required this.val,
      required this.data,
      required this.rs,
      required this.decs,
      required this.dis,
      required this.img,
      required this.name,
      required this.num});

  @override
  State<PrepaidView> createState() => _PrepaidViewState();
}

class _PrepaidViewState extends State<PrepaidView> {
  List response = [];
  final user = Hive.box('User');
  bool lang = false;

  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? AllUpiapps;
  UpiApp? hiveApp;
  bool isAppPresent = false;
  bool loader = false;

  late int i;
  late int check = 0;
  late List str = [];

  @override
  void initState() {
    super.initState();
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        AllUpiapps = value;
      });
    }).catchError((e) {
      AllUpiapps = [];
    });
    sync();
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  Future checkApp() async {
    var upiapps = user.get('upi');
    if (upiapps == 'Gpay') {
      hiveApp = UpiApp.googlePay;
    } else if (upiapps == 'Paytm') {
      hiveApp = UpiApp.paytm;
    } else if (upiapps == 'Bhim') {
      hiveApp = UpiApp.bhim;
    } else if (upiapps == 'upi') {}

    print(hiveApp?.name);
    var i;
    int isUpiApp = 0;
    for (i = 0; i < AllUpiapps?.length; i++) {
      print(AllUpiapps?[i].name);
      if (hiveApp?.packageName == AllUpiapps?[i].packageName) {
        print(AllUpiapps?[i].name);
        isUpiApp = 1;
      }
    }
    if (isUpiApp == 1) {
      print("App present");
      setState(() {
        loader = true;
      });
      billUpi(hiveApp);
    } else {
      print("not App present");
      setState(() {
        isAppPresent = true;
      });
    }
    return;
  }

  Future billUpi(appid) async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/aadharpay/api/v4/upiid.php'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          setState(() {
            loader = false;
          });
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Proccessing(
                    rs: widget.rs,
                    dis: double.parse((widget.rs - widget.rs * widget.dis / 100)
                        .toStringAsFixed(2)),
                    num: widget.num,
                    opr: widget.name,
                    upiid: reponse['upi'],
                    upiAppID: appid,
                  )));
        } else if (reponse['success'] == "N") {
          setState(() {
            loader = false;
          });
          showerror(context, reponse['msg']);
        } else {
          setState(() {
            loader = false;
          });
          showerror(context, "Something went wrong");
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        setState(() {
          loader = false;
        });
        showerror(context, "Something went wrong");
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
      });
      showerror(context, "Interner is not Connected");
    }
  }

  Widget displayUpiApps() {
    if (AllUpiapps == null) {
      return Center(child: CircularProgressIndicator());
    } else if (AllUpiapps!.length == 0) {
      return const Center(
        child: Text(
          "No apps found to handle transaction.",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return Center(
        child: Wrap(
          children: AllUpiapps!.map<Widget>((UpiApp app) {
            if (app.name == "PhonePe") {
              return const Text('');
            } else {
              return GestureDetector(
                onTap: () {
                  // upi(app);
                  billUpi(app);
                  setState(() {
                    isAppPresent = false;
                  });
                },
                child: Container(
                  height: 100,
                  width: 100,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.memory(
                        app.icon,
                        height: 40,
                        width: 40,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          app.name,
                          style: const TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
          }).toList(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return DefaultTabController(
      length: response.length,
      child: Scaffold(
        backgroundColor: const Color(0xff181A20),
        body: SafeArea(
            child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.20,
                        alignment: Alignment.center,
                        child: Row(children: [
                          const Icon(
                            Icons.keyboard_arrow_left,
                            size: 35,
                            color: Color(0xff497CFF),
                          ),
                          Text(
                            lang ? "पीछे" : "back",
                            style: TextStyle(
                                fontSize: 15,
                                color: const Color(0xff497CFF),
                                fontFamily: lang ? 'MBold' : 'Bold'),
                          ),
                        ]),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      alignment: Alignment.center,
                      child: Text(
                        lang ? "मोबाइल" : "Mobile",
                        style: TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                            fontFamily: lang ? 'MBold' : 'Bold'),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      alignment: Alignment.center,
                    )
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.05,
                    ),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(100),
                      child: Image.network(
                        widget.img,
                        width: 50,
                        height: 50,
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.name,
                          style: const TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontFamily: 'Bold'),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        const Text(
                          "+91 74710232899",
                          style: TextStyle(
                              fontSize: 15,
                              color: Color(0xffC0C0C0),
                              fontFamily: 'SemiBold'),
                        )
                      ],
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Color(0xff262C3A),
                      border: Border(
                          bottom: BorderSide(
                        width: 1,
                        color: Color(0xff121212),
                      ))),
                  padding: const EdgeInsets.only(top: 5, bottom: 10),
                  child: Row(
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.75,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.only(left: 20, top: 20),
                              child: Text(
                                widget.val.isNotEmpty ? widget.val : "",
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    color: Colors.white),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(left: 20, top: 5),
                              child: Text(
                                widget.data != null ? widget.data : "",
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: Color.fromARGB(255, 185, 185, 185)),
                              ),
                            ),
                            Container(
                                margin: const EdgeInsets.only(left: 20, top: 5),
                                child: Text(
                                  widget.decs != null ? widget.decs : "",
                                  maxLines: 2,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color:
                                          Color.fromARGB(255, 185, 185, 185)),
                                )),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.25,
                        height: 100,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              margin: const EdgeInsets.only(bottom: 3),
                              child: Text(
                                "₹${widget.rs}",
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.lineThrough,
                                    decorationColor: Color(0xff00CE19),
                                    decorationThickness: 3),
                              ),
                            ),
                            Text(
                              "₹${(widget.rs - widget.rs * widget.dis / 100).toStringAsFixed(2)}",
                              style: const TextStyle(
                                fontSize: 18,
                                color: Color(0xff00CE19),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.25,
                              margin: const EdgeInsets.only(top: 3),
                              child: ClipPath(
                                clipper: discountClip(),
                                child: Container(
                                  padding: const EdgeInsets.only(
                                      top: 6, bottom: 6, left: 15, right: 5),
                                  color: const Color(0xff00CE19),
                                  child: Text(
                                    "₹${(widget.rs * widget.dis / 100).toStringAsFixed(2)}  OFF",
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    top: 50,
                    left: MediaQuery.of(context).size.width * 0.05,
                    right: MediaQuery.of(context).size.width * 0.05,
                  ),
                  child: InkWell(
                    onTap: () {
                      checkApp();
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.90,
                      height: 50,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: const Color(0xff00CE19),
                          borderRadius: BorderRadius.circular(5)),
                      child: Text(
                        lang ? "कंटीन्यू" : "Contiune",
                        style: TextStyle(
                            fontFamily: lang ? 'MExtraBold' : 'ExtraBold',
                            color: const Color(0xff1F222A),
                            fontSize: 18),
                      ),
                    ),
                  ),
                )
              ],
            ),
            loader
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: const Color(0xff181A20).withOpacity(0.3),
                    child: const Center(
                        child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xff497CFF),
                      ),
                    )),
                  )
                : const Text(""),
            Visibility(
              visible: isAppPresent,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0x4d0097A7),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(
                        color: Color(0xff161616),
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(5),
                            topRight: Radius.circular(5)),
                      ),
                      padding: const EdgeInsets.only(top: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(bottom: 8, left: 20),
                            child: Text(
                              "Select Payment App",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white,
                                  fontSize: 25),
                            ),
                          ),
                          displayUpiApps(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        )),
      ),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}

class discountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}
