import 'package:aadharpayv3/screens/home.dart';
import 'package:aadharpayv3/screens/privacy_policy.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';

class UpiApps extends StatefulWidget {
  const UpiApps({super.key});

  @override
  State<UpiApps> createState() => _UpiAppsState();
}

class _UpiAppsState extends State<UpiApps> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(top: 30, bottom: 50),
            child: SvgPicture.asset(
              'assets/logo.svg',
              width: 220,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: const Text(
              "UPI Apps",
              style: TextStyle(
                  fontFamily: 'ExtraBold', color: Colors.white, fontSize: 25),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          InkWell(
            onTap: () {
              user.put("upi", "Gpay");
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (BuildContext context) => const Home()));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: const BoxDecoration(
                color: Color(0xff161616),
                border: Border(
                  top: BorderSide(
                    color: Color(0xff121212),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/UPI/Gpay.webp"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10),
                          child: Text(
                            "Gpay",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              user.put("upi", "Paytm");
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (BuildContext context) => const Home()));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: const BoxDecoration(
                color: Color(0xff161616),
                border: Border(
                  top: BorderSide(
                    color: Color(0xff121212),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/UPI/Paytm.png"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10),
                          child: Text(
                            "Paytm",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              user.put("upi", "Bhim");
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (BuildContext context) => const Home()));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: const BoxDecoration(
                color: Color(0xff161616),
                border: Border(
                  top: BorderSide(
                    color: Color(0xff121212),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/UPI/bhim.webp"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10),
                          child: Text(
                            "Bhim UPI",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              user.put("upi", "UPI");
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (BuildContext context) => const Home()));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: const BoxDecoration(
                color: Color(0xff161616),
                border: Border(
                  top: BorderSide(
                    color: Color(0xff121212),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/UPI/upi.webp"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10),
                          child: Text(
                            "Other",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
        ],
      )),
    );
  }
}
