import 'dart:convert';
import 'dart:io';
import 'package:aadharpayv3/screens/upi.dart';
import 'package:intl/intl.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:simple_ripple_animation/simple_ripple_animation.dart';
import 'package:http/http.dart' as http;
import 'package:upi_india/upi_india.dart';

import 'response.dart';

class Proccessing extends StatefulWidget {
  String num;
  String opr;
  int rs;
  double dis;
  UpiApp upiAppID;
  String upiid;
  Proccessing(
      {super.key,
      required this.num,
      required this.opr,
      required this.rs,
      required this.dis,
      required this.upiAppID,
      required this.upiid});

  @override
  State<Proccessing> createState() => _ProccessingState();
}

class _ProccessingState extends State<Proccessing> {
  final user = Hive.box('User');
  String txn = "";
  int once = 0;
  UpiIndia _upiIndia = UpiIndia();
  final now = DateTime.now();
  @override
  void initState() {
    super.initState();
    if (once == 0) {
      sendInitialRequest();
    }
  }

  Future sendInitialRequest() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v4/initial_payment.php?userid=${user.get('user_id1')}&num=${widget.num}&type=Mobile&opr=${widget.opr}&mrp=${widget.rs}&selling_price=${widget.dis}'));

      if (fetch.statusCode == 200) {
        var response = json.decode(fetch.body);
        print(response['tranid']);
        if (response['success'] == "Y") {
          setState(() {
            txn = response['tranid'];
          });
          widget.dis = (widget.dis > 99) ? (widget.dis + 1) : widget.dis;
          upi(widget.upiAppID);
        } else {
          showerror(context, "Something went wrong");
        }
        once++;
        return response;
      } else {
        showerror(context, "Something went wrong");
      }
    } on SocketException catch (_) {
      showerror(context, "Internet is not connected");
    }
  }

  Future<String> upi(apppack) async {
    _upiIndia
        .startTransaction(
            app: apppack,
            receiverName: 'Dhiraj Dattatray Kadam',
            receiverUpiId: widget.upiid,
            transactionRefId: 'IQR20220823',
            amount: widget.dis)
        .then((value) => {
              if (value.status == UpiPaymentStatus.SUCCESS)
                {
                  print(widget.dis + 1),
                  billFetch(),
                }
              else if (value.status == UpiPaymentStatus.FAILURE)
                {
                  showerror(context, "Payment Failed"),
                }
              else if (value.status == UpiPaymentStatus.SUBMITTED)
                {
                  PaymentPending(),
                }
              else
                {
                  showerror(context, "Payment Failed"),
                }
            })
        .onError((error, stackTrace) => {
              if (error.runtimeType == UpiIndiaAppNotInstalledException)
                {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (BuildContext context) => const UpiApps()))
                }
              else if (error.runtimeType == UpiIndiaUserCancelledException)
                {
                  showerror(context, "Payment Failed"),
                }
              else if (error.runtimeType == UpiIndiaNullResponseException)
                {
                  showerror(context, "Payment Failed"),
                }
              else if (error.runtimeType == UpiIndiaInvalidParametersException)
                {
                  showerror(context, "Payment Failed"),
                }
              else
                {
                  showerror(context, "Payment Failed"),
                }
            });

    return 'reponse';
  }

  Future PaymentPending() async {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (BuildContext context) => Response(
              amu: widget.dis,
              num: widget.num,
              status: "PENDING",
              type: "Mobile",
              date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
              time: DateFormat('kk:mm').format(DateTime.now()),
              tranid: "null",
            )));
  }

  Future billFetch() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v4/payment.php?txn=$txn'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Response(
                    amu: widget.dis,
                    num: widget.num,
                    status: "SUCCESS",
                    type: "Mobile",
                    date: reponse['date'],
                    time: reponse['time'],
                    tranid: reponse['tranid'],
                  )));
        } else if (reponse['success'] == "F") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Response(
                    amu: widget.dis,
                    num: widget.num,
                    status: "FAILED",
                    type: "Mobile",
                    date: reponse['date'],
                    time: reponse['time'],
                    tranid: reponse['tranid'],
                  )));
        } else if (reponse['success'] == "P") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Response(
                    amu: widget.dis,
                    num: widget.num,
                    status: "PENDING",
                    type: "Mobile",
                    date: reponse['date'],
                    time: reponse['time'],
                    tranid: reponse['tranid'],
                  )));
        } else if (reponse['success'] == "N") {
          showerror(context, "Internet is not connected");
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        showerror(context, "Something went wrong");
        //throw Exception('FAILED to load album');
      }
    } on SocketException catch (_) {
      showerror(context, "Interner is not Connected");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: Stack(
        children: [
          Center(
            child: SizedBox(
              height: 200,
              width: 200,
              child: RippleAnimation(
                repeat: true,
                color: const Color(0xff00CE19),
                minRadius: 100,
                ripplesCount: 5,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      'assets/green_logo.svg',
                      width: 100,
                      height: 100,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
              bottom: 20,
              child: Container(
                width: MediaQuery.of(context).size.width,
                alignment: Alignment.center,
                child: Column(
                  children: const [
                    Text(
                      "Payment proccessing",
                      style: TextStyle(
                          fontFamily: 'ExtraBold',
                          color: Colors.white,
                          fontSize: 25),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "Please Wait",
                      style: TextStyle(
                          fontFamily: 'SemiBold',
                          color: Color(0xffC0C0C0),
                          fontSize: 15),
                    ),
                  ],
                ),
              ))
        ],
      ),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
