import 'package:aadharpayv3/screens/prepaid.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

import 'home.dart';

class DthNum extends StatefulWidget {
  const DthNum({super.key});

  @override
  State<DthNum> createState() => _DthNumState();
}

class _DthNumState extends State<DthNum> {
  TextEditingController numController = TextEditingController();
  List<Contact> contacts = [];
  List<Contact> contactscheck = [];
  List<Contact> contactsFilter = [];
  final user = Hive.box('User');
  bool lang = false;
  @override
  void initState() {
    super.initState();
    sync();
    getContact();
  }

  void getContact() async {
    if (await FlutterContacts.requestPermission()) {
      contacts = await FlutterContacts.getContacts(
          withProperties: true, withPhoto: true);
      print(contacts);
      contactsFilter = contacts;
      setState(() {});
    }
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    void filterSearchResults(String query) {
      contactscheck.clear();
      for (var item in contacts) {
        if (item.phones.first.number
            .toString()
            .replaceAll(" ", "")
            .contains(query.toString())) {
          setState(() {
            contactscheck.add(item);
          });
        }
        setState(() {
          contactsFilter = contactscheck;
        });
      }

      return;
    }

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.20,
                  alignment: Alignment.center,
                  child: Row(children: [
                    const Icon(
                      Icons.keyboard_arrow_left,
                      size: 35,
                      color: Color(0xff497CFF),
                    ),
                    Text(
                      lang ? "पीछे" : "back",
                      style: TextStyle(
                          fontSize: 15,
                          color: const Color(0xff497CFF),
                          fontFamily: lang ? 'MBold' : 'Bold'),
                    ),
                  ]),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.20,
                alignment: Alignment.center,
                child: Text(
                  lang ? "मोबाइल" : "TV",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontFamily: lang ? 'MBold' : 'Bold'),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.20,
                alignment: Alignment.center,
              )
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 10,
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: const Color(0xff262C3A)),
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextField(
                  style: const TextStyle(
                      fontSize: 17, color: Colors.white, fontFamily: 'Bold'),
                  decoration: InputDecoration(
                      hintStyle: TextStyle(
                          fontSize: 17,
                          color: Colors.white,
                          fontFamily: lang ? 'MBold' : 'Bold'),
                      border: InputBorder.none,
                      hintText: lang ? 'अपना नाम दर्ज करें' : 'Enter Your Name',
                      fillColor: Colors.white),
                )),
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: InkWell(
              onTap: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => const Home()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: const Color(0xff00CE19),
                    borderRadius: BorderRadius.circular(5)),
                child: Text(
                  lang ? "कंटीन्यू" : "Contiune",
                  style: TextStyle(
                      fontFamily: lang ? 'MExtraBold' : 'ExtraBold',
                      color: const Color(0xff1F222A),
                      fontSize: 18),
                ),
              ),
            ),
          )
        ],
      )),
    );
  }
}
