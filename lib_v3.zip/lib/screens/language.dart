import 'package:aadharpayv3/screens/privacy_policy.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';

class Language extends StatefulWidget {
  const Language({super.key});

  @override
  State<Language> createState() => _LanguageState();
}

class _LanguageState extends State<Language> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(top: 30, bottom: 50),
            child: SvgPicture.asset(
              'assets/logo.svg',
              width: 220,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
            ),
            child: const Text(
              "Language",
              style: TextStyle(
                  fontFamily: 'ExtraBold', color: Colors.white, fontSize: 25),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              InkWell(
                onTap: () {
                  user.put("lang", "hin");
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) =>
                          const PrivacyPolicy()));
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.40,
                  height: 50,
                  decoration: BoxDecoration(
                      color: const Color(0xff262C3A),
                      borderRadius: BorderRadius.circular(10)),
                  alignment: Alignment.center,
                  child: const Text(
                    "हिंदी",
                    style: TextStyle(
                        fontFamily: 'MBold',
                        color: Color(0xffC0C0C0),
                        fontSize: 20),
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  user.put("lang", "eng");
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) =>
                          const PrivacyPolicy()));
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.40,
                  height: 50,
                  decoration: BoxDecoration(
                      color: const Color(0xff262C3A),
                      borderRadius: BorderRadius.circular(10)),
                  alignment: Alignment.center,
                  child: const Text(
                    "English",
                    style: TextStyle(
                        fontFamily: 'Bold',
                        color: Color(0xffC0C0C0),
                        fontSize: 20),
                  ),
                ),
              )
            ],
          )
        ],
      )),
    );
  }
}
