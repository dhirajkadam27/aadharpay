import 'dart:convert';
import 'dart:io';

import 'package:aadharpayv3/screens/history.dart';
import 'package:aadharpayv3/screens/mobile.dart';
import 'package:aadharpayv3/screens/update.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:uninstall_apps_plus/uninstall_apps.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController nameController = TextEditingController();
  final user = Hive.box('User');
  bool lang = false;
  @override
  void initState() {
    super.initState();
    UPIFetch();
    sync();
  }

  Future sync() async {
    if (user.get('lang') == "hin") {
      setState(() {
        lang = true;
      });
    }
    return;
  }

  Future<void> initPlatformState() async {
    await UninstallApps.uninstall("com.aadharpay.app").then((value) => {
          if (!value)
            {
              initPlatformState(),
            }
        });
  }

  Future UPIFetch() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/aadharpay/api/v4/version.php'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['version'] == "2.00") {
          print("up to date");
        } else if (reponse['version'] == "null") {
          initPlatformState();
        } else {
          print(" not up to date");
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => const Update()));
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {}
  }

  Future fetchHistory() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v4/recent_history.php?user_id=' +
              user.get('user_id1')));

      if (fetch.statusCode == 200) {
        List response = json.decode(fetch.body);
        return response;
      } else {
        showerror(context, "Something went wrong");
      }
    } on SocketException catch (_) {
      showerror(context, "Internet is not connected");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      backgroundColor: const Color(0xff181A20),
      body: SafeArea(
          child: ListView(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(top: 30, bottom: 50),
            child: SvgPicture.asset(
              'assets/logo.svg',
              width: 220,
            ),
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.05,
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: Image.network(
                  "https://cdn.icon-icons.com/icons2/2643/PNG/512/male_boy_person_people_avatar_icon_159358.png",
                  width: 50,
                  height: 50,
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    lang ? "स्वागत है" : "Welcome",
                    style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                        fontFamily: lang ? 'MBold' : 'Bold'),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    "${user.get('user_name1')}",
                    style: const TextStyle(
                        fontSize: 15,
                        color: Color(0xffC0C0C0),
                        fontFamily: 'SemiBold'),
                  )
                ],
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 40, bottom: 30),
            child: Row(
              children: [
                Container(
                  width: 10,
                  height: 40,
                  color: const Color(0xff00CE19),
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  lang ? "भुगतान" : "Payments",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontFamily: lang ? 'MBold' : 'Bold'),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              InkWell(
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => const Mobile()));
                },
                child: Container(
                  padding: const EdgeInsets.only(
                      top: 10, left: 20, right: 20, bottom: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: const Color(0xff262C3A)),
                  child: Column(children: [
                    const Icon(
                      Icons.phone_iphone,
                      size: 30,
                      color: Colors.white,
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Text(
                      lang ? "मोबाइल" : "Mobile",
                      style: TextStyle(
                          fontSize: 13,
                          color: Colors.white,
                          fontFamily: lang ? 'MBold' : 'Bold'),
                    ),
                  ]),
                ),
              ),
              // Container(
              //   padding: const EdgeInsets.only(
              //       top: 10, left: 20, right: 20, bottom: 10),
              //   decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(5),
              //       color: const Color(0xff262C3A)),
              //   child: Column(children: [
              //     const Icon(
              //       Icons.tv,
              //       size: 30,
              //       color: Colors.white,
              //     ),
              //     const SizedBox(
              //       height: 8,
              //     ),
              //     Text(
              //       lang ? "टीवी" : "TV",
              //       style: TextStyle(
              //           fontSize: 13,
              //           color: Colors.white,
              //           fontFamily: lang ? 'MBold' : 'Bold'),
              //     ),
              //   ]),
              // ),

              InkWell(
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => const History()));
                },
                child: Container(
                  padding: const EdgeInsets.only(
                      top: 10, left: 20, right: 20, bottom: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: const Color(0xff262C3A)),
                  child: Column(children: [
                    const Icon(
                      Icons.compare_arrows,
                      size: 30,
                      color: Colors.white,
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Text(
                      lang ? "इतिहास" : "History",
                      style: TextStyle(
                          fontSize: 13,
                          color: Colors.white,
                          fontFamily: lang ? 'MBold' : 'Bold'),
                    ),
                  ]),
                ),
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 40, bottom: 30),
            child: Row(
              children: [
                Container(
                  width: 10,
                  height: 40,
                  color: const Color(0xff00CE19),
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  lang ? "हालिया भुगतान" : "Recent Payments",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontFamily: lang ? 'MBold' : 'Bold'),
                ),
              ],
            ),
          ),
          Column(
            children: [
              FutureBuilder(
                future: fetchHistory(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text(
                      lang ? "इतिहास" : "Something went wrong",
                      style: TextStyle(
                          fontSize: 13,
                          color: Colors.white,
                          fontFamily: lang ? 'MBold' : 'Bold'),
                    );
                  } else {
                    if (snapshot.hasData) {
                      if (snapshot.data.length == 0) {
                        return Text(
                          lang ? "इतिहास" : "No transactions yet!",
                          style: TextStyle(
                              fontSize: 13,
                              color: Colors.white,
                              fontFamily: lang ? 'MBold' : 'Bold'),
                        );
                      }
                      return ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        itemCount: snapshot.data!.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, index) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            padding: const EdgeInsets.all(10),
                            margin: const EdgeInsets.only(top: 2),
                            color: const Color(0xff262C3A),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            color: const Color(0xff181A20)),
                                        child: snapshot.data[index]['status'] ==
                                                "Success"
                                            ? const Icon(
                                                Icons.arrow_forward,
                                                size: 30,
                                                color: Color(0xff00CE19),
                                              )
                                            : snapshot.data[index]['status'] ==
                                                    "Refunding"
                                                ? const Center(
                                                    child: Text(
                                                      "!",
                                                      style: TextStyle(
                                                          fontSize: 25,
                                                          color:
                                                              Color(0xff005CE7),
                                                          fontFamily: 'Bold'),
                                                    ),
                                                  )
                                                : snapshot.data[index]
                                                            ['status'] ==
                                                        "Refunded"
                                                    ? const Icon(
                                                        Icons.done,
                                                        size: 30,
                                                        color:
                                                            Color(0xff00CE19),
                                                      )
                                                    : const Center(
                                                        child: Text(
                                                          "?",
                                                          style: TextStyle(
                                                              fontSize: 25,
                                                              color: Color(
                                                                  0xffFAE100),
                                                              fontFamily:
                                                                  'Bold'),
                                                        ),
                                                      ),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            snapshot.data[index]['status'] ==
                                                    "Success"
                                                ? lang
                                                    ? "भुगतान की सफलता"
                                                    : "Payment Success"
                                                : snapshot.data[index]
                                                            ['status'] ==
                                                        "Refunding"
                                                    ? lang
                                                        ? "पेमेंट रिफंडिंग"
                                                        : "Payment Refunding"
                                                    : snapshot.data[index]
                                                                ['status'] ==
                                                            "Refunded"
                                                        ? lang
                                                            ? "भुगतान वापस किया"
                                                            : "Payment Refunded"
                                                        : lang
                                                            ? "भुगतान लंबित"
                                                            : "Payment Pending",
                                            style: TextStyle(
                                                fontSize: 13,
                                                color: Colors.white,
                                                fontFamily:
                                                    lang ? 'MBold' : 'Bold'),
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            "+91 ${snapshot.data[index]['num']}",
                                            style: const TextStyle(
                                                fontSize: 13,
                                                color: Colors.white,
                                                fontFamily: 'Bold'),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  Text(
                                    "${snapshot.data[index]['mrp']}",
                                    style: const TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                        fontFamily: 'Bold'),
                                  ),
                                ]),
                          );
                        },
                      );
                    } else {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.only(top: 2),
                        color: const Color(0xff262C3A),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Shimmer.fromColors(
                                    baseColor: const Color(0xff181A20),
                                    highlightColor: const Color(0xff262C3A),
                                    child: Container(
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          color: const Color(0xff181A20)),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Shimmer.fromColors(
                                        baseColor: const Color(0xff181A20),
                                        highlightColor: const Color(0xff262C3A),
                                        child: Container(
                                            width: 100,
                                            height: 10,
                                            color: const Color(0xff181A20)),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      Shimmer.fromColors(
                                        baseColor: const Color(0xff181A20),
                                        highlightColor: const Color(0xff262C3A),
                                        child: Container(
                                            width: 100,
                                            height: 10,
                                            color: const Color(0xff181A20)),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              Shimmer.fromColors(
                                baseColor: const Color(0xff181A20),
                                highlightColor: const Color(0xff262C3A),
                                child: Container(
                                    width: 50,
                                    height: 30,
                                    color: const Color(0xff181A20)),
                              ),
                            ]),
                      );
                    }
                  }
                },
              ),
            ],
          )
        ],
      )),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    fetchHistory();
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
