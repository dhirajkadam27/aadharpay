import 'package:aadharpayv3/screens/privacy_policy.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher.dart';

class Update extends StatefulWidget {
  const Update({super.key});

  @override
  State<Update> createState() => _UpdateState();
}

class _UpdateState extends State<Update> {
  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff181A20),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: const Color(0xff181A20),
        body: SafeArea(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              alignment: Alignment.center,
              margin: const EdgeInsets.only(top: 30, bottom: 50),
              child: SvgPicture.asset(
                'assets/logo.svg',
                width: 220,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                bottom: 30,
                left: MediaQuery.of(context).size.width * 0.05,
                right: MediaQuery.of(context).size.width * 0.05,
              ),
              child: const Text(
                "Update",
                style: TextStyle(
                    fontFamily: 'ExtraBold', color: Colors.white, fontSize: 25),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                top: 30,
                left: MediaQuery.of(context).size.width * 0.05,
                right: MediaQuery.of(context).size.width * 0.05,
              ),
              child: InkWell(
                onTap: () {
                  launchUrl(
                    Uri.parse(
                        "https://play.google.com/store/apps/details?id=com.aadharpay.app"),
                    mode: LaunchMode.externalApplication,
                  );
                },
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.90,
                  height: 50,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: const Color(0xff00CE19),
                      borderRadius: BorderRadius.circular(5)),
                  child: Text(
                    "Update",
                    style: TextStyle(
                        fontFamily: 'ExtraBold',
                        color: const Color(0xff1F222A),
                        fontSize: 18),
                  ),
                ),
              ),
            )
          ],
        )),
      ),
    );
  }
}
