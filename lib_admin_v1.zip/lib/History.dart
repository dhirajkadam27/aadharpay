import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:ui';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';

class History extends StatefulWidget {
  const History({Key? key}) : super(key: key);

  @override
  State<History> createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  late Future<List<List<String>>> futureAlbum;

  Future<List<List<String>>> fetchAlbum() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/admin/history.php'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        print(
            'akdsm kdsdsl ds dlks dlksdkslklsk slklskslklsdslk s lskdlskdlsklsdlklkdslksd');
        List<List<String>> planData = welcomeFromJson(response.body);

        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      throw Exception('Something Went Wrong');
    }
  }

  List<List<String>> welcomeFromJson(String str) => List<List<String>>.from(
      json.decode(str).map((x) => List<String>.from(x.map((x) => x))));
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: Stack(
      children: [
        MainFrame(
          data: fetchAlbum(),
        )
      ],
    )));
  }
}

class MainFrame extends StatefulWidget {
  Future<List<List<String>>> data;
  MainFrame({required this.data});

  @override
  State<MainFrame> createState() => _MainFrameState();
}

String status = "Proccessing";
String id = "00";
int iVal = 0;
bool popup = false;

bool loader = false;
String statusTxt = 'Status';

class _MainFrameState extends State<MainFrame> {
  Future addData() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/admin/update.php?rec=${status}&sr=${id}'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        if (json.decode(response.body)['success'] == 'Y') {
          setState(() {
            loader = false;
            statusTxt = "Done";
          });
        } else {
          setState(() {
            loader = false;
            statusTxt = "Failed";
          });
        }
        return;
      } else {
        setState(() {
          loader = false;
          statusTxt = "Failed";
        });
        // If the server did not return a 200 OK response,
        // then throw an exception.

        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
        statusTxt = "Failed";
      });
      throw Exception('Something Went Wrong');
    }
  }

  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: (statusTxt == 'Done')
              ? Color.fromARGB(255, 120, 255, 210)
              : (statusTxt == 'Loading...')
                  ? Color.fromARGB(255, 120, 167, 255)
                  : (statusTxt == 'Status')
                      ? Colors.white
                      : Color.fromARGB(255, 255, 168, 161),
          padding: EdgeInsets.all(10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(statusTxt),
              loader
                  ? const SizedBox(
                      width: 15,
                      height: 15,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xff00CE19),
                      ),
                    )
                  : const Text(''),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 30),
          child: FutureBuilder<List<List<String>>>(
            future: widget.data,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                print(snapshot.data!.length);
                if (snapshot.data!.length == 0) {
                  return Container(
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: const [
                        Text("No Transactions Yet"),
                      ],
                    ),
                  );
                } else {
                  return ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: snapshot.data!.length,
                    shrinkWrap: true,
                    itemBuilder: (BuildContext context, index) {
                      return Container(
                        decoration: const BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                          color: Color.fromARGB(255, 0, 164, 14),
                          width: 2,
                        ))),
                        padding: const EdgeInsets.only(
                            top: 10, bottom: 10, left: 20, right: 20),
                        child: Column(children: [
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Text('Id : ${snapshot.data![index][0]}')
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "₹${snapshot.data![index][1]}",
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              ),
                              Text(
                                "₹${snapshot.data![index][2]}",
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("${snapshot.data![index][5]}"),
                              Text("${snapshot.data![index][3]}")
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              const Text("Commission : "),
                              Container(
                                padding: const EdgeInsets.only(
                                    top: 5, bottom: 5, left: 10, right: 10),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Color.fromARGB(255, 222, 255, 202),
                                ),
                                child: const Text(
                                  "₹19.00",
                                  style: TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                      color: Color.fromARGB(255, 42, 156, 0)),
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                            children: [
                              const Text("Status : "),
                              Container(
                                child: Text(
                                  "${snapshot.data![index][4]}",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: (snapshot.data![index][4] ==
                                              "SUCCESS")
                                          ? Color.fromARGB(255, 0, 153, 0)
                                          : (snapshot.data![index][4] ==
                                                  "PENDING")
                                              ? Color.fromARGB(255, 255, 166, 0)
                                              : (snapshot.data![index][4] ==
                                                      "REFUNDED")
                                                  ? Color.fromARGB(
                                                      255, 255, 166, 0)
                                                  : Color.fromARGB(
                                                      255, 255, 0, 0)),
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.only(
                                    top: 5, bottom: 5, left: 10, right: 10),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: (snapshot.data![index][6].isEmpty)
                                      ? Color.fromARGB(255, 255, 214, 196)
                                      : Color.fromARGB(255, 222, 255, 202),
                                ),
                                child: Text(
                                  (snapshot.data![index][6].isEmpty)
                                      ? "Unverified"
                                      : "verified",
                                  style: TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                      color: (snapshot.data![index][6].isEmpty)
                                          ? const Color.fromARGB(255, 255, 0, 0)
                                          : const Color.fromARGB(
                                              255, 0, 153, 0)),
                                ),
                              ),
                              ElevatedButton(
                                child: const Text('Update'),
                                onPressed: () {
                                  setState(() {
                                    status = snapshot.data![index][4];
                                    id = snapshot.data![index][7];
                                    popup = true;
                                    iVal = index;
                                    statusTxt = 'Status';
                                  });
                                },
                              ),
                            ],
                          ),
                        ]),
                      );
                    },
                  );
                }
              } else if (snapshot.hasError) {
                return Container(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text("${snapshot.error}"),
                    ],
                  ),
                );
              }

              // By default, show a loading spinner.
              return const Center(
                  child: SizedBox(
                width: 50,
                height: 50,
                child: CircularProgressIndicator(
                  strokeWidth: 6,
                  backgroundColor: Colors.black,
                  color: Color(0xff00CE19),
                ),
              ));
            },
          ),
        ),
        popup
            ? BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Color.fromARGB(57, 255, 255, 255),
                ),
              )
            : const Text(""),
        popup
            ? Container(
                padding:
                    EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 255, 255),
                  boxShadow: [
                    BoxShadow(
                      color: Color.fromARGB(255, 212, 212, 212),
                      spreadRadius: 10,
                      blurRadius: 20,
                      offset: Offset(3, 7),
                    ),
                  ],
                ),
                margin: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height * 0.40),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.60,
                child: Column(children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      InkWell(
                        onTap: () {
                          setState(() {
                            popup = false;
                          });
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(10),
                          child: Text(
                            "X",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "ID : ${id}",
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Active Status : ${status}",
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Update Status",
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  Wrap(
                    children: [
                      InkWell(
                        onTap: () {
                          setState(() {
                            status = "SUCCESS";
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 20, right: 20),
                          padding: const EdgeInsets.only(
                              top: 5, bottom: 5, left: 10, right: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color.fromARGB(255, 222, 255, 202),
                          ),
                          child: const Text(
                            "Success",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 42, 156, 0)),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            status = "FAILED";
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 20, right: 20),
                          padding: const EdgeInsets.only(
                              top: 5, bottom: 5, left: 10, right: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color.fromARGB(255, 255, 215, 215),
                          ),
                          child: const Text(
                            "Failed",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 255, 0, 0)),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            status = "PENDING";
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 20, right: 20),
                          padding: const EdgeInsets.only(
                              top: 5, bottom: 5, left: 10, right: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color.fromARGB(255, 255, 239, 202),
                          ),
                          child: const Text(
                            "Pending",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 255, 128, 0)),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            status = "PROCCESSING";
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 20, right: 20),
                          padding: const EdgeInsets.only(
                              top: 5, bottom: 5, left: 10, right: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color.fromARGB(255, 202, 214, 255),
                          ),
                          child: const Text(
                            "Proccessing",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 0, 13, 255)),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            status = "REFUNDED";
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 20, right: 20),
                          padding: const EdgeInsets.only(
                              top: 5, bottom: 5, left: 10, right: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Color.fromARGB(255, 255, 239, 202),
                          ),
                          child: const Text(
                            "Refunded",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 255, 128, 0)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        loader = true;
                        statusTxt = "Loading...";
                        popup = false;
                        widget.data.then((value) {
                          value[iVal][4] = status;
                          value[iVal][6] = 'Verified';
                        });
                      });
                      addData();
                    },
                    child: Container(
                      margin: const EdgeInsets.only(top: 20, right: 20),
                      padding: const EdgeInsets.only(
                          top: 10, bottom: 10, left: 30, right: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                      child: const Text(
                        "Submit",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 255, 255, 255)),
                      ),
                    ),
                  ),
                ]),
              )
            : const Text(""),
      ],
    );
  }
}
