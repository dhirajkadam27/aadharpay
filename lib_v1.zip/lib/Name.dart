import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'SetPin.dart';

class Name extends StatefulWidget {
  String num;
  Name({required this.num});

  @override
  State<Name> createState() => _NameState();
}

TextEditingController mycontroller = TextEditingController();
bool isButtonActive = false;

class _NameState extends State<Name> {
  @override
  void initState() {
    super.initState();
    mycontroller.text = "";
    mycontroller.addListener(() {
      if (mycontroller.text.length >= 1) {
        setState(() {
          isButtonActive = true;
        });
      } else {
        setState(() {
          isButtonActive = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        systemNavigationBarColor:
            isButtonActive ? const Color(0xff00CE19) : Colors.grey,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            child: Container(
              margin: const EdgeInsets.only(top: 40),
              height: 80,
              alignment: Alignment.center,
              child: const Image(
                image: AssetImage("assets/Logo/LogoGreen.png"),
                width: 200,
                height: 70,
              ),
            ),
          ),
          Container(
              margin: const EdgeInsets.only(top: 150),
              // ignore: prefer_const_literals_to_create_immutables
              child: Container(
                margin: const EdgeInsets.only(left: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(bottom: 10, left: 10),
                      child: const Text(
                        "Name",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      margin:
                          const EdgeInsets.only(top: 10, left: 5, bottom: 10),
                      child: TextField(
                        controller: mycontroller,
                        textAlignVertical: TextAlignVertical.center,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.only(
                              top: 12, bottom: 12, left: 20, right: 20),
                          isCollapsed: true,
                          hintText: "Enter Your Name",
                          hintStyle: TextStyle(color: Colors.black),
                          filled: true,
                          fillColor: Color(0xffA7FFB2),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                          disabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                        ),
                        style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                  ],
                ),
              )),
          Positioned(
            left: 0,
            bottom: 0,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: 60,
              child: TextButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.resolveWith((state) {
                    if (state.contains(MaterialState.disabled)) {
                      return Colors.grey;
                    } else {
                      return const Color(0xff00CE19);
                    }
                  }),
                ),
                onPressed: isButtonActive
                    ? () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => SetPin(
                                  num: widget.num,
                                  name: mycontroller.text,
                                )));
                      }
                    : null,
                child: const Text(
                  "Proceed",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
