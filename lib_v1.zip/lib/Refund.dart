import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'DthNum.dart';
import 'PrepaidOperators.dart';

class Refund extends StatefulWidget {
  String amu;
  Refund({required this.amu});

  @override
  State<Refund> createState() => _RefundState();
}

class _RefundState extends State<Refund> {
  var Name = Hive.box('AuthCred').get('name');

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Image(
                  image: AssetImage("assets/Action/Failed.png"),
                  width: 100,
                  height: 100,
                ),
                const Padding(
                  padding: EdgeInsets.only(top: 40),
                  child: Text(
                    "Refund Pending",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.black),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: Text(
                    "Refundable Amount ₹${widget.amu}",
                    style: TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.75,
                  padding: const EdgeInsets.only(top: 15),
                  child: const Text(
                    "If the Transaction Fails the your money will be refunded back to your account within 4-5hours",
                    style: TextStyle(
                        fontSize: 12, color: Color.fromARGB(255, 85, 85, 85)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ));
  }
}
