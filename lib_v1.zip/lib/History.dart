import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';
import 'dart:io';

class History extends StatefulWidget {
  const History({super.key});

  @override
  State<History> createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  late Future<List<List<String>>> futureAlbum;
  bool isError = false;
  String ErrorTxt = "Error";
  String userid = "";
  Box? authCred;

  Future<List<List<String>>> fetchAlbum() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/users/history.php?id=${userid}'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List<List<String>> planData = welcomeFromJson(response.body);
        print(planData);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          ErrorTxt = "Error";
          isError = true;
        });
        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      setState(() {
        ErrorTxt = "No Internet";
        isError = true;
      });

      throw Exception('Something Went Wrong');
    }
  }

  List<List<String>> welcomeFromJson(String str) => List<List<String>>.from(
      json.decode(str).map((x) => List<String>.from(x.map((x) => x))));

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');
    var user = await authCred?.get('id');
    setState(() {
      userid = user;
    });
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 50),
            width: MediaQuery.of(context).size.width,
            height: 50,
            alignment: Alignment.center,
            color: Color(0xff7358ff),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  RotationTransition(
                    turns: AlwaysStoppedAnimation(-90 / 360),
                    child: Image(
                      image: AssetImage("assets/Action/Back.png"),
                      width: 25,
                      height: 25,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 5),
                    child: Text(
                      "Pull down to refresh",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ]),
          ),
          Container(
            margin: const EdgeInsets.only(top: 100),
            color: Colors.white,
            child: RefreshIndicator(
                child: FutureBuilder<List<List<String>>>(
                  future: fetchAlbum(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      print(snapshot.data!.length);
                      if (snapshot.data!.length == 0) {
                        return Container(
                          width: MediaQuery.of(context).size.width,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: const [
                              Text("No Transactions Yet"),
                            ],
                          ),
                        );
                      } else {
                        return ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: snapshot.data!.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, index) {
                            return Container(
                              padding: const EdgeInsets.only(
                                  top: 15, bottom: 15, left: 20, right: 20),
                              decoration: const BoxDecoration(
                                  border: Border(
                                      bottom: BorderSide(
                                          width: 1,
                                          color: Color.fromARGB(
                                              255, 177, 177, 177)))),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(right: 15),
                                        decoration: BoxDecoration(
                                          color: (snapshot.data![index][4] ==
                                                  "SUCCESS")
                                              ? Color(0xff00CE19)
                                              : (snapshot.data![index][4] ==
                                                      "PROCCESSING")
                                                  ? Color.fromARGB(
                                                      255, 178, 255, 187)
                                                  : (snapshot.data![index][4] ==
                                                          "REFUNDED")
                                                      ? Colors.white
                                                      : (snapshot.data![index]
                                                                  [4] ==
                                                              "PENDING")
                                                          ? Colors.white
                                                          : (snapshot.data![
                                                                          index]
                                                                      [4] ==
                                                                  "RPROCCESSING")
                                                              ? Colors.white
                                                              : Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(100),
                                        ),
                                        padding: EdgeInsets.all(5),
                                        child: RotationTransition(
                                          turns: (snapshot.data![index][4] ==
                                                  "SUCCESS")
                                              ? const AlwaysStoppedAnimation(
                                                  135 / 360)
                                              : (snapshot.data![index][4] ==
                                                      "PROCCESSING")
                                                  ? const AlwaysStoppedAnimation(
                                                      1 / 1)
                                                  : (snapshot.data![index][4] ==
                                                          "REFUNDED")
                                                      ? const AlwaysStoppedAnimation(
                                                          1 / 1)
                                                      : (snapshot.data![index]
                                                                  [4] ==
                                                              "PENDING")
                                                          ? const AlwaysStoppedAnimation(
                                                              1 / 1)
                                                          : (snapshot.data![
                                                                          index]
                                                                      [4] ==
                                                                  "RPROCCESSING")
                                                              ? const AlwaysStoppedAnimation(
                                                                  1 / 1)
                                                              : const AlwaysStoppedAnimation(
                                                                  -35 / 360),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            child: Image(
                                              image: (snapshot.data![index]
                                                          [4] ==
                                                      "PROCCESSING")
                                                  ? AssetImage(
                                                      "assets/Action/Proccess.png")
                                                  : (snapshot.data![index][4] ==
                                                          "REFUNDED")
                                                      ? AssetImage(
                                                          "assets/Action/Refunded.png")
                                                      : (snapshot.data![index]
                                                                  [4] ==
                                                              "PENDING")
                                                          ? AssetImage(
                                                              "assets/Action/Pending.png")
                                                          : (snapshot.data![
                                                                          index]
                                                                      [4] ==
                                                                  "RPROCCESSING")
                                                              ? AssetImage(
                                                                  "assets/Action/In-progress.png")
                                                              : AssetImage(
                                                                  "assets/Action/Back.png"),
                                              width: 35,
                                              height: 35,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            (snapshot.data![index][4] ==
                                                    "SUCCESS")
                                                ? "Paid To"
                                                : (snapshot.data![index][4] ==
                                                        "PROCCESSING")
                                                    ? "Proccessing"
                                                    : (snapshot.data![index]
                                                                [4] ==
                                                            "REFUNDED")
                                                        ? "Refunded"
                                                        : (snapshot.data![index]
                                                                    [4] ==
                                                                "PENDING")
                                                            ? "Pending"
                                                            : (snapshot.data![
                                                                            index]
                                                                        [4] ==
                                                                    "RPROCCESSING")
                                                                ? "Recharge Proccessing"
                                                                : "Failed",
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 5),
                                            child: Text(
                                              snapshot.data![index][3],
                                              style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Color.fromARGB(
                                                      255, 88, 88, 88)),
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  Text(
                                    '₹${snapshot.data![index][2]}',
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xff00CE19),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      }
                    } else if (snapshot.hasError) {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text("${snapshot.error}"),
                          ],
                        ),
                      );
                    }

                    // By default, show a loading spinner.
                    return const Center(
                        child: SizedBox(
                      width: 50,
                      height: 50,
                      child: CircularProgressIndicator(
                        strokeWidth: 6,
                        backgroundColor: Colors.black,
                        color: Color(0xff00CE19),
                      ),
                    ));
                  },
                ),
                onRefresh: () async {
                  futureAlbum;
                }),
          ),
          Visibility(
            visible: isError,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: Color.fromARGB(117, 151, 151, 151),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.50,
                      decoration: const BoxDecoration(
                          color: Color.fromARGB(255, 251, 252, 255),
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(50),
                              topRight: Radius.circular(50)),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey,
                                spreadRadius: 3,
                                blurRadius: 15,
                                offset: Offset(0, 0))
                          ]),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Image(
                              image: AssetImage("assets/Action/Error.webp"),
                              width: 100,
                              height: 100,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              child: Text(
                                ErrorTxt,
                                style: const TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                            const Text(
                              "Something went wrong",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey),
                            ),
                            TextButton(
                                onPressed: () {
                                  futureAlbum;
                                  setState(() {
                                    isError = false;
                                    ErrorTxt = "Error";
                                  });
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(top: 10),
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10, left: 20, right: 20),
                                  decoration: BoxDecoration(
                                      color: Colors.blueAccent,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: const Text(
                                    "Retry",
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ))
                          ]),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
