import 'package:aadharpay/DthNum.dart';
import 'package:aadharpay/NotificationService.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'Demo.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Electricity.dart';
import 'Failed.dart';
import 'History.dart';
import 'Landline.dart';
import 'Offers.dart';
import 'Profile.dart';
import 'Splash.dart';
import 'Contacts.dart';
import 'PrepaidOperators.dart';
import 'package:in_app_update/in_app_update.dart';

import 'Update.dart';

NotificationServices notificationServices = NotificationServices();
void main() {
  runApp(const Home());
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int index = 0;
  final screens = [
    const MainFrame(),
    const Offers(),
    const History(),
    const Profile()
  ];

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));

    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Color(0xff00CE19),
          selectedFontSize: 12,
          type: BottomNavigationBarType.fixed,
          currentIndex: index,
          onTap: (index) => setState(() {
            this.index = index;
          }),
          items: const [
            BottomNavigationBarItem(
                activeIcon: Image(
                  image: AssetImage("assets/Bottom/AHome.png"),
                  width: 25,
                  height: 25,
                ),
                icon: Image(
                  image: AssetImage("assets/Bottom/Home.png"),
                  width: 25,
                  height: 25,
                ),
                label: "Home"),
            BottomNavigationBarItem(
                activeIcon: Image(
                  image: AssetImage("assets/Bottom/AOffer.png"),
                  width: 25,
                  height: 25,
                ),
                icon: Image(
                  image: AssetImage("assets/Bottom/Offer.png"),
                  width: 25,
                  height: 25,
                ),
                label: "Offers"),
            BottomNavigationBarItem(
                activeIcon: Image(
                  image: AssetImage("assets/Bottom/AHistory.png"),
                  width: 25,
                  height: 25,
                ),
                icon: Image(
                  image: AssetImage("assets/Bottom/History.png"),
                  width: 25,
                  height: 25,
                ),
                label: "History"),
            BottomNavigationBarItem(
                activeIcon: Image(
                  image: AssetImage("assets/Bottom/AProfile.png"),
                  width: 25,
                  height: 25,
                ),
                icon: Image(
                  image: AssetImage("assets/Bottom/Profile.png"),
                  width: 25,
                  height: 25,
                ),
                label: "Profile"),
          ],
        ),
        body: screens[index]);
  }
}

class MainFrame extends StatefulWidget {
  const MainFrame({super.key});

  @override
  State<MainFrame> createState() => _MainFrameState();
}

class _MainFrameState extends State<MainFrame> {
  Box? authCred;

  @override
  void initState() {
    super.initState();
    notificationServices.initialiseNotifications();

    // Instantiate NewVersion manager object (Using GCP Console app as example)

    InAppUpdate.checkForUpdate().then((info) {
      if (info.updateAvailability == UpdateAvailability.updateAvailable) {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => const Update()));
      }
    }).catchError((e) {
      //showSnack(e.toString());
    });

    openBox();

    // You can let the plugin handle fetching the status and showing a dialog,
    // or you can fetch the status and display your own dialog, or no dialog.
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred').then((value) {
      if (value.get('id') == null) {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => const Splash()));
      }
    }).onError((error, stackTrace) {
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (context) => const Splash()));
    });

    setState(() {});
    return;
  }

  var ctime;
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));

    return WillPopScope(
      onWillPop: () {
        DateTime now = DateTime.now();
        if (ctime == null || now.difference(ctime) > Duration(seconds: 2)) {
          //add duration of press gap
          ctime = now;
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  'Press Back Button Again to Exit'))); //scaffold message, you can show Toast message too.
          return Future.value(false);
        }
        SystemNavigator.pop();
        return Future.value(true);
      },
      child: SafeArea(
        child: Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: 50,
              color: const Color(0xff00CE19),
            ),
            Container(
              alignment: Alignment.center,
              height: 50,
              child: Image(
                image: const AssetImage("assets/Logo/LogoWhite.png"),
                width: MediaQuery.of(context).size.width * 0.45,
                height: 50,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 50),
              color: const Color(0xffF5F5F5),
              child: ListView(
                children: [
                  InkWell(
                    onTap: () {
                      //notificationServices.sendNotification();
                    },
                    child: Container(
                      margin:
                          const EdgeInsets.only(top: 20, left: 20, right: 20),
                      height: 130,
                      decoration: const BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(255, 180, 180, 180),
                          blurRadius: 18,
                          offset: Offset(0, 0),
                        )
                      ]),
                      child: const Image(
                        image: AssetImage("assets/Home/Account.png"),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20, left: 20, right: 20),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromARGB(255, 180, 180, 180),
                            blurRadius: 18,
                            offset: Offset(0, 0),
                          )
                        ]),
                    child: Container(
                      child: Column(children: [
                        Container(
                          alignment: Alignment.topLeft,
                          child: Container(
                            margin: const EdgeInsets.only(top: 15, left: 20),
                            child: const Text(
                              "Recharges & Bill Payments",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 15, bottom: 15),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const PrepaidOperators()));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        child: const Image(
                                          image: AssetImage(
                                              "assets/Home/Prepaid.png"),
                                          width: 35,
                                          height: 35,
                                        ),
                                      ),
                                      const Text(
                                        "Mobile",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const DthOperators()));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        child: const Image(
                                          image:
                                              AssetImage("assets/Home/DTH.png"),
                                          width: 35,
                                          height: 35,
                                        ),
                                      ),
                                      const Text(
                                        "DTH",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const Electricity()));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        child: const Image(
                                          image: AssetImage(
                                              "assets/Home/Electricity.png"),
                                          width: 35,
                                          height: 35,
                                        ),
                                      ),
                                      const Text(
                                        "Electricity",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => Landline()));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        child: const Image(
                                          image: AssetImage(
                                              "assets/Home/Landline.png"),
                                          width: 35,
                                          height: 35,
                                        ),
                                      ),
                                      const Text(
                                        "Landline",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ]),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20, left: 20, right: 20),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromARGB(255, 180, 180, 180),
                            blurRadius: 18,
                            offset: Offset(0, 0),
                          )
                        ]),
                    child: Container(
                      child: Column(children: [
                        Container(
                          alignment: Alignment.topLeft,
                          child: Container(
                            margin: const EdgeInsets.only(top: 15, left: 20),
                            child: const Text(
                              "Prepaid Provider",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 8, bottom: 10),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => Contacts(
                                                opr: 'Airtel',
                                                dis: 2,
                                                img:
                                                    'assets/Prepaid/Airtel.png',
                                                oprcode: 6)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Prepaid/Airtel.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Airtel",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => Contacts(
                                                opr: 'BSNL',
                                                dis: 4,
                                                img: 'assets/Prepaid/BSNL.png',
                                                oprcode: 13)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Prepaid/BSNL.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "BSNL",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => Contacts(
                                                opr: 'VI',
                                                dis: 3,
                                                img: 'assets/Prepaid/VI.png',
                                                oprcode: 1)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Prepaid/VI.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "VI",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => Contacts(
                                                opr: 'JIO',
                                                dis: 3,
                                                img: 'assets/Prepaid/JIO.png',
                                                oprcode: 2)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Prepaid/JIO.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Jio",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ]),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20, left: 20, right: 20),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromARGB(255, 180, 180, 180),
                            blurRadius: 18,
                            offset: Offset(0, 0),
                          )
                        ]),
                    child: Container(
                      child: Column(children: [
                        Container(
                          alignment: Alignment.topLeft,
                          child: Container(
                            margin: const EdgeInsets.only(top: 15, left: 20),
                            child: const Text(
                              "DTH Provider",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 8, bottom: 10),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => DthNum(
                                                opr: 'Dish TV',
                                                dis: 3,
                                                img: 'assets/DTH/Dish.png',
                                                oprcode: 7)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/DTH/Dish.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Dish TV",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => DthNum(
                                                opr: 'Videocon D2H',
                                                dis: 3,
                                                img: 'assets/DTH/D2h.jpg',
                                                oprcode: 10)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/DTH/D2h.jpg"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "D2H",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => DthNum(
                                                opr: 'Sun TV',
                                                dis: 3,
                                                img: 'assets/DTH/Sun.jpg',
                                                oprcode: 11)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/DTH/Sun.jpg"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Sun TV",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (context) => DthNum(
                                                opr: 'Tata Sky',
                                                dis: 3,
                                                img: 'assets/DTH/Tata.png',
                                                oprcode: 8)));
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/DTH/Tata.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Tata Play",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          margin: const EdgeInsets.only(left: 10),
                          child: TextButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => DthNum(
                                      opr: 'Airtel Digital TV',
                                      dis: 3,
                                      img: 'assets/Prepaid/Airtel.png',
                                      oprcode: 12)));
                            },
                            child: Column(
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  padding: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(100),
                                    border: Border.all(
                                        color: const Color(0xff00CE19),
                                        width: 2),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(100),
                                    child: const Image(
                                      image: AssetImage(
                                          "assets/Prepaid/Airtel.png"),
                                      width: 35,
                                      height: 35,
                                    ),
                                  ),
                                ),
                                const Text(
                                  "Airtel TV",
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20, left: 20, right: 20),
                    height: 130,
                    decoration: const BoxDecoration(boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 180, 180, 180),
                        blurRadius: 18,
                        offset: Offset(0, 0),
                      )
                    ]),
                    child: const Image(
                      image: AssetImage("assets/Ads/Ad0.png"),
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20, left: 20, right: 20),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromARGB(255, 180, 180, 180),
                            blurRadius: 18,
                            offset: Offset(0, 0),
                          )
                        ]),
                    child: Container(
                      child: Column(children: [
                        Container(
                          alignment: Alignment.topLeft,
                          child: Container(
                            margin: const EdgeInsets.only(top: 15, left: 20),
                            child: const Text(
                              "Sponser Links",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 8, bottom: 10),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    launchUrl(
                                        Uri.parse("https://www.amazon.com"),
                                        mode: LaunchMode.externalApplication);
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Home/Amazon.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Amazon",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    launchUrl(
                                        Uri.parse("https://www.zomato.com"),
                                        mode: LaunchMode.externalApplication);
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Home/Zomato.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Zomato",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    launchUrl(Uri.parse("https://www.groww.in"),
                                        mode: LaunchMode.externalApplication);
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Home/Groww.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Groww",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () {
                                    launchUrl(
                                        Uri.parse("https://www.swiggy.com"),
                                        mode: LaunchMode.externalApplication);
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        margin:
                                            const EdgeInsets.only(bottom: 10),
                                        padding: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          border: Border.all(
                                              color: const Color(0xff00CE19),
                                              width: 2),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: const Image(
                                            image: AssetImage(
                                                "assets/Home/Swiggy.png"),
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Swiggy",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ]),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      launchUrl(
                          Uri.parse(
                              "https://www.paisabazaar.com/education-loan/"),
                          mode: LaunchMode.externalApplication);
                    },
                    child: Container(
                      margin:
                          const EdgeInsets.only(top: 20, left: 20, right: 20),
                      height: 130,
                      decoration: const BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(255, 180, 180, 180),
                          blurRadius: 18,
                          offset: Offset(0, 0),
                        )
                      ]),
                      child: const Image(
                        image: AssetImage("assets/Ads/Loans.png"),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      launchUrl(Uri.parse("https://www.upgrad.com/"),
                          mode: LaunchMode.externalApplication);
                    },
                    child: Container(
                      margin:
                          const EdgeInsets.only(top: 20, left: 20, right: 20),
                      height: 130,
                      decoration: const BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(255, 180, 180, 180),
                          blurRadius: 18,
                          offset: Offset(0, 0),
                        )
                      ]),
                      child: const Image(
                        image: AssetImage("assets/Ads/upGrad.png"),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  const SizedBox(width: 100, height: 50)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
