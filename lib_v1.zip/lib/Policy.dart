import 'package:aadharpay/MobileNumber.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'SetPin.dart';

class Policy extends StatefulWidget {
  @override
  State<Policy> createState() => _PolicyState();
}

class _PolicyState extends State<Policy> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Color(0xff00CE19),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            child: Container(
              margin: const EdgeInsets.only(top: 40),
              height: 80,
              alignment: Alignment.center,
              child: const Image(
                image: AssetImage("assets/Logo/LogoGreen.png"),
                width: 200,
                height: 70,
              ),
            ),
          ),
          Container(
              margin: const EdgeInsets.only(top: 150),
              // ignore: prefer_const_literals_to_create_immutables
              child: Container(
                margin: const EdgeInsets.only(left: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(bottom: 10, left: 10),
                      child: const Text(
                        "Accept",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 87, 87, 87)),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(bottom: 10, left: 10),
                      child: const Text(
                        "Privacy Policy",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(
                          bottom: 10, right: 20, left: 10, top: 20),
                      child: const Text(
                        "Click on the link to read all the privacy policy of Aadharpay App",
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 111, 111, 111)),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        launchUrl(
                            Uri.parse(
                                "https://mydukanpe.com/aadharpay/legal/privacypolicy.html"),
                            mode: LaunchMode.externalApplication);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(
                            bottom: 10, right: 20, left: 10),
                        child: const Text(
                          "View Privacy Policy",
                          style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: Color.fromARGB(255, 0, 110, 255)),
                        ),
                      ),
                    ),
                  ],
                ),
              )),
          Positioned(
            left: 0,
            bottom: 0,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: 60,
              child: TextButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.resolveWith((state) {
                    if (state.contains(MaterialState.disabled)) {
                      return Colors.grey;
                    } else {
                      return const Color(0xff00CE19);
                    }
                  }),
                ),
                onPressed: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => MobileNumber()));
                },
                child: const Text(
                  "I Agree",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
