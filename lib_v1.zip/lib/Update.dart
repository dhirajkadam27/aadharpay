import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';
import 'package:in_app_update/in_app_update.dart';

class Update extends StatefulWidget {
  const Update({super.key});

  @override
  State<Update> createState() => _UpdateState();
}

class _UpdateState extends State<Update> {
  var ctime;
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: WillPopScope(
      onWillPop: () {
        DateTime now = DateTime.now();
        if (ctime == null || now.difference(ctime) > Duration(seconds: 2)) {
          //add duration of press gap
          ctime = now;
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  'Press Back Button Again to Exit'))); //scaffold message, you can show Toast message too.
          return Future.value(false);
        }
        SystemNavigator.pop();
        return Future.value(true);
      },
      child: SafeArea(
        child: Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: 50,
              color: const Color(0xff00CE19),
            ),
            Container(
              alignment: Alignment.center,
              height: 50,
              child: Image(
                image: const AssetImage("assets/Logo/LogoWhite.png"),
                width: MediaQuery.of(context).size.width * 0.45,
                height: 50,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 50),
              color: Colors.white,
              child: Center(
                child: Column(
                  children: [
                    const SizedBox(
                      width: 100,
                      height: 150,
                    ),
                    const Image(
                      image: AssetImage("assets/Action/update.webp"),
                      width: 250,
                      height: 250,
                    ),
                    Container(
                        width: MediaQuery.of(context).size.width * 0.75,
                        margin: const EdgeInsets.only(top: 10, bottom: 20),
                        child: const Text(
                          "Hurry! The App is ready to be updated. Update the app and experience the new features and services of Aadharpay.",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                          ),
                          textAlign: TextAlign.center,
                        )),
                    ElevatedButton(
                      child: const Text('Update Now'),
                      onPressed: () {
                        InAppUpdate.performImmediateUpdate()
                            .catchError((e) => print("Error"));
                      },
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    ));
  }
}
