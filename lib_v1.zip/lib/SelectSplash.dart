import 'dart:io';

import 'package:aadharpay/fullchange.dart';
import 'package:aadharpay/proChange.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';
import 'package:in_app_update/in_app_update.dart';

class SelectSplash extends StatefulWidget {
  const SelectSplash({super.key});

  @override
  State<SelectSplash> createState() => _SelectSplashState();
}

class _SelectSplashState extends State<SelectSplash> {
  int def = 1;
  int pro = 0;
  int ful = 0;

  Box? authCred;
  late Box AuthCred;

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');
    AuthCred = await Hive.openBox('AuthCred');
    if (authCred?.get('splash') != null) {
      setState(() {
        def = 1;
        pro = 0;
        ful = 0;
      });
    }
    if (authCred?.get('splash') == 'def') {
      setState(() {
        def = 1;
        pro = 0;
        ful = 0;
      });
    }
    if (authCred?.get('splash') == 'ful') {
      setState(() {
        def = 0;
        pro = 0;
        ful = 1;
      });
    }
    if (authCred?.get('splash') == 'pro') {
      setState(() {
        def = 0;
        pro = 1;
        ful = 0;
      });
    }

    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 20, top: 80),
            child: Text(
              "Select Splash Theme",
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            padding: EdgeInsets.only(top: 120),
            child: Wrap(children: [
              InkWell(
                onTap: (def == 1)
                    ? () {
                        setState(() {
                          def = 0;
                          pro = 0;
                          ful = 0;
                        });
                      }
                    : () {
                        AuthCred.put('splash', 'def');
                        setState(() {
                          def = 1;
                          pro = 0;
                          ful = 0;
                        });
                      },
                child: Container(
                  padding: const EdgeInsets.all(20),
                  child: Column(children: [
                    Container(
                      width: 100,
                      height: 200,
                      decoration: BoxDecoration(
                          border: (def == 1)
                              ? Border.all(
                                  color: const Color(0xff00CE19), width: 4)
                              : Border.all(
                                  color: const Color.fromARGB(255, 0, 0, 0),
                                  width: 3),
                          borderRadius: BorderRadius.circular(10)),
                      child: Image(
                        image: AssetImage("assets/Action/Default_Splash.png"),
                        width: 100,
                        height: 200,
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Text(
                        'Default Screen',
                        style: TextStyle(fontSize: 10),
                      ),
                    )
                  ]),
                ),
              ),
              InkWell(
                onTap: (pro == 1)
                    ? () {
                        setState(() {
                          def = 0;
                          pro = 0;
                          ful = 0;
                        });
                      }
                    : () {
                        AuthCred.put('splash', 'pro');
                        setState(() {
                          def = 0;
                          pro = 1;
                          ful = 0;
                        });
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) => proChange()));
                      },
                child: Container(
                  padding: const EdgeInsets.all(20),
                  child: Column(children: [
                    Container(
                      width: 100,
                      height: 200,
                      decoration: BoxDecoration(
                          border: (pro == 1)
                              ? Border.all(
                                  color: const Color(0xff00CE19), width: 4)
                              : Border.all(
                                  color: const Color.fromARGB(255, 0, 0, 0),
                                  width: 3),
                          borderRadius: BorderRadius.circular(10)),
                      child: const Image(
                        image: AssetImage("assets/Action/Profile_Splash.png"),
                        width: 100,
                        height: 200,
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Text('Profile Screen',
                          style: TextStyle(fontSize: 10)),
                    )
                  ]),
                ),
              ),
              InkWell(
                onTap: (ful == 1)
                    ? () {
                        setState(() {
                          def = 0;
                          pro = 0;
                          ful = 0;
                        });
                      }
                    : () {
                        setState(() {
                          AuthCred.put('splash', 'ful');
                          def = 0;
                          pro = 0;
                          ful = 1;
                        });
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) => fullChange()));
                      },
                child: Container(
                  padding: const EdgeInsets.all(20),
                  child: Column(children: [
                    Container(
                      width: 100,
                      height: 200,
                      decoration: BoxDecoration(
                          border: (ful == 1)
                              ? Border.all(
                                  color: const Color(0xff00CE19), width: 4)
                              : Border.all(
                                  color: const Color.fromARGB(255, 0, 0, 0),
                                  width: 3),
                          borderRadius: BorderRadius.circular(10)),
                      child: const Image(
                        image: AssetImage("assets/Action/Full_Splash.png"),
                        width: 100,
                        height: 100,
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 10),
                      child:
                          Text('Full Screen', style: TextStyle(fontSize: 10)),
                    )
                  ]),
                ),
              ),
            ]),
          )
        ],
      ),
    ));
  }
}
