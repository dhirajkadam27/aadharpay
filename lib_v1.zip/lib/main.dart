import 'dart:isolate';

import 'package:aadharpay/Demo.dart';
import 'package:aadharpay/proSplash.dart';
import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';
import 'package:aadharpay/NotificationService.dart';
import 'SelectSplash.dart';
import 'Splash.dart';
import 'Home.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'Upi.dart';
import 'UpiAppScreen.dart';
import 'fullSplash.dart';

@pragma('vm:entry-point') //
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) {
    print("Native called background task:"); //simpleTask will be emitted here.
    notificationServices.sendNotification();
    return Future.value(true);
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  NotificationServices notificationServices = NotificationServices();
  await Workmanager().initialize(
    callbackDispatcher, // The top level function, aka callbackDispatcher If enabled it will post a notification whenever the task is running. Handy for debugging tasks
  );

  await Hive.initFlutter();
  runApp(const Mains());
}

class Mains extends StatefulWidget {
  const Mains({Key? key}) : super(key: key);

  @override
  State<Mains> createState() => _MainsState();
}

class _MainsState extends State<Mains> {
  Box? authCred;
  int pop = 0;

  @override
  void initState() {
    super.initState();
    notificationServices.initialiseNotifications();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred').then((value) {
      if (value.get('splash') == null) {
        print("null");
        setState(() {
          pop = 1;
        });
      }
      if (value.get('splash') == 'def') {
        print("def1");
        setState(() {
          pop = 1;
        });
      }
      if (value.get('splash') == 'ful') {
        print("full");
        setState(() {
          pop = 2;
        });
      }
      if (value.get('splash') == 'pro') {
        print("pro");
        setState(() {
          pop = 3;
        });
      }
    });
    return;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: 'splash',
      routes: {
        'splash': (context) => Scaffold(
              backgroundColor: Colors.white,
              body: (pop == 1)
                  ? Splash()
                  : (pop == 2)
                      ? const fullSplash()
                      : (pop == 3)
                          ? const ProSplash()
                          : null,
            )
      },
    );
  }
}
