import 'package:aadharpay/PaymentProccessing.dart';
import 'package:aadharpay/Policy.dart';
import 'package:aadharpay/Refund.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'CheckPin.dart';
import 'MobileNumber.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  Box? authCred;

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');
    setState(() {});
    return;
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 2), () async {
      if (authCred?.get('tok') != null && authCred?.get('policy') != null) {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => CheckPin()));
      } else {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => Policy()));
      }
    });

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Container(
        color: Colors.white,
        child: Stack(
          children: const [
            Padding(
              padding: EdgeInsets.only(bottom: 100),
              child: Center(
                child: Image(
                  image: AssetImage("assets/Logo/SplashB.png"),
                  width: 200,
                  height: 200,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Center(
                child: Image(
                  image: AssetImage("assets/Action/Splash.png"),
                  width: 300,
                  height: 100,
                ),
              ),
            )
          ],
        ),
      ),
    ));
  }
}
