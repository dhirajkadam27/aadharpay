import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'DthNum.dart';
import 'PrepaidOperators.dart';
import 'package:audioplayers/audioplayers.dart';

class Success extends StatefulWidget {
  String amu;
  String dis;
  Success({required this.amu, required this.dis});

  @override
  State<Success> createState() => _SuccessState();
}

class _SuccessState extends State<Success> {
  final player = AudioPlayer();
  Duration duration = Duration.zero;
  Duration Position = Duration.zero;

  @override
  void dispose() {
    player.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(milliseconds: 50), () async {
      await player.play(AssetSource('audio/Tune.mp3'));
    });

    player.play(AssetSource('assests/audio/Tune.mp3'));
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Image(
                  image: AssetImage("assets/Action/Success.png"),
                  width: 100,
                  height: 100,
                ),
                const Padding(
                  padding: EdgeInsets.only(top: 40),
                  child: Text(
                    "Payment Successful",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.black),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    "Transaction Amount ₹${widget.amu}",
                    style: const TextStyle(fontSize: 15, color: Colors.black),
                  ),
                ),
                Container(
                    margin: const EdgeInsets.only(top: 50),
                    padding: const EdgeInsets.only(
                        top: 20, bottom: 20, left: 30, right: 30),
                    decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(10)),
                    child: Text(
                      "You Have Saved ₹${widget.dis}",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ))
              ],
            ),
          ),
        ],
      ),
    ));
  }
}
