import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';

class DthNum extends StatefulWidget {
  String opr;
  int dis;
  String img;
  int oprcode;
  DthNum(
      {required this.opr,
      required this.dis,
      required this.img,
      required this.oprcode});

  @override
  State<DthNum> createState() => _DthNumState();
}

TextEditingController mycontroller = TextEditingController();
bool isButtonActive = false;
Color btncolor = const Color(0xff00CE19);

class _DthNumState extends State<DthNum> {
  @override
  void initState() {
    super.initState();
    mycontroller.text = "";
    mycontroller.addListener(() {
      print(mycontroller);
      if (mycontroller.text.length > 1) {
        setState(() {
          isButtonActive = true;
        });
      } else {
        setState(() {
          isButtonActive = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: const Color(0xff00CE19),
        systemNavigationBarColor:
            isButtonActive ? const Color(0xff00CE19) : Colors.grey,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: 50,
              color: const Color(0xff00CE19),
            ),
            Container(
              alignment: Alignment.center,
              height: 50,
              child: Image(
                image: const AssetImage("assets/Logo/LogoWhite.png"),
                width: MediaQuery.of(context).size.width * 0.45,
                height: 50,
              ),
            ),
            Container(
                margin: const EdgeInsets.only(top: 70, left: 20, right: 20),
                height: 165,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 180, 180, 180),
                        blurRadius: 18,
                        offset: Offset(0, 0),
                      )
                    ]),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          margin:
                              EdgeInsets.only(left: 20, top: 20, bottom: 20),
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                color: const Color(0xff00CE19), width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image(
                              image: AssetImage(widget.img),
                              width: 40,
                              height: 40,
                            ),
                          ),
                        ),
                        Container(
                            margin: const EdgeInsets.only(left: 15),
                            child: Center(
                                child: Text(
                              widget.opr,
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ))),
                      ],
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 20, right: 20),
                      alignment: Alignment.topLeft,
                      child: TextField(
                        keyboardType: TextInputType.number,
                        controller: mycontroller,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.only(
                              top: 15, bottom: 15, left: 15, right: 15),
                          isCollapsed: true,
                          hintText: "Enter your TV's VC no.",
                          hintStyle: TextStyle(color: Colors.black),
                          filled: true,
                          fillColor: Color(0xffA7FFB2),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                          disabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide:
                                BorderSide(width: 0, color: Colors.white),
                          ),
                        ),
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            letterSpacing: 3),
                      ),
                    ),
                  ],
                )),
            Positioned(
              left: 0,
              bottom: 0,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 60,
                child: TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.resolveWith((state) {
                      if (state.contains(MaterialState.disabled)) {
                        return Colors.grey;
                      } else {
                        return Color(0xff00CE19);
                      }
                    }),
                  ),
                  child: const Text(
                    "Proceed",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.white),
                  ),
                  onPressed: isButtonActive
                      ? () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => DthAmu(
                                  opr: widget.opr,
                                  dis: widget.dis,
                                  img: widget.img,
                                  num: mycontroller.text,
                                  oprcode: widget.oprcode)));
                        }
                      : null,
                ),
              ),
            ),
            Visibility(
              visible: false,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Color(0x4d0097A7),
                  child: Center(child: CircularProgressIndicator()),
                ),
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
