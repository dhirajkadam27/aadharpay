import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';

class Landline extends StatefulWidget {
  const Landline({super.key});

  @override
  State<Landline> createState() => _LandlineState();
}

class _LandlineState extends State<Landline> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 50),
            color: Color(0xfff5f5f5),
            child: const Center(
              child: Image(
                image: AssetImage("assets/Action/CommingSoon.jpeg"),
                width: 200,
                height: 200,
              ),
            ),
          )
        ],
      ),
    ));
  }
}
