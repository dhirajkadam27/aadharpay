import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'PrepaidOperators.dart';
import 'PrepaidPlansView.dart';

List<Album> albumFromJson(String str) =>
    List<Album>.from(json.decode(str).map((x) => Album.fromJson(x)));

String albumToJson(List<Album> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Album {
  Album({
    required this.type,
    required this.data,
  });

  String type;
  List<Datum> data;

  factory Album.fromJson(Map<String, dynamic> json) => Album(
        type: json["type"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "type": type,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    required this.rs,
    required this.decs,
    required this.val,
    required this.data,
    required this.sms,
  });

  int rs;
  String decs;
  String val;
  String data;
  String sms;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        rs: json["rs"],
        decs: json["decs"],
        val: json["val"],
        data: json["data"],
        sms: json["sms"],
      );

  Map<String, dynamic> toJson() => {
        "rs": rs,
        "decs": decs,
        "val": val,
        "data": data,
        "sms": sms,
      };
}

class PrepaidPlans extends StatefulWidget {
  String opr;
  int dis;
  String num;
  String name;
  String ico;
  int oprcode;
  PrepaidPlans(
      {required this.opr,
      required this.dis,
      required this.num,
      required this.name,
      required this.ico,
      required this.oprcode});

  @override
  State<PrepaidPlans> createState() => _PrepaidPlansState();
}

class _PrepaidPlansState extends State<PrepaidPlans> {
  late Future<List<Album>> futureAlbum;
  bool isError = false;
  String ErrorTxt = "Error";

  Future<List<Album>> fetchAlbum() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/plans/${widget.opr}.json'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List<Album> planData = albumFromJson(response.body);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          ErrorTxt = "Error";
          isError = true;
        });
        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      setState(() {
        ErrorTxt = "No Internet";
        isError = true;
      });

      throw Exception('Something Went Wrong');
    }
  }

  @override
  void initState() {
    super.initState();
    futureAlbum = fetchAlbum();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return DefaultTabController(
      length: 7,
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: 50,
                color: const Color(0xff00CE19),
              ),
              Container(
                alignment: Alignment.center,
                height: 50,
                child: Image(
                  image: const AssetImage("assets/Logo/LogoWhite.png"),
                  width: MediaQuery.of(context).size.width * 0.45,
                  height: 50,
                ),
              ),
              Container(
                  margin: const EdgeInsets.only(top: 50),
                  child: Column(children: [
                    Row(
                      children: [
                        Container(
                          margin: const EdgeInsets.only(
                              top: 30, bottom: 10, left: 40, right: 15),
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                color: const Color(0xff00CE19), width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image(
                              image: AssetImage(widget.ico),
                              width: 45,
                              height: 45,
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                margin:
                                    const EdgeInsets.only(top: 15, bottom: 10),
                                child: Text(
                                  widget.name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      color: Colors.black),
                                )),
                            Text(widget.num,
                                style: const TextStyle(
                                    fontSize: 13,
                                    color: Color.fromARGB(255, 100, 100, 100))),
                          ],
                        )
                      ],
                    ),
                    Container(
                      margin:
                          const EdgeInsets.only(top: 10, left: 40, right: 40),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.only(
                                top: 8, bottom: 8, left: 20, right: 20),
                            decoration: const BoxDecoration(
                                color: Color(0xffA7FFB2),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            child: const Text(
                              "Prepaid",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 12),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                                top: 8, bottom: 8, left: 20, right: 20),
                            decoration: const BoxDecoration(
                                color: Color(0xffA7FFB2),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            child: Text(
                              widget.opr,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      child: TabBar(
                          indicatorWeight: 4,
                          indicatorColor: const Color(0xff00CE19),
                          isScrollable: true,
                          tabs: [
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(snapshot.data![0].type,
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(snapshot.data![1].type,
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(snapshot.data![2].type,
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(snapshot.data![3].type,
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(
                                        snapshot.data!.length > 4
                                            ? snapshot.data![4].type
                                            : 'Special Offers',
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(
                                        snapshot.data!.length > 5
                                            ? snapshot.data![5].type
                                            : 'Popular',
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                            Tab(
                              child: FutureBuilder<List<Album>>(
                                future: futureAlbum,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return Text(
                                        snapshot.data!.length > 6
                                            ? snapshot.data![6].type
                                            : 'Offers',
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold));
                                  } else if (snapshot.hasError) {
                                    return Text('${snapshot.error}');
                                  }
                                  return const Text(".",
                                      style: TextStyle(color: Colors.black));
                                },
                              ),
                            ),
                          ]),
                    ),
                    Expanded(
                        child: TabBarView(children: [
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data![0].data.length == 0) {
                                return Text("No plans found");
                              } else {
                                return ListView.builder(
                                  itemCount: snapshot.data![0].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![0]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![0]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![0]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![0]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![0].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![0].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![0].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![0].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![0].data[index].rs - snapshot.data![0].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![0].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style: TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data![1].data.length == 0) {
                                return Text("No plans found");
                              } else {
                                return ListView.builder(
                                  itemCount: snapshot.data![1].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![1]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![1]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![1]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![1]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![1].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![1].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![1].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![1].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![1].data[index].rs - snapshot.data![1].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![1].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data![2].data.length == 0) {
                                return Text("No plans found");
                              } else {
                                return ListView.builder(
                                  itemCount: snapshot.data![2].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![2]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![2]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![2]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![2]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![2].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![2].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![2].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![2].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![2].data[index].rs - snapshot.data![2].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![2].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data![3].data.length == 0) {
                                return Text("No plans found");
                              } else {
                                return ListView.builder(
                                  itemCount: snapshot.data![3].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![3]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![3]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![3]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![3]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![3].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![3].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![3].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![3].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![3].data[index].rs - snapshot.data![3].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![3].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data!.length > 4) {
                                return ListView.builder(
                                  itemCount: snapshot.data![4].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![4]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![4]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![4]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![4]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![4].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![4].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![4].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![4].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![4].data[index].rs - snapshot.data![4].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![4].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              } else {
                                return Text("No plans found");
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data!.length > 5) {
                                return ListView.builder(
                                  itemCount: snapshot.data![5].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![5]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![5]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![5]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![5]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![5].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![5].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![5].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![5].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![5].data[index].rs - snapshot.data![5].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![5].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              } else {
                                return Text("No plans found");
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                      Center(
                        child: FutureBuilder<List<Album>>(
                          future: futureAlbum,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data!.length > 6) {
                                return ListView.builder(
                                  itemCount: snapshot.data![6].data.length,
                                  itemBuilder: (BuildContext context, index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        PrepaidPlansView(
                                                          opr: widget.opr,
                                                          dis: widget.dis,
                                                          num: widget.num,
                                                          name: widget.name,
                                                          ico: widget.ico,
                                                          oprcode:
                                                              widget.oprcode,
                                                          val: snapshot.data![6]
                                                              .data[index].val,
                                                          data: snapshot
                                                              .data![6]
                                                              .data[index]
                                                              .data,
                                                          decs: snapshot
                                                              .data![6]
                                                              .data[index]
                                                              .decs,
                                                          amu: snapshot.data![6]
                                                              .data[index].rs,
                                                        )));
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: Color.fromARGB(
                                                255, 247, 247, 247),
                                            border: Border(
                                                bottom: BorderSide(
                                                    width: 1,
                                                    color: Colors.grey))),
                                        padding: const EdgeInsets.only(
                                            top: 5, bottom: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.75,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 20),
                                                    child: Text(
                                                      "${snapshot.data![6].data[index].val}",
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 20, top: 5),
                                                    child: Text(
                                                      "${snapshot.data![6].data[index].data}",
                                                      style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Color.fromARGB(
                                                              255, 92, 92, 92)),
                                                    ),
                                                  ),
                                                  Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 20, top: 5),
                                                      child: Text(
                                                        "${snapshot.data![6].data[index].decs}",
                                                        maxLines: 2,
                                                        style: const TextStyle(
                                                            fontSize: 12,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    92,
                                                                    92,
                                                                    92)),
                                                      )),
                                                  TextButton(
                                                      onPressed: () {},
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        margin: const EdgeInsets
                                                                .only(
                                                            left: 12, top: 5),
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 10,
                                                                right: 10),
                                                        child: const Text(
                                                          "Show More",
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              height: 100,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        bottom: 3),
                                                    child: Text(
                                                      "₹${snapshot.data![6].data[index].rs}",
                                                      style: const TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough,
                                                          decorationColor:
                                                              Color(0xff00CE19),
                                                          decorationThickness:
                                                              3),
                                                    ),
                                                  ),
                                                  Text(
                                                    "₹${(snapshot.data![6].data[index].rs - snapshot.data![6].data[index].rs * widget.dis / 100).toStringAsFixed(2)}",
                                                    style: const TextStyle(
                                                      fontSize: 18,
                                                      color: Color(0xff00CE19),
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.25,
                                                    margin:
                                                        const EdgeInsets.only(
                                                            top: 3),
                                                    child: ClipPath(
                                                      clipper: discountClip(),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 6,
                                                                bottom: 6,
                                                                left: 15,
                                                                right: 5),
                                                        color: const Color(
                                                            0xff00CE19),
                                                        child: Text(
                                                          "₹${(snapshot.data![6].data[index].rs * widget.dis / 100).toStringAsFixed(2)} OFF",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              } else {
                                return Text("No plans found");
                              }
                            } else if (snapshot.hasError) {
                              return Text('${snapshot.error}');
                            }

                            // By default, show a loading spinner.
                            return const CircularProgressIndicator();
                          },
                        ),
                      ),
                    ]))
                  ])),
              Visibility(
                visible: isError,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Color.fromARGB(117, 151, 151, 151),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height * 0.50,
                          decoration: const BoxDecoration(
                              color: Color.fromARGB(255, 251, 252, 255),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  topRight: Radius.circular(50)),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    spreadRadius: 3,
                                    blurRadius: 15,
                                    offset: Offset(0, 0))
                              ]),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Image(
                                  image: AssetImage("assets/Action/Error.webp"),
                                  width: 100,
                                  height: 100,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  child: Text(
                                    ErrorTxt,
                                    style: const TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ),
                                ),
                                const Text(
                                  "Something went wrong",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey),
                                ),
                                TextButton(
                                    onPressed: () {
                                      setState(() {
                                        isError = false;
                                        ErrorTxt = "Error";
                                      });
                                      Navigator.of(context).pop();
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10),
                                      padding: const EdgeInsets.only(
                                          top: 10,
                                          bottom: 10,
                                          left: 20,
                                          right: 20),
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: const Text(
                                        "Back",
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ))
                              ]),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class discountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}
