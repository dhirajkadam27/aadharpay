import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:upi_india/upi_india.dart';

import 'Failed.dart';
import 'PaymentProccessing.dart';
import 'RechargeProccessing.dart';
import 'Refund.dart';
import 'Success.dart';
import 'UpiAppScreen.dart';

class PrepaidPlansView extends StatefulWidget {
  String opr;
  int dis;
  String num;
  String name;
  String ico;
  String val;
  String data;
  String decs;
  int amu;
  int oprcode;
  PrepaidPlansView(
      {required this.opr,
      required this.dis,
      required this.num,
      required this.name,
      required this.ico,
      required this.val,
      required this.data,
      required this.decs,
      required this.amu,
      required this.oprcode});

  @override
  State<PrepaidPlansView> createState() => _PrepaidPlansViewState();
}

class _PrepaidPlansViewState extends State<PrepaidPlansView> {
  bool isError = false;
  bool isError2 = false;
  bool isInternet = false;
  bool isLoader = false;
  String ErrorTxt = "Error";
  bool Paybtn = false;
  String upiId = "";
  int ordid = (99999999 + Random().nextInt(1000000000 - 99999999));
  Box? authCred;
  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? AllUpiapps;
  UpiApp? hiveApp;
  bool isAppPresent = false;

  late int i;
  late int check = 0;
  late List str = [];

  @override
  void initState() {
    super.initState();
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        AllUpiapps = value;
      });
    }).catchError((e) {
      AllUpiapps = [];
    });
    openBox();
  }

  UpiApp app = UpiApp.allBank;
  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');

    for (i = 0; i < str.length; i++) {
      if (str[i]['num'] == widget.num) {
        check++;
      }
    }
    if (check == 0) {
      setState(() {
        str.add({
          "num": widget.num,
          "name": widget.name,
          "type": "mobile",
          "opr": widget.opr,
          "opr_code": widget.oprcode,
          "dis": widget.dis,
          "img": widget.ico
        });
      });
    }
    authCred?.put('bills', str);

    return;
  }

  Future checkApp() async {
    var upiapps = await authCred?.get('upi');
    if (upiapps == 'PhonePe') {
      hiveApp = UpiApp.phonePe;
    } else if (upiapps == 'Gpay') {
      hiveApp = UpiApp.googlePay;
    } else if (upiapps == 'Paytm') {
      hiveApp = UpiApp.paytm;
    } else if (upiapps == 'Bhim') {
      hiveApp = UpiApp.bhim;
    } else if (upiapps == 'upi') {}

    print(hiveApp?.name);
    var i;
    int isUpiApp = 0;
    for (i = 0; i < AllUpiapps?.length; i++) {
      print(AllUpiapps?[i].name);
      if (hiveApp?.packageName == AllUpiapps?[i].packageName) {
        print(AllUpiapps?[i].name);
        isUpiApp = 1;
      }
    }
    if (isUpiApp == 1) {
      print("App present");
      setState(() {
        isLoader = true;
      });
      upi(hiveApp);
    } else {
      print("not App present");
      setState(() {
        isAppPresent = true;
      });
    }
    return;
  }

  Future<String> upi(apppack) async {
    _upiIndia
        .startTransaction(
            app: apppack,
            receiverName: 'Dhiraj Dattatray Kadam',
            receiverUpiId: upiId,
            transactionRefId: 'IQR20220823',
            amount: (widget.amu > 99)
                ? double.parse((widget.amu - widget.amu * widget.dis / 100)
                        .toStringAsFixed(2)) +
                    1
                : double.parse((widget.amu - widget.amu * widget.dis / 100)
                    .toStringAsFixed(2)))
        .then((reponse) => {
              print(reponse),
              if (reponse.status == UpiPaymentStatus.SUCCESS)
                {
                  Payment(),
                }
              else if (reponse.status == UpiPaymentStatus.FAILURE)
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            Failed(amu: (widget.amu).toString()),
                      )),
                }
              else if (reponse.status == UpiPaymentStatus.SUBMITTED)
                {
                  PaymentPending(),
                }
              else
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            Failed(amu: (widget.amu).toString()),
                      )),
                }
            })
        .onError((error, stackTrace) => {
              if (error.runtimeType == UpiIndiaAppNotInstalledException)
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const UpiAppScreen(),
                      )),
                }
              else if (error.runtimeType == UpiIndiaUserCancelledException)
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            Failed(amu: (widget.amu).toString()),
                      )),
                }
              else if (error.runtimeType == UpiIndiaNullResponseException)
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            Failed(amu: (widget.amu).toString()),
                      )),
                }
              else if (error.runtimeType == UpiIndiaInvalidParametersException)
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            Failed(amu: (widget.amu).toString()),
                      )),
                }
              else
                {
                  setState(() {
                    isLoader = true;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            Failed(amu: (widget.amu).toString()),
                      )),
                }
            });

    return 'reponse';
  }

  Future PaymentPending() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/gateway/Payment.php?id=${authCred?.get('id')}&ordid=${ordid}&amu=${widget.amu}&dis=${(widget.amu - widget.amu * widget.dis / 100).toStringAsFixed(2)}&num=${widget.num.replaceAll(RegExp(r'[^0-9]'), '').substring((widget.num.replaceAll(RegExp(r'[^0-9]'), '')).toString().length - 10)}&opr=${widget.oprcode}&stat=Pending'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planData = json.decode(response.body);
        if (planData['success'] == "Y") {
          setState(() {
            isLoader = true;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    PaymentProccessing(amu: (widget.amu).toString()),
              ));
        } else {
          setState(() {
            isLoader = true;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    PaymentProccessing(amu: (widget.amu).toString()),
              ));
        }
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          isLoader = true;
        });
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  PaymentProccessing(amu: (widget.amu).toString()),
            ));
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        isInternet = true;
      });
    }
  }

  Future Payment() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/gateway/Payment.php?id=${authCred?.get('id')}&ordid=${ordid}&amu=${widget.amu}&dis=${(widget.amu - widget.amu * widget.dis / 100).toStringAsFixed(2)}&num=${widget.num.replaceAll(RegExp(r'[^0-9]'), '').substring((widget.num.replaceAll(RegExp(r'[^0-9]'), '')).toString().length - 10)}&opr=${widget.oprcode}&stat=Success'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planData = json.decode(response.body);
        if (planData['success'] == "Y") {
          setState(() {
            isLoader = true;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => Success(
                  amu: (widget.amu).toString(),
                  dis: (widget.amu * widget.dis / 100).toStringAsFixed(2),
                ),
              ));
        } else if (planData['success'] == "P") {
          setState(() {
            isLoader = true;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    RechargeProccessing(amu: (widget.amu).toString()),
              ));
        } else {
          setState(() {
            isLoader = true;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => Refund(amu: (widget.amu).toString()),
              ));
        }
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          isLoader = true;
        });
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => Refund(amu: (widget.amu).toString()),
            ));
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        isInternet = true;
      });
    }
  }

  Widget displayUpiApps() {
    if (AllUpiapps == null) {
      return Center(child: CircularProgressIndicator());
    } else if (AllUpiapps!.length == 0) {
      return const Center(
        child: Text(
          "No apps found to handle transaction.",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return Center(
        child: Wrap(
          children: AllUpiapps!.map<Widget>((UpiApp app) {
            if (app.name == "PhonePe") {
              return const Text('');
            } else {
              return GestureDetector(
                onTap: () {
                  upi(app);
                  setState(() {
                    isAppPresent = false;
                  });
                },
                child: Container(
                  height: 100,
                  width: 100,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.memory(
                        app.icon,
                        height: 40,
                        width: 40,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(app.name),
                      ),
                    ],
                  ),
                ),
              );
            }
          }).toList(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Color(0xff00CE19),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return DefaultTabController(
      length: 7,
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: 50,
                color: const Color(0xff00CE19),
              ),
              Container(
                alignment: Alignment.center,
                height: 50,
                child: Image(
                  image: const AssetImage("assets/Logo/LogoWhite.png"),
                  width: MediaQuery.of(context).size.width * 0.45,
                  height: 50,
                ),
              ),
              Container(
                  margin: const EdgeInsets.only(top: 50),
                  child: Column(children: [
                    Row(
                      children: [
                        Container(
                          margin: const EdgeInsets.only(
                              top: 30, bottom: 10, left: 40, right: 15),
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                color: const Color(0xff00CE19), width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image(
                              image: AssetImage(widget.ico),
                              width: 45,
                              height: 45,
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                margin:
                                    const EdgeInsets.only(top: 15, bottom: 10),
                                child: Text(
                                  widget.name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      color: Colors.black),
                                )),
                            Text(widget.num,
                                style: const TextStyle(
                                    fontSize: 13,
                                    color: Color.fromARGB(255, 100, 100, 100))),
                          ],
                        )
                      ],
                    ),
                    Container(
                      margin:
                          const EdgeInsets.only(top: 10, left: 40, right: 40),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.only(
                                top: 8, bottom: 8, left: 20, right: 20),
                            decoration: const BoxDecoration(
                                color: Color(0xffA7FFB2),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            child: const Text(
                              "Prepaid",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 12),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                                top: 8, bottom: 8, left: 20, right: 20),
                            decoration: const BoxDecoration(
                                color: Color(0xffA7FFB2),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            child: Text(
                              widget.opr,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                          color: Color.fromARGB(255, 235, 244, 255)),
                      padding: const EdgeInsets.only(top: 5, bottom: 10),
                      margin: const EdgeInsets.only(top: 20),
                      child: Row(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.75,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin:
                                      const EdgeInsets.only(left: 20, top: 20),
                                  child: Text(
                                    "Validity:${widget.val}",
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                        color: Colors.black),
                                  ),
                                ),
                                Container(
                                  margin:
                                      const EdgeInsets.only(left: 20, top: 5),
                                  child: Text(
                                    "Data:${widget.data}",
                                    style: const TextStyle(
                                        fontSize: 12,
                                        color: Color.fromARGB(255, 92, 92, 92)),
                                  ),
                                ),
                                Container(
                                    margin:
                                        const EdgeInsets.only(left: 20, top: 5),
                                    child: Text(
                                      widget.decs,
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color:
                                              Color.fromARGB(255, 92, 92, 92)),
                                    )),
                              ],
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.25,
                            height: 100,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Container(
                                  margin: EdgeInsets.only(bottom: 3),
                                  child: Text(
                                    "₹${widget.amu}",
                                    style: const TextStyle(
                                        fontSize: 18,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        decoration: TextDecoration.lineThrough,
                                        decorationColor: Color(0xff00CE19),
                                        decorationThickness: 3),
                                  ),
                                ),
                                Text(
                                  "₹${(widget.amu - widget.amu * widget.dis / 100).toStringAsFixed(2)}",
                                  style: const TextStyle(
                                    fontSize: 18,
                                    color: Color(0xff00CE19),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.25,
                                  margin: const EdgeInsets.only(top: 3),
                                  child: ClipPath(
                                    clipper: discountClip(),
                                    child: Container(
                                      padding: const EdgeInsets.only(
                                          top: 6,
                                          bottom: 6,
                                          left: 15,
                                          right: 5),
                                      color: const Color(0xff00CE19),
                                      child: Text(
                                        "₹${(widget.amu * widget.dis / 100).toStringAsFixed(2)} OFF",
                                        style: const TextStyle(
                                          fontSize: 10,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ])),
              Positioned(
                left: 0,
                bottom: 0,
                child: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height: 60,
                  child: TextButton(
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.resolveWith((state) {
                        if (state.contains(MaterialState.disabled)) {
                          return Colors.grey;
                        } else {
                          return Color(0xff00CE19);
                        }
                      }),
                    ),
                    onPressed: () {
                      checkApp();
                    },
                    child: const Text(
                      "Pay",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
              Visibility(
                visible: isError,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Color.fromARGB(117, 151, 151, 151),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height * 0.50,
                          decoration: const BoxDecoration(
                              color: Color.fromARGB(255, 251, 252, 255),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  topRight: Radius.circular(50)),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    spreadRadius: 3,
                                    blurRadius: 15,
                                    offset: Offset(0, 0))
                              ]),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Image(
                                  image: AssetImage("assets/Action/Error.webp"),
                                  width: 100,
                                  height: 100,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  child: Text(
                                    ErrorTxt,
                                    style: const TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ),
                                ),
                                const Text(
                                  "Something went wrong",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey),
                                ),
                                TextButton(
                                    onPressed: () {
                                      setState(() {
                                        isError = false;
                                        ErrorTxt = "Error";
                                        ordid = (99999999 +
                                            Random().nextInt(
                                                1000000000 - 99999999));
                                      });
                                      //initialPayment();
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10),
                                      padding: const EdgeInsets.only(
                                          top: 10,
                                          bottom: 10,
                                          left: 20,
                                          right: 20),
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: const Text(
                                        "Retry",
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ))
                              ]),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Visibility(
                visible: isError2,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Color.fromARGB(117, 151, 151, 151),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height * 0.50,
                          decoration: const BoxDecoration(
                              color: Color.fromARGB(255, 251, 252, 255),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  topRight: Radius.circular(50)),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    spreadRadius: 3,
                                    blurRadius: 15,
                                    offset: Offset(0, 0))
                              ]),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Image(
                                  image: AssetImage("assets/Action/Error.webp"),
                                  width: 100,
                                  height: 100,
                                ),
                                const Padding(
                                  padding: EdgeInsets.only(top: 10, bottom: 20),
                                  child: Text(
                                    "server under maintenance",
                                    style: TextStyle(
                                        fontSize: 23,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ),
                                ),
                                Text(
                                  ErrorTxt,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey),
                                ),
                                TextButton(
                                    onPressed: () {
                                      setState(() {
                                        isError2 = false;
                                        isLoader = true;
                                        ErrorTxt = "Error";
                                        ordid = (99999999 +
                                            Random().nextInt(
                                                1000000000 - 99999999));
                                      });
                                      //initialPayment();
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10),
                                      padding: const EdgeInsets.only(
                                          top: 10,
                                          bottom: 10,
                                          left: 20,
                                          right: 20),
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: const Text(
                                        "Retry",
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ))
                              ]),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Visibility(
                visible: isInternet,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Color.fromARGB(117, 151, 151, 151),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height * 0.50,
                          decoration: const BoxDecoration(
                              color: Color.fromARGB(255, 251, 252, 255),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  topRight: Radius.circular(50)),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    spreadRadius: 3,
                                    blurRadius: 15,
                                    offset: Offset(0, 0))
                              ]),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Image(
                                  image: AssetImage("assets/Action/Error.webp"),
                                  width: 100,
                                  height: 100,
                                ),
                                const Padding(
                                  padding: EdgeInsets.only(top: 10, bottom: 10),
                                  child: Text(
                                    "No Internet",
                                    style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ),
                                ),
                                const Text(
                                  "Something went wrong",
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey),
                                ),
                                TextButton(
                                    onPressed: () {
                                      setState(() {
                                        isInternet = false;
                                      });
                                      Navigator.of(context).pop();
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10),
                                      padding: const EdgeInsets.only(
                                          top: 10,
                                          bottom: 10,
                                          left: 20,
                                          right: 20),
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: const Text(
                                        "Back",
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ))
                              ]),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Visibility(
                visible: isLoader,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: const Color(0x4d0097A7),
                    child: const Center(child: CircularProgressIndicator()),
                  ),
                ),
              ),
              Visibility(
                visible: isAppPresent,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: const Color(0x4d0097A7),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                              color: Color.fromARGB(255, 251, 252, 255),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  topRight: Radius.circular(50)),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey,
                                    spreadRadius: 3,
                                    blurRadius: 15,
                                    offset: Offset(0, 0))
                              ]),
                          padding: EdgeInsets.only(top: 20),
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Text(
                                  "Select Payment App",
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              displayUpiApps(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class discountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}
