import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthNum.dart';
import 'PrepaidOperators.dart';
import 'UpiAppScreen.dart';

class DthOperators extends StatefulWidget {
  const DthOperators({super.key});

  @override
  State<DthOperators> createState() => _DthOperatorsState();
}

class _DthOperatorsState extends State<DthOperators> {
  late Box? AuthCred;
  late List str = [];
  late int len = 0;
  late int recents = 0;

  Widget recent() {
    if (str.isNotEmpty) {
      return Column(
        children: [
          Column(
              children: str.map((e) {
            if (e['type'] == 'dth' && recents == 0) {
              recents++;
              return Container(
                  width: MediaQuery.of(context).size.width,
                  margin: EdgeInsets.only(top: 20, bottom: 10),
                  padding: EdgeInsets.only(top: 10, bottom: 10, left: 20),
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Recent Recharges",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: Colors.black),
                  ));
            } else {
              return Text("");
            }
          }).toList()),
          Column(
              children: str.map((e) {
            if (e['type'] == "dth") {
              return Container(
                decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(
                        top: BorderSide(
                            width: 1,
                            color: Color.fromARGB(255, 209, 209, 209)),
                        bottom: BorderSide(
                            width: 1,
                            color: Color.fromARGB(255, 209, 209, 209)))),
                child: TextButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => DthAmu(
                            opr: e['opr'],
                            dis: e['dis'],
                            img: e['img'],
                            num: e['num'],
                            oprcode: e['opr_code'])));
                  },
                  child: Container(
                    margin: const EdgeInsets.only(
                        left: 30, right: 30, top: 3, bottom: 3),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: Image(
                                image: AssetImage(e['img']),
                                width: 35,
                                height: 35,
                              ),
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    child: Center(
                                        child: Text(
                                      e['name'],
                                      style: const TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ))),
                                Container(
                                    margin:
                                        const EdgeInsets.only(left: 15, top: 5),
                                    child: Center(
                                        child: Text(
                                      e['num'],
                                      style: const TextStyle(
                                          fontSize: 10, color: Colors.grey),
                                    ))),
                              ],
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.all(2),
                          child: const Image(
                            image: AssetImage("assets/Action/Next.png"),
                            width: 20,
                            height: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            } else {
              return const SizedBox(
                width: 0,
                height: 0,
              );
            }
          }).toList()),
        ],
      );
    } else {
      return Text("");
    }
  }

  @override
  void initState() {
    super.initState();
    createBox();
  }

  Future createBox() async {
    AuthCred = await Hive.openBox('AuthCred');
    print(AuthCred?.get('bills'));
    if (AuthCred?.get('bills') != null) {
      setState(() {
        str = AuthCred?.get('bills');
      });
    }
    if (AuthCred?.get('upi') == 'PhonePe') {
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (context) => const UpiAppScreen()));
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 50),
            color: Colors.white,
            child: ListView(
              children: [
                recent(),
                Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    alignment: Alignment.center,
                    child: Text(
                      "DTH Operators",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          color: Colors.black),
                    )),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(
                          top: BorderSide(
                              width: 1,
                              color: Color.fromARGB(255, 209, 209, 209)),
                          bottom: BorderSide(
                              width: 1,
                              color: Color.fromARGB(255, 209, 209, 209)))),
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => DthNum(
                              opr: 'Airtel Digital TV',
                              dis: 3,
                              img: 'assets/Prepaid/Airtel.png',
                              oprcode: 12)));
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                          left: 30, right: 30, top: 3, bottom: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: const Image(
                                  image:
                                      AssetImage("assets/Prepaid/Airtel.png"),
                                  width: 35,
                                  height: 35,
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(left: 15),
                                  child: const Center(
                                      child: Text(
                                    "Airtel Digital TV",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ))),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.all(2),
                            child: const Image(
                              image: AssetImage("assets/Action/Next.png"),
                              width: 20,
                              height: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(
                          bottom: BorderSide(
                              width: 1,
                              color: Color.fromARGB(255, 209, 209, 209)))),
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => DthNum(
                              opr: 'Dish TV',
                              dis: 3,
                              img: 'assets/DTH/Dish.png',
                              oprcode: 7)));
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                          left: 30, right: 30, top: 3, bottom: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: const Image(
                                  image: AssetImage("assets/DTH/Dish.png"),
                                  width: 35,
                                  height: 35,
                                ),
                              ),
                              Container(
                                  margin: const EdgeInsets.only(left: 15),
                                  child: const Center(
                                      child: Text(
                                    "Dish TV",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ))),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.all(2),
                            child: const Image(
                              image: AssetImage("assets/Action/Next.png"),
                              width: 20,
                              height: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(
                          bottom: BorderSide(
                              width: 1,
                              color: Color.fromARGB(255, 209, 209, 209)))),
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => DthNum(
                              opr: 'Sun TV',
                              dis: 3,
                              img: 'assets/DTH/Sun.jpg',
                              oprcode: 11)));
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                          left: 30, right: 30, top: 3, bottom: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: const Image(
                                  image: AssetImage("assets/DTH/Sun.jpg"),
                                  width: 35,
                                  height: 35,
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(left: 15),
                                  child: const Center(
                                      child: Text(
                                    "Sun TV",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ))),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.all(2),
                            child: const Image(
                              image: AssetImage("assets/Action/Next.png"),
                              width: 20,
                              height: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(
                          bottom: BorderSide(
                              width: 1,
                              color: Color.fromARGB(255, 209, 209, 209)))),
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => DthNum(
                              opr: 'Videocon D2H',
                              dis: 3,
                              img: 'assets/DTH/D2h.jpg',
                              oprcode: 10)));
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                          left: 30, right: 30, top: 3, bottom: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: const Image(
                                  image: AssetImage("assets/DTH/D2h.jpg"),
                                  width: 35,
                                  height: 35,
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(left: 15),
                                  child: const Center(
                                      child: Text(
                                    "Videocon D2H",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ))),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.all(2),
                            child: const Image(
                              image: AssetImage("assets/Action/Next.png"),
                              width: 20,
                              height: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(
                          bottom: BorderSide(
                              width: 1,
                              color: Color.fromARGB(255, 209, 209, 209)))),
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => DthNum(
                              opr: 'Tata Sky',
                              dis: 3,
                              img: 'assets/DTH/Tata.png',
                              oprcode: 8)));
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                          left: 30, right: 30, top: 3, bottom: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: const Image(
                                  image: AssetImage("assets/DTH/Tata.png"),
                                  width: 35,
                                  height: 35,
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(left: 15),
                                  child: const Center(
                                      child: Text(
                                    "Tata Sky",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                                  ))),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.all(2),
                            child: const Image(
                              image: AssetImage("assets/Action/Next.png"),
                              width: 20,
                              height: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Visibility(
            visible: false,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: Color(0x4d0097A7),
                child: Center(child: CircularProgressIndicator()),
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
