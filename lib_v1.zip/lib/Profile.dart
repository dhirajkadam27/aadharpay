import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'Biller.dart';
import 'CheckOldPin.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'SelectSplash.dart';
import 'Splash.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';
import 'UpiAppScreen.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  Box? authCred;

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');
    setState(() {});
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 50),
            color: Color.fromARGB(255, 230, 230, 230),
            child: ListView(
              children: [
                Container(
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top: 20, left: 20),
                        child: Text(
                          "Name",
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Color.fromARGB(255, 80, 80, 80)),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 5, left: 20),
                        child: Text(
                          (authCred?.get('name') == null)
                              ? 'Loading...'
                              : authCred?.get('name'),
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.black),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(top: 15, left: 20),
                        child: Text(
                          "Mobile Number",
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Color.fromARGB(255, 80, 80, 80)),
                        ),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 5, left: 20, bottom: 20),
                        child: Text(
                          (authCred?.get('num') == null)
                              ? 'Loading...'
                              : authCred?.get('num'),
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(top: 15),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => CheckOldPin()));
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 10, right: 50),
                            child: Text(
                              "Change the pin",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          )),
                      TextButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => UpiAppScreen()));
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 10, right: 50),
                            child: Text(
                              "Select UPI apps",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          )),
                      TextButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => const Biller()));
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 10, right: 50),
                            child: Text(
                              "Recent Bills",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          )),
                      TextButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => const SelectSplash()));
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 10, right: 50),
                            child: Text(
                              "Custom Splash Screen",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          )),
                      TextButton(
                          onPressed: () {
                            launchUrl(
                                Uri.parse(
                                    "https://mydukanpe.com/aadharpay/legal/privacypolicy.html"),
                                mode: LaunchMode.externalApplication);
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 10, right: 50),
                            child: Text(
                              "Privacy Policy",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          )),
                      TextButton(
                          onPressed: () {
                            authCred?.clear();
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => const Splash()));
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 10, right: 50),
                            child: Text(
                              "Logout",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          )),
                    ],
                  ),
                ),
                const SizedBox(width: 100, height: 50)
              ],
            ),
          ),
        ],
      ),
    ));
  }
}
