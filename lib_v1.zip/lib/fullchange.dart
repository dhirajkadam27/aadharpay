import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'DthNum.dart';
import 'PrepaidOperators.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';

class fullChange extends StatefulWidget {
  @override
  State<fullChange> createState() => _fullChangeState();
}

class _fullChangeState extends State<fullChange> {
  File? img;
  String? saved;

  Box? authCred;
  late Box AuthCred;

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    AuthCred = await Hive.openBox('AuthCred');
    authCred = await Hive.openBox('AuthCred').then((value) {
      if (value.get('splashImg') != null) {
        setState(() {
          this.saved = value.get('splashImg');
        });
      }
    });
    return;
  }

  Future pickImage() async {
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (image == null) return;
      final mainimg = await save(image.path);
      AuthCred.put('splashImg', mainimg.path);
      setState(() => this.saved = mainimg.path);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  Future save(String imgPath) async {
    final directory = await getApplicationDocumentsDirectory();
    final name = basename(imgPath);
    final Simg = File('${directory.path}/$name');
    return File(imgPath).copy(Simg.path);
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.only(top: 90),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      pickImage();
                    },
                    child: Container(
                        padding: EdgeInsets.all(10),
                        margin: EdgeInsets.only(bottom: 40),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color(0xff00CE19)),
                        child: Text(
                          'Change Image',
                          style: TextStyle(color: Colors.white),
                        )),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.50,
                    height: (MediaQuery.of(context).size.width * 0.50) * 2,
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: Colors.black, width: 3),
                          image: saved == null
                              ? DecorationImage(
                                  image: AssetImage(
                                      "assets/Action/fullscreen.jpg"),
                                  fit: BoxFit.cover)
                              : DecorationImage(
                                  image: new FileImage(File(saved!)),
                                  fit: BoxFit.cover)),
                      child: Stack(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Color.fromARGB(108, 255, 154, 154),
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(bottom: 60),
                            child: Center(
                              child: Image(
                                image: AssetImage("assets/Logo/Splash.png"),
                                width: 60,
                                height: 60,
                              ),
                            ),
                          ),
                          const Positioned(
                            bottom: -20,
                            left: 0,
                            right: 0,
                            child: Center(
                              child: Image(
                                image: AssetImage("assets/Action/Splash.png"),
                                width: 300,
                                height: 100,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ]),
          )
        ],
      ),
    ));
  }
}
