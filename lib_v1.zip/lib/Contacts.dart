import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'PrepaidPlans.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';
import 'package:flutter/cupertino.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:fast_contacts/fast_contacts.dart';
import 'package:permission_handler/permission_handler.dart';

class Contacts extends StatefulWidget {
  String opr;
  int dis;
  String img;
  int oprcode;
  Contacts(
      {super.key,
      required this.opr,
      required this.dis,
      required this.img,
      required this.oprcode});

  @override
  State<Contacts> createState() => _ContactsState();
}

class _ContactsState extends State<Contacts> {
  List<Contact> contacts = const [];
  List<Contact> contactlist = const [];
  List<Contact> contactssrc = const [];
  TextEditingController editingController = TextEditingController();

  var search;
  @override
  void initState() {
    super.initState();
    getContact();
  }

  void getContact() async {
    try {
      await Permission.contacts.request();
      contacts = await FastContacts.allContacts;
      contactlist = await FastContacts.allContacts;
      contactssrc = await FastContacts.allContacts;
      // print(contacts);
      setState(() {});
    } on PlatformException catch (e) {
      // _text = 'Failed to get contacts:\n${e.details}';
    }
  }

  void filterSearchResults(String query) {
    print(query);
    contactssrc.clear();
    contactlist.forEach((item) {
      print("5");
      if (item.displayName
              .toLowerCase()
              .toString()
              .contains(query.toLowerCase()) ||
          item.phones.toString().contains(query.toString())) {
        print("3");
        print(item);
        setState(() {
          contactssrc.add(item);
        });
      }
    });
    setState(() {
      contacts.clear();
      contacts.addAll(contactssrc);
    });
    //print(contacts);
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.03,
                height: MediaQuery.of(context).size.width * 0.05,
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.94,
                margin: const EdgeInsets.only(top: 60, bottom: 10),
                child: TextField(
                  onChanged: (value) {
                    filterSearchResults(value);
                  },
                  controller: editingController,
                  textAlignVertical: TextAlignVertical.center,
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.only(
                        top: 12, bottom: 12, left: 20, right: 20),
                    isCollapsed: true,
                    hintText: "Search your No. or name",
                    hintStyle: TextStyle(color: Colors.black),
                    filled: true,
                    fillColor: Color(0xffA7FFB2),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      borderSide: BorderSide(width: 0, color: Colors.white),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      borderSide: BorderSide(width: 0, color: Colors.white),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      borderSide: BorderSide(width: 0, color: Colors.white),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      borderSide: BorderSide(width: 0, color: Colors.white),
                    ),
                  ),
                  style: const TextStyle(fontSize: 17, color: Colors.black),
                ),
              ),
            ],
          ),
          Container(
            margin: const EdgeInsets.only(top: 120),
            color: Colors.white,
            child: (contacts) == null
                ? const Center(child: CircularProgressIndicator())
                : (contacts.length == 0)
                    ? ListTile(
                        leading: const CircleAvatar(
                            backgroundColor: Color(0xff00CE19),
                            child: Icon(
                              Icons.person,
                              color: Colors.white,
                            )),
                        title: Text("New Number"),
                        subtitle: Text(editingController.text),
                        onTap: () {
                          if (editingController.text.isNotEmpty) {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        PrepaidPlans(
                                            opr: widget.opr,
                                            dis: widget.dis,
                                            num: editingController.text,
                                            name: 'New Number',
                                            ico: widget.img,
                                            oprcode: widget.oprcode)));
                          }
                        })
                    : ListView.builder(
                        itemCount: contacts.length,
                        itemBuilder: (BuildContext context, int index) {
                          Future<Uint8List?> image =
                              FastContacts.getContactImage(contacts[0].id,
                                  size: ContactImageSize.fullSize);
                          String name = (contacts[index].displayName);
                          String num = (contacts[index].phones.isNotEmpty)
                              ? (contacts[index].phones.first).toString()
                              : "No. not found";

                          return ListTile(
                              leading: FutureBuilder<Uint8List?>(
                                future: image,
                                builder: (context, snapshot) => Container(
                                  child: snapshot.hasData
                                      ? CircleAvatar(
                                          child: Image.memory(snapshot.data!,
                                              gaplessPlayback: true),
                                        )
                                      : const CircleAvatar(
                                          backgroundColor: Color(0xff00CE19),
                                          child: Icon(
                                            Icons.person,
                                            color: Colors.white,
                                          )),
                                ),
                              ),
                              title: Text("${contacts[index].displayName}"),
                              subtitle: Text(num),
                              onTap: () {
                                if (contacts[index].phones.isNotEmpty) {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (context) => PrepaidPlans(
                                          opr: widget.opr,
                                          dis: widget.dis,
                                          num: num,
                                          name: name,
                                          ico: widget.img,
                                          oprcode: widget.oprcode)));
                                }
                              });
                        },
                      ),
          ),
        ],
      ),
    ));
  }
}
