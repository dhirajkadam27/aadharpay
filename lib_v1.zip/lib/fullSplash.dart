import 'dart:io';

import 'package:aadharpay/PaymentProccessing.dart';
import 'package:aadharpay/Refund.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'CheckPin.dart';
import 'MobileNumber.dart';
import 'Policy.dart';

class fullSplash extends StatefulWidget {
  const fullSplash({super.key});

  @override
  State<fullSplash> createState() => _fullSplashState();
}

class _fullSplashState extends State<fullSplash> {
  Box? authCred;
  String? saved;

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred').then((value) {
      if (value.get('splashImg') != null) {
        setState(() {
          this.saved = value.get('splashImg');
        });
      }
    });
    setState(() {});
    return;
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 2), () async {
      if (authCred?.get('tok') != null && authCred?.get('policy') != null) {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => CheckPin()));
      } else {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => Policy()));
      }
    });

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Container(
        decoration: BoxDecoration(
            image: saved == null
                ? DecorationImage(
                    image: AssetImage("assets/Action/fullscreen.jpg"),
                    fit: BoxFit.cover)
                : DecorationImage(
                    image: new FileImage(File(saved!)), fit: BoxFit.cover)),
        child: Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              color: Color.fromARGB(108, 255, 154, 154),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 100),
              child: Center(
                child: Image(
                  image: AssetImage("assets/Logo/Splash.png"),
                  width: 200,
                  height: 200,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Center(
                child: Image(
                  image: AssetImage("assets/Action/Splash.png"),
                  width: 300,
                  height: 100,
                ),
              ),
            )
          ],
        ),
      ),
    ));
  }
}
