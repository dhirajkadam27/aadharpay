import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

class Biller extends StatefulWidget {
  const Biller({super.key});

  @override
  State<Biller> createState() => _BillerState();
}

class _BillerState extends State<Biller> {
  late Box AuthCred;
  late List str = [];
  late int len = 0;

  @override
  void initState() {
    super.initState();
    createBox();
  }

  Future createBox() async {
    AuthCred = await Hive.openBox('AuthCred');
    //await AuthCred.delete('bills');
    // await AuthCred.put('bills', [
    //   {
    //     'num': '5',
    //     'name': 'Dish TV',
    //     'type': 'dth',
    //     'opr': 'Dish TV',
    //     'opr_code': '1',
    //     'dis': '3',
    //     'img': 'assets/DTH/D2h.jpg'
    //   },
    //   {
    //     'num': '7',
    //     'name': 'Dish TV',
    //     'type': 'dth',
    //     'opr': 'Dish TV',
    //     'opr_code': '1',
    //     'dis': '3',
    //     'img': 'assets/DTH/D2h.jpg'
    //   },
    //   {
    //     'num': '3',
    //     'name': 'Dish TV',
    //     'type': 'dth',
    //     'opr': 'Dish TV',
    //     'opr_code': '1',
    //     'dis': '3',
    //     'img': 'assets/DTH/D2h.jpg'
    //   }
    // ]);

    print(AuthCred.get('bills'));
    if (AuthCred.get('bills') != null) {
      setState(() {
        str = AuthCred.get('bills');
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 60),
            child: Column(
                children: str.map((e) {
              print(e['num']);
              return Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: (Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          margin:
                              EdgeInsets.only(left: 20, top: 20, bottom: 20),
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                color: const Color(0xff00CE19), width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image(
                              image: AssetImage("${e['img']}"),
                              width: 40,
                              height: 40,
                            ),
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.only(left: 15),
                            child: Center(
                                child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "${e['opr']}",
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Text(
                                    "${e['num']}",
                                    style: const TextStyle(
                                        fontSize: 12,
                                        color: Color.fromARGB(255, 68, 68, 68)),
                                  ),
                                ),
                              ],
                            ))),
                      ],
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          str.removeAt(len);
                        });
                        AuthCred.put('bills', str);
                      },
                      child: const Image(
                        image: AssetImage("assets/Action/close.jpg"),
                        width: 40,
                        height: 40,
                      ),
                    ),
                  ],
                )),
              );
              len++;
            }).toList()),
          ),
        ],
      ),
    ));
  }
}
