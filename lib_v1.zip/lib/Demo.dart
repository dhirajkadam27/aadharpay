import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';

class Demo extends StatefulWidget {
  @override
  _DemoState createState() => _DemoState();
}

class _DemoState extends State<Demo> {
  File? img;
  String? saved;

  Box? authCred;
  late Box AuthCred;

  @override
  void initState() {
    super.initState();
    openBox();
  }

  Future openBox() async {
    AuthCred = await Hive.openBox('AuthCred');
    authCred = await Hive.openBox('AuthCred').then((value) {
      if (value.get('splashImg') != null) {
        setState(() {
          this.saved = value.get('splashImg');
        });
      }
    });
    return;
  }

  Future pickImage() async {
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (image == null) return;
      final mainimg = await save(image.path);
      AuthCred.put('splashImg', mainimg);
      setState(() => this.saved = mainimg);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  Future save(String imgPath) async {
    final directory = await getApplicationDocumentsDirectory();
    final name = basename(imgPath);
    final Simg = File('${directory.path}/$name');
    return File(imgPath).copy(Simg.path);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text("Image Picker from Gallery"),
            backgroundColor: Colors.redAccent),
        body: Container(
          child: Column(children: [
            InkWell(
              onTap: () {
                pickImage();
              },
              child: Container(
                  padding: const EdgeInsets.all(10),
                  color: Colors.red,
                  child: const Text(
                    'Pick Image',
                    style: TextStyle(color: Colors.white),
                  )),
            ),
            saved == null
                ? Container(
                    width: 100,
                    height: 200,
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.black, width: 3),
                          image: DecorationImage(
                              image: AssetImage("assets/Action/fullscreen.jpg"),
                              fit: BoxFit.cover)),
                      child: Stack(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color.fromARGB(108, 255, 154, 154),
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(bottom: 60),
                            child: Center(
                              child: Image(
                                image: AssetImage("assets/Logo/Splash.png"),
                                width: 60,
                                height: 60,
                              ),
                            ),
                          ),
                          const Positioned(
                            bottom: -20,
                            left: 0,
                            right: 0,
                            child: Center(
                              child: Image(
                                image: AssetImage("assets/Action/Splash.png"),
                                width: 300,
                                height: 100,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                : SizedBox(
                    width: 100,
                    height: 200,
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.black, width: 3),
                          image: DecorationImage(
                              image: new FileImage(File(saved!)),
                              fit: BoxFit.cover)),
                      child: Stack(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color.fromARGB(108, 255, 255, 255),
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(bottom: 60),
                            child: Center(
                              child: Image(
                                image: AssetImage("assets/Logo/Splash.png"),
                                width: 60,
                                height: 60,
                              ),
                            ),
                          ),
                          const Positioned(
                            bottom: -20,
                            left: 0,
                            right: 0,
                            child: Center(
                              child: Image(
                                image: AssetImage("assets/Action/Splash.png"),
                                width: 300,
                                height: 100,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
          ]),
        ));
  }
}
