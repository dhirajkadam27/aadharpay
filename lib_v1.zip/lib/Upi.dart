import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:upi_india/upi_app.dart';
import 'package:upi_india/upi_india.dart';
import 'DthAmu.dart';
import 'DthOperators.dart';
import 'Failed.dart';
import 'Splash.dart';
import 'Success.dart';
import 'PrepaidOperators.dart';
import 'UpiAppScreen.dart';

class Upi extends StatefulWidget {
  const Upi({super.key});

  @override
  State<Upi> createState() => _UpiStatetate();
}

class _UpiStatetate extends State<Upi> {
  Box? authCred;
  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? AllUpiapps;
  UpiApp? hiveApp;
  bool isAppPresent = false;

  @override
  void initState() {
    super.initState();
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        AllUpiapps = value;
      });
    }).catchError((e) {
      AllUpiapps = [];
    });
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');
    return;
  }

  Future checkApp() async {
    var upiapps = await authCred?.get('upi');
    if (upiapps == 'PhonePe') {
      hiveApp = UpiApp.phonePe;
    } else if (upiapps == 'Gpay') {
      hiveApp = UpiApp.googlePay;
    } else if (upiapps == 'Paytm') {
      hiveApp = UpiApp.paytm;
    } else if (upiapps == 'upi') {
      hiveApp = UpiApp.paytm;
    }

    print(hiveApp?.name);
    var i;
    int isUpiApp = 0;
    for (i = 0; i < AllUpiapps?.length; i++) {
      print(AllUpiapps?[i].name);
      if (hiveApp?.packageName == AllUpiapps?[i].packageName) {
        print(AllUpiapps?[i].name);
        isUpiApp = 1;
      }
    }
    if (isUpiApp == 1) {
      print("App present");
      payment(hiveApp);
    } else {
      print("not App present");
      setState(() {
        isAppPresent = true;
      });
    }
    return;
  }

  String payment(data) {
    print("Data");
    print(data.name);
    return "success";
  }

  Widget displayUpiApps() {
    if (AllUpiapps == null) {
      return Center(child: CircularProgressIndicator());
    } else if (AllUpiapps!.length == 0) {
      return const Center(
        child: Text(
          "No apps found to handle transaction.",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return Center(
        child: Wrap(
          children: AllUpiapps!.map<Widget>((UpiApp app) {
            return GestureDetector(
              onTap: () {
                payment(app);
                setState(() {
                  isAppPresent = false;
                });
              },
              child: Container(
                height: 100,
                width: 100,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Image.memory(
                      app.icon,
                      height: 40,
                      width: 40,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Text(app.name),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff00CE19),
        systemNavigationBarColor: Colors.white,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 50,
            color: const Color(0xff00CE19),
          ),
          Container(
            alignment: Alignment.center,
            height: 50,
            child: Image(
              image: const AssetImage("assets/Logo/LogoWhite.png"),
              width: MediaQuery.of(context).size.width * 0.45,
              height: 50,
            ),
          ),
          Column(
            children: [
              TextButton(
                  onPressed: () {
                    checkApp();
                  },
                  child: Text("Press")),
            ],
          ),
          Visibility(
            visible: isAppPresent,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0x4d0097A7),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(
                          color: Color.fromARGB(255, 251, 252, 255),
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(50),
                              topRight: Radius.circular(50)),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey,
                                spreadRadius: 3,
                                blurRadius: 15,
                                offset: Offset(0, 0))
                          ]),
                      padding: EdgeInsets.only(top: 20),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(
                              "Select Payment App",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                          displayUpiApps(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
