import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui';

import 'package:aadharpay/RechargeProccessing.dart';

import 'PaymentProccessing.dart';
import 'UpiAppScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:upi_india/upi_india.dart';
import 'package:upi_india/upi_response.dart';
import 'Failed.dart';
import 'PrepaidOperators.dart';
import 'package:http/http.dart' as http;
import 'Refund.dart';
import 'Success.dart';
import 'package:upi_india/upi_app.dart';

class DthAmu extends StatefulWidget {
  String opr;
  int dis;
  String img;
  String num;
  int oprcode;
  DthAmu(
      {required this.opr,
      required this.dis,
      required this.img,
      required this.num,
      required this.oprcode});

  @override
  State<DthAmu> createState() => _DthAmuState();
}

class _DthAmuState extends State<DthAmu> {
  TextEditingController mycontroller = TextEditingController();
  TextEditingController mycontroller1 = TextEditingController();
  bool isErrorinitialPayment = false;
  bool isError2 = false;
  bool isErrorbillFetch = false;
  bool isErrorPayment = false;
  bool Paybtn = false;
  bool isDthOffer = false;
  bool isLoader = true;
  bool noBiller = false;
  bool isButtonActive = false;
  bool isBillerButtonActive = false;
  String ErrorTxt = "Error";
  String upiId = "";
  String vcNo = "";
  String name = "";
  String amu = "";
  int ordid = (99999999 + Random().nextInt(1000000000 - 99999999));
  Box? authCred;
  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? AllUpiapps;
  UpiApp? hiveApp;
  bool isAppPresent = false;

  late int i;
  late int check = 0;
  late List str = [];

  @override
  void initState() {
    super.initState();
    mycontroller.text = "";
    mycontroller1.text = "";
    mycontroller.addListener(() {
      print(mycontroller);
      if (mycontroller.text.length > 2) {
        setState(() {
          isButtonActive = true;
        });
      } else {
        setState(() {
          isButtonActive = false;
        });
      }
    });
    mycontroller1.addListener(() {
      print(mycontroller1);
      if (mycontroller1.text.length > 1) {
        setState(() {
          isBillerButtonActive = true;
          vcNo = "";
        });
      } else {
        setState(() {
          isBillerButtonActive = false;
          vcNo = "";
        });
      }
    });
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        AllUpiapps = value;
      });
    }).catchError((e) {
      AllUpiapps = [];
    });
    openBox();
  }

  Future openBox() async {
    authCred = await Hive.openBox('AuthCred');

    for (i = 0; i < str.length; i++) {
      if (str[i]['num'] == widget.num) {
        check++;
      }
    }
    if (check == 0) {
      setState(() {
        str.add({
          "num": widget.num,
          "name": widget.opr,
          "type": "dth",
          "opr": widget.opr,
          "opr_code": widget.oprcode,
          "dis": widget.dis,
          "img": widget.img
        });
      });
    }
    authCred?.put('bills', str);

    billFetch();
    return;
  }

  Future billFetch() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/plans/DTHBiller.php?vc=${widget.num}&opr=${widget.oprcode}'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planDataJson = json.decode(response.body);
        var planData = json.decode(planDataJson);
        print(planData['records'][0]);
        if (planData['records'][0]['customerName'] == null) {
          setState(() {
            isLoader = false;
            noBiller = true;
          });
        } else {
          setState(() {
            isLoader = false;
            name = planData.records[0].customerName;
            amu = planData.records[0].lastrechargeamount;
          });
        }
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          isLoader = false;
          ErrorTxt = "Error";
          isErrorbillFetch = true;
        });
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        isLoader = false;
        ErrorTxt = "No Internet";
        isErrorbillFetch = true;
      });
    }
  }

  Future checkApp() async {
    var upiapps = await authCred?.get('upi');
    if (upiapps == 'PhonePe') {
      hiveApp = UpiApp.phonePe;
    } else if (upiapps == 'Gpay') {
      hiveApp = UpiApp.googlePay;
    } else if (upiapps == 'Paytm') {
      hiveApp = UpiApp.paytm;
    } else if (upiapps == 'Bhim') {
      hiveApp = UpiApp.bhim;
    } else if (upiapps == 'upi') {}

    print(hiveApp?.name);
    var i;
    int isUpiApp = 0;
    for (i = 0; i < AllUpiapps?.length; i++) {
      print(AllUpiapps?[i].name);
      if (hiveApp?.packageName == AllUpiapps?[i].packageName) {
        print(AllUpiapps?[i].name);
        isUpiApp = 1;
      }
    }
    if (isUpiApp == 1) {
      print("App present");
      setState(() {
        isLoader = true;
      });
      upi(hiveApp);
    } else {
      print("not App present");
      setState(() {
        isAppPresent = true;
      });
    }
    return;
  }

  Future<String> upi(apppack) async {
    _upiIndia
        .startTransaction(
            app: apppack,
            receiverName: 'Dhiraj Dattatray Kadam',
            receiverUpiId: upiId,
            transactionRefId: 'IQR20220823',
            amount: (int.parse(mycontroller.text) > 99)
                ? double.parse((int.parse(mycontroller.text) -
                            int.parse(mycontroller.text) * widget.dis / 100)
                        .toStringAsFixed(2)) +
                    1
                : double.parse((int.parse(mycontroller.text) -
                        int.parse(mycontroller.text) * widget.dis / 100)
                    .toStringAsFixed(2)))
        .then((value) => {
              if (value.status == UpiPaymentStatus.SUCCESS)
                {
                  Payment(),
                }
              else if (value.status == UpiPaymentStatus.FAILURE)
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Failed(amu: mycontroller.text),
                      )),
                }
              else if (value.status == UpiPaymentStatus.SUBMITTED)
                {
                  PaymentPending(),
                }
              else
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Failed(amu: mycontroller.text),
                      )),
                }
            })
        .onError((error, stackTrace) => {
              if (error.runtimeType == UpiIndiaAppNotInstalledException)
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const UpiAppScreen(),
                      )),
                }
              else if (error.runtimeType == UpiIndiaUserCancelledException)
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Failed(amu: mycontroller.text),
                      )),
                }
              else if (error.runtimeType == UpiIndiaNullResponseException)
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Failed(amu: mycontroller.text),
                      )),
                }
              else if (error.runtimeType == UpiIndiaInvalidParametersException)
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Failed(amu: mycontroller.text),
                      )),
                }
              else
                {
                  setState(() {
                    isLoader = false;
                  }),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Failed(amu: mycontroller.text),
                      )),
                }
            });

    return 'reponse';
  }

  Future PaymentPending() async {
    print((int.parse(mycontroller.text) -
            int.parse(mycontroller.text) * widget.dis / 100)
        .toStringAsFixed(2));
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/gateway/Payment.php?id=${authCred?.get('id')}&ordid=${ordid}&amu=${mycontroller.text}&dis=${(int.parse(mycontroller.text) - int.parse(mycontroller.text) * widget.dis / 100).toStringAsFixed(2)}&num=${widget.num}&opr=${widget.oprcode}&stat=Pending&type=Prepaid Recharge'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planData = json.decode(response.body);
        if (planData['success'] == "Y") {
          setState(() {
            isLoader = false;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    PaymentProccessing(amu: mycontroller.text),
              ));
        } else {
          setState(() {
            isLoader = false;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    PaymentProccessing(amu: mycontroller.text),
              ));
        }
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          isLoader = false;
        });
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => PaymentProccessing(amu: mycontroller.text),
            ));
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        ErrorTxt = "No Internet";
        isLoader = false;
        isErrorPayment = true;
      });
    }
  }

  Future Payment() async {
    print((int.parse(mycontroller.text) -
            int.parse(mycontroller.text) * widget.dis / 100)
        .toStringAsFixed(2));
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/gateway/Payment.php?id=${authCred?.get('id')}&ordid=${ordid}&amu=${mycontroller.text}&dis=${(int.parse(mycontroller.text) - int.parse(mycontroller.text) * widget.dis / 100).toStringAsFixed(2)}&num=${widget.num}&opr=${widget.oprcode}&stat=Success&type=Prepaid Recharge'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planData = json.decode(response.body);
        if (planData['success'] == "Y") {
          setState(() {
            isLoader = false;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => Success(
                  amu: mycontroller.text,
                  dis: (int.parse(mycontroller.text) * widget.dis / 100)
                      .toStringAsFixed(2),
                ),
              ));
        } else if (planData['success'] == "P") {
          setState(() {
            isLoader = false;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    RechargeProccessing(amu: mycontroller.text),
              ));
        } else {
          setState(() {
            isLoader = false;
          });
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => Refund(amu: mycontroller.text),
              ));
        }
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          isLoader = false;
        });
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => Refund(amu: mycontroller.text),
            ));
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        ErrorTxt = "No Internet";
        isLoader = false;
        isErrorPayment = true;
      });
    }
  }

  Widget displayUpiApps() {
    if (AllUpiapps == null) {
      return Center(child: CircularProgressIndicator());
    } else if (AllUpiapps!.length == 0) {
      return const Center(
        child: Text(
          "No apps found to handle transaction.",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return Center(
        child: Wrap(
          children: AllUpiapps!.map<Widget>((UpiApp app) {
            if (app.name == "PhonePe") {
              return const Text('');
            } else {
              return GestureDetector(
                onTap: () {
                  upi(app);
                  setState(() {
                    isAppPresent = false;
                  });
                },
                child: Container(
                  height: 100,
                  width: 100,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.memory(
                        app.icon,
                        height: 40,
                        width: 40,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(app.name),
                      ),
                    ],
                  ),
                ),
              );
            }
          }).toList(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: const Color(0xff00CE19),
        systemNavigationBarColor:
            isButtonActive ? const Color(0xff00CE19) : Colors.grey,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: 50,
              color: const Color(0xff00CE19),
            ),
            Container(
              alignment: Alignment.center,
              height: 50,
              child: Image(
                image: const AssetImage("assets/Logo/LogoWhite.png"),
                width: MediaQuery.of(context).size.width * 0.45,
                height: 50,
              ),
            ),
            Container(
                margin: const EdgeInsets.only(top: 70, left: 20, right: 20),
                height: 210,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 180, 180, 180),
                        blurRadius: 18,
                        offset: Offset(0, 0),
                      )
                    ]),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          margin:
                              EdgeInsets.only(left: 20, top: 20, bottom: 20),
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                color: const Color(0xff00CE19), width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image(
                              image: AssetImage(widget.img),
                              width: 40,
                              height: 40,
                            ),
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.only(left: 15),
                            child: Center(
                                child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.opr,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Text(
                                    widget.num,
                                    style: const TextStyle(
                                        fontSize: 12,
                                        color: Color.fromARGB(255, 68, 68, 68)),
                                  ),
                                ),
                              ],
                            ))),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(left: 21, right: 21),
                      child: Column(children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Name:"),
                            Text(name.isEmpty ? 'Customer' : name),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10, bottom: 15),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("Amount:"),
                              Text(amu.isEmpty
                                  ? '₹.${mycontroller.text}'
                                  : '₹.$amu'),
                            ],
                          ),
                        ),
                      ]),
                    ),
                    Stack(children: [
                      Container(
                        margin: const EdgeInsets.only(left: 20, right: 20),
                        child: TextField(
                          controller: mycontroller,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            contentPadding: EdgeInsets.only(
                                top: 12, bottom: 12, left: 30, right: 20),
                            isCollapsed: true,
                            hintText: "100.00",
                            hintStyle: TextStyle(color: Colors.green),
                            filled: true,
                            fillColor: Color(0xffA7FFB2),
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              borderSide:
                                  BorderSide(width: 0, color: Colors.white),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              borderSide:
                                  BorderSide(width: 0, color: Colors.white),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              borderSide:
                                  BorderSide(width: 0, color: Colors.white),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              borderSide:
                                  BorderSide(width: 0, color: Colors.white),
                            ),
                          ),
                          style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              letterSpacing: 3),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 12, left: 35),
                        child: const Text("₹",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                      )
                    ]),
                  ],
                )),
            Positioned(
              left: 0,
              bottom: 0,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 60,
                child: TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.resolveWith((state) {
                      if (state.contains(MaterialState.disabled)) {
                        return Colors.grey;
                      } else {
                        return Color(0xff00CE19);
                      }
                    }),
                  ),
                  child: const Text(
                    "Proceed",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.white),
                  ),
                  onPressed: isButtonActive
                      ? () {
                          setState(() {
                            isDthOffer = true;
                          });
                        }
                      : null,
                ),
              ),
            ),
            Visibility(
              visible: isLoader,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: const Center(child: CircularProgressIndicator()),
                ),
              ),
            ),
            Visibility(
              visible: noBiller,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        padding: EdgeInsets.only(top: 20),
                        child: Column(children: [
                          Column(children: [
                            const Text(
                              "Re enter VC No.",
                              style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                            Text(
                              vcNo,
                              style: TextStyle(color: Colors.red),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(20),
                              child: TextField(
                                keyboardType: TextInputType.number,
                                controller: mycontroller1,
                                decoration: const InputDecoration(
                                  contentPadding: EdgeInsets.only(
                                      top: 15, bottom: 15, left: 15, right: 15),
                                  isCollapsed: true,
                                  hintText: "Enter your TV's VC no.",
                                  hintStyle: TextStyle(color: Colors.black),
                                  filled: true,
                                  fillColor: Color(0xffA7FFB2),
                                  border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(
                                        width: 0, color: Colors.white),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(
                                        width: 0, color: Colors.white),
                                  ),
                                  disabledBorder: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(
                                        width: 0, color: Colors.white),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(
                                        width: 0, color: Colors.white),
                                  ),
                                ),
                                style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black,
                                    letterSpacing: 3),
                              ),
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: 60,
                              child: TextButton(
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith(
                                          (state) {
                                    if (state
                                        .contains(MaterialState.disabled)) {
                                      return Colors.grey;
                                    } else {
                                      return Color(0xff00CE19);
                                    }
                                  }),
                                ),
                                onPressed: isBillerButtonActive
                                    ? () {
                                        if (widget.num == mycontroller1.text) {
                                          setState(() {
                                            noBiller = false;
                                          });
                                          //initialPayment();
                                        } else {
                                          setState(() {
                                            vcNo = "Incorrect VC number";
                                          });
                                        }
                                      }
                                    : null,
                                child: const Text(
                                  "Proceed",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: Colors.white),
                                ),
                              ),
                            ),
                          ])
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isErrorbillFetch,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Color.fromARGB(117, 151, 151, 151),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.50,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Image(
                                image: AssetImage("assets/Action/Error.webp"),
                                width: 100,
                                height: 100,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, bottom: 10),
                                child: Text(
                                  ErrorTxt,
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              const Text(
                                "Something went wrong",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey),
                              ),
                              TextButton(
                                  onPressed: () {
                                    setState(() {
                                      isErrorbillFetch = false;
                                      ErrorTxt = "Error";
                                      isLoader = true;
                                    });
                                    billFetch();
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    padding: const EdgeInsets.only(
                                        top: 10,
                                        bottom: 10,
                                        left: 20,
                                        right: 20),
                                    decoration: BoxDecoration(
                                        color: Colors.blueAccent,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: const Text(
                                      "Retry",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ))
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isErrorinitialPayment,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Color.fromARGB(117, 151, 151, 151),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.50,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Image(
                                image: AssetImage("assets/Action/Error.webp"),
                                width: 100,
                                height: 100,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, bottom: 10),
                                child: Text(
                                  ErrorTxt,
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              const Text(
                                "Something went wrong",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey),
                              ),
                              TextButton(
                                  onPressed: () {
                                    setState(() {
                                      isErrorinitialPayment = false;
                                      ErrorTxt = "Error";
                                      ordid = (99999999 +
                                          Random()
                                              .nextInt(1000000000 - 99999999));
                                      isLoader = true;
                                    });
                                    //initialPayment();
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    padding: const EdgeInsets.only(
                                        top: 10,
                                        bottom: 10,
                                        left: 20,
                                        right: 20),
                                    decoration: BoxDecoration(
                                        color: Colors.blueAccent,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: const Text(
                                      "Retry",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ))
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isErrorPayment,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Color.fromARGB(117, 151, 151, 151),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.50,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Image(
                                image: AssetImage("assets/Action/Error.webp"),
                                width: 100,
                                height: 100,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, bottom: 10),
                                child: Text(
                                  ErrorTxt,
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              const Text(
                                "Something went wrong",
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey),
                              ),
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    padding: const EdgeInsets.only(
                                        top: 10,
                                        bottom: 10,
                                        left: 20,
                                        right: 20),
                                    decoration: BoxDecoration(
                                        color: Colors.blueAccent,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: const Text(
                                      "Back",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ))
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isError2,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Color.fromARGB(117, 151, 151, 151),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.50,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Image(
                                image: AssetImage("assets/Action/Error.webp"),
                                width: 100,
                                height: 100,
                              ),
                              const Padding(
                                padding: EdgeInsets.only(top: 10, bottom: 20),
                                child: Text(
                                  "server under maintenance",
                                  style: TextStyle(
                                      fontSize: 23,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              Text(
                                ErrorTxt,
                                style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey),
                              ),
                              TextButton(
                                  onPressed: () {
                                    setState(() {
                                      isError2 = false;
                                      isLoader = true;
                                      ErrorTxt = "Error";
                                      ordid = (99999999 +
                                          Random()
                                              .nextInt(1000000000 - 99999999));
                                    });
                                    // initialPayment();
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    padding: const EdgeInsets.only(
                                        top: 10,
                                        bottom: 10,
                                        left: 20,
                                        right: 20),
                                    decoration: BoxDecoration(
                                        color: Colors.blueAccent,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: const Text(
                                      "Retry",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ))
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isAppPresent,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        padding: EdgeInsets.only(top: 20),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(
                                "Select Payment App",
                                style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                            displayUpiApps(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isDthOffer,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 251, 252, 255),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50)),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 3,
                                  blurRadius: 15,
                                  offset: Offset(0, 0))
                            ]),
                        padding: EdgeInsets.only(top: 20),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(
                                "Offer For You",
                                style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(bottom: 20, top: 10),
                              child: Text(
                                "₹${mycontroller.text}",
                                style: const TextStyle(
                                    fontSize: 25,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.lineThrough,
                                    decorationColor: Color(0xff00CE19),
                                    decorationThickness: 3),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(),
                              child: Text(
                                "₹${(mycontroller.text.isNotEmpty) ? (int.parse(mycontroller.text) - int.parse(mycontroller.text) * widget.dis / 100).toStringAsFixed(2) : ''}",
                                style: TextStyle(
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 20),
                              child: Container(
                                padding: const EdgeInsets.only(
                                    top: 5, bottom: 5, right: 15, left: 15),
                                decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  "You Saved ₹${(mycontroller.text.isNotEmpty) ? (int.parse(mycontroller.text) * widget.dis / 100).toStringAsFixed(2) : ''}",
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xff00CE19)),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: 60,
                              child: TextButton(
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith(
                                          (state) {
                                    if (state
                                        .contains(MaterialState.disabled)) {
                                      return Colors.grey;
                                    } else {
                                      return Color(0xff00CE19);
                                    }
                                  }),
                                ),
                                onPressed: () {
                                  setState(() {
                                    isLoader = true;
                                    isDthOffer = false;
                                  });
                                  checkApp();
                                },
                                child: const Text(
                                  "Proceed",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: Colors.white),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
