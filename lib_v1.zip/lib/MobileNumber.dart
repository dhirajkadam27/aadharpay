import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:aadharpay/Name.dart';
import 'package:aadharpay/Pin.dart';
import 'package:workmanager/workmanager.dart';
import 'dart:isolate';
import 'package:aadharpay/NotificationService.dart';

void main() async {
  runApp(const MobileNumber());
}

class MobileNumber extends StatefulWidget {
  const MobileNumber({super.key});

  @override
  State<MobileNumber> createState() => _MobileNumberState();
}

TextEditingController mycontroller = TextEditingController();
bool isButtonActive = false;
bool isLoader = false;
bool isError = false;
String ErrorTxt = "Error";

class _MobileNumberState extends State<MobileNumber> {
  Future fetchAlbum() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v2/login/checkUser.php?num=${mycontroller.text}'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planData = json.decode(response.body);
        await Workmanager().registerPeriodicTask(
            "task-identifier5", "simpleTask4",
            frequency: const Duration(hours: 12));
        if (planData['success'] == "Y") {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Pin(num: mycontroller.text),
              ));

          setState(() {
            isLoader = false;
          });
        } else if (planData['success'] == "N") {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Name(
                  num: mycontroller.text,
                ),
              ));
          setState(() {
            isLoader = false;
          });
        } else {
          setState(() {
            isLoader = false;
            ErrorTxt = "Error";
            isError = true;
          });
        }
        print("planData");
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        setState(() {
          isLoader = false;
          ErrorTxt = "Error";
          isError = true;
        });
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        isLoader = false;
        ErrorTxt = "No Internet";
        isError = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    mycontroller.text = "";
    mycontroller.addListener(() {
      print(mycontroller);
      if (mycontroller.text.length == 10) {
        setState(() {
          isButtonActive = true;
        });
      } else {
        setState(() {
          isButtonActive = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        systemNavigationBarColor:
            isButtonActive ? const Color(0xff00CE19) : Colors.grey,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light));
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            child: Container(
              margin: const EdgeInsets.only(top: 40),
              height: 80,
              alignment: Alignment.center,
              child: const Image(
                image: AssetImage("assets/Logo/LogoGreen.png"),
                width: 200,
                height: 70,
              ),
            ),
          ),
          Container(
              margin: const EdgeInsets.only(top: 150),
              // ignore: prefer_const_literals_to_create_immutables
              child: Container(
                margin: const EdgeInsets.only(left: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: const Text(
                        "Mobile Number",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      margin:
                          const EdgeInsets.only(top: 10, left: 5, bottom: 10),
                      child: Stack(children: [
                        Container(
                          child: TextField(
                            keyboardType: TextInputType.number,
                            maxLength: 10,
                            controller: mycontroller,
                            decoration: const InputDecoration(
                              contentPadding: EdgeInsets.only(
                                  top: 12, bottom: 12, left: 60, right: 20),
                              isCollapsed: true,
                              hintText: "0000000000",
                              hintStyle: TextStyle(color: Colors.black),
                              filled: true,
                              fillColor: Color(0xffA7FFB2),
                              border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                borderSide:
                                    BorderSide(width: 0, color: Colors.white),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                borderSide:
                                    BorderSide(width: 0, color: Colors.white),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                borderSide:
                                    BorderSide(width: 0, color: Colors.white),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                borderSide:
                                    BorderSide(width: 0, color: Colors.white),
                              ),
                            ),
                            style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                                letterSpacing: 3),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 12, left: 15),
                          child: const Text("+91",
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black)),
                        )
                      ]),
                    )
                  ],
                ),
              )),
          Positioned(
            left: 0,
            bottom: 0,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: 60,
              child: TextButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.resolveWith((state) {
                    if (state.contains(MaterialState.disabled)) {
                      return Colors.grey;
                    } else {
                      return Color(0xff00CE19);
                    }
                  }),
                ),
                onPressed: isButtonActive
                    ? () {
                        setState(() {
                          isLoader = true;
                        });
                        FocusScope.of(context).requestFocus(new FocusNode());
                        fetchAlbum();
                      }
                    : null,
                child: const Text(
                  "Proceed",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white),
                ),
              ),
            ),
          ),
          Visibility(
            visible: isLoader,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: Color.fromARGB(117, 255, 255, 255),
                child: const Center(
                    child: SizedBox(
                  width: 50,
                  height: 50,
                  child: CircularProgressIndicator(
                    strokeWidth: 6,
                    backgroundColor: Colors.black,
                    color: Color(0xff00CE19),
                  ),
                )),
              ),
            ),
          ),
          Visibility(
            visible: isError,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 2.0, sigmaY: 2.0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color.fromARGB(117, 151, 151, 151),
                child: Column(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.50,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.50,
                      decoration: const BoxDecoration(
                          color: Color.fromARGB(255, 251, 252, 255),
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(50),
                              topRight: Radius.circular(50)),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey,
                                spreadRadius: 3,
                                blurRadius: 15,
                                offset: Offset(0, 0))
                          ]),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Image(
                              image: AssetImage("assets/Action/Error.webp"),
                              width: 100,
                              height: 100,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              child: Text(
                                ErrorTxt,
                                style: const TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                            ),
                            const Text(
                              "Something went wrong",
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey),
                            ),
                            TextButton(
                                onPressed: () {
                                  setState(() {
                                    mycontroller.text = "";
                                    isError = false;
                                    ErrorTxt = "Error";
                                  });
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(top: 10),
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10, left: 20, right: 20),
                                  decoration: BoxDecoration(
                                      color: Colors.blueAccent,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: const Text(
                                    "Retry",
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ))
                          ]),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
