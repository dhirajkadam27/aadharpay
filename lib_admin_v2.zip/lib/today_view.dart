import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class TodayView extends StatefulWidget {
  const TodayView({super.key});

  @override
  State<TodayView> createState() => _TodayViewState();
}

class _TodayViewState extends State<TodayView> {
  @override
  void initState() {
    super.initState();
  }

  Future update(id, status) async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v3/Admin/Update/?stat=${status}&id=${id}'));

      if (response.statusCode == 200) {
        if (json.decode(response.body)['success'] == 'Y') {
          Navigator.pop(context);
        } else {
          showerror(context, "Something went wrong");
        }
      } else {
        showerror(context, "Something went wrong");
      }
    } on SocketException catch (_) {
      showerror(context, "Something went wrong");
    }
  }

  Future<List<List<String>>> fetchAlbum() async {
    try {
      final response = await http.get(
          Uri.parse('https://mydukanpe.com/aadharpay/api/v3/Admin/Today/'));

      if (response.statusCode == 200) {
        List<List<String>> planData = welcomeFromJson(response.body);
        return planData;
      } else {
        showerror(context, "Something went wrong");
        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      showerror(context, "Something went wrong");
      throw Exception('Something Went Wrong');
    }
  }

  List<List<String>> welcomeFromJson(String str) => List<List<String>>.from(
      json.decode(str).map((x) => List<String>.from(x.map((x) => x))));

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Color(0xff161616),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0xff161616),
                child: Stack(
                  children: [
                    Column(
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        FutureBuilder<List<List<String>>>(
                          future: fetchAlbum(),
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              if (snapshot.data!.isEmpty) {
                                return SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  height: 100,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: const [
                                      Text(
                                        "No Transactions Yet",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ],
                                  ),
                                );
                              } else {
                                return Expanded(
                                  child: ListView.builder(
                                    scrollDirection: Axis.vertical,
                                    itemCount: snapshot.data!.length,
                                    shrinkWrap: true,
                                    itemBuilder: (BuildContext context, index) {
                                      String status = snapshot.data![index][3];

                                      return Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.90,
                                          margin:
                                              const EdgeInsets.only(top: 10),
                                          padding: const EdgeInsets.all(10),
                                          color: int.parse(snapshot.data![index]
                                                      [4]) ==
                                                  0
                                              ? Colors.black
                                              : const Color(0xff00271E),
                                          child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    "₹${snapshot.data![index][0]} - ₹${snapshot.data![index][5]}",
                                                    style: const TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 20,
                                                        color:
                                                            Color(0xff00CE19)),
                                                  ),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: [
                                                      Text(
                                                        snapshot.data![index]
                                                            [1],
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize: 12,
                                                            color: Color(
                                                                0xff9E9E9E)),
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      Text(
                                                        snapshot.data![index]
                                                            [2],
                                                        style: const TextStyle(
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize: 12,
                                                            color: Color(
                                                                0xff9E9E9E)),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              Row(
                                                children: [
                                                  const Text(
                                                    "Status: ",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 12,
                                                        color:
                                                            Color(0xff9E9E9E)),
                                                  ),
                                                  Text(
                                                    snapshot.data![index][3],
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 12,
                                                        color: (status ==
                                                                "SUCCESS")
                                                            ? Color(0xff00CE19)
                                                            : Color.fromARGB(
                                                                255,
                                                                255,
                                                                68,
                                                                68)),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(
                                                height: 20,
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  InkWell(
                                                    onTap: () {
                                                      showloader(context);
                                                      update(
                                                          snapshot.data![index]
                                                              [6],
                                                          "s");

                                                      setState(() {
                                                        snapshot.data![index]
                                                            [4] = "1";
                                                      });
                                                    },
                                                    child: Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.15,
                                                      height: 30,
                                                      alignment:
                                                          Alignment.center,
                                                      decoration: BoxDecoration(
                                                          color: const Color(
                                                              0xff00CE19),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: const Text(
                                                        "S",
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 20,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ),
                                                  ),
                                                  InkWell(
                                                    onTap: () {
                                                      showloader(context);
                                                      update(
                                                          snapshot.data![index]
                                                              [6],
                                                          "f");

                                                      setState(() {
                                                        snapshot.data![index]
                                                            [4] = "1";
                                                      });
                                                    },
                                                    child: Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.15,
                                                      height: 30,
                                                      alignment:
                                                          Alignment.center,
                                                      decoration: BoxDecoration(
                                                          color: const Color(
                                                              0xffFF3939),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: const Text(
                                                        "F",
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 20,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ),
                                                  ),
                                                  InkWell(
                                                    onTap: () {
                                                      showloader(context);
                                                      update(
                                                          snapshot.data![index]
                                                              [6],
                                                          "p");

                                                      setState(() {
                                                        snapshot.data![index]
                                                            [4] = "1";
                                                      });
                                                    },
                                                    child: Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.15,
                                                      height: 30,
                                                      alignment:
                                                          Alignment.center,
                                                      decoration: BoxDecoration(
                                                          color: const Color(
                                                              0xffE76F00),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: const Text(
                                                        "P",
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 20,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ),
                                                  ),
                                                  InkWell(
                                                    onTap: () {
                                                      showloader(context);
                                                      update(
                                                          snapshot.data![index]
                                                              [6],
                                                          "r");

                                                      setState(() {
                                                        snapshot.data![index]
                                                            [4] = "1";
                                                      });
                                                    },
                                                    child: Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.15,
                                                      height: 30,
                                                      alignment:
                                                          Alignment.center,
                                                      decoration: BoxDecoration(
                                                          color: const Color(
                                                              0xff01AE7A),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: const Text(
                                                        "R",
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 20,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                            ],
                                          ));
                                    },
                                  ),
                                );
                              }
                            } else if (snapshot.hasError) {
                              return SizedBox(
                                width: MediaQuery.of(context).size.width,
                                height: 100,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: const [
                                    Text(
                                      "Something went wrong",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              );
                            }

                            // By default, show a loading spinner.
                            return SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: 100,
                              child: const Center(
                                  child: SizedBox(
                                width: 30,
                                height: 30,
                                child: CircularProgressIndicator(
                                  color: Color(0xff00CE19),
                                ),
                              )),
                            );
                          },
                        ),
                      ],
                    )
                  ],
                ))));
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            color: Color(0xff161616),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: const Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }

  showloader(context) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                )),
          );
        });
  }
}
