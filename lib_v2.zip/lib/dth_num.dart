import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:newaadharpay/dth_amu.dart';

import 'navigation.dart';

class DTHNum extends StatefulWidget {
  String opr;
  int dis = 1;
  String ico = "";
  DTHNum({super.key, required this.opr});

  @override
  State<DTHNum> createState() => _DTHNumState();
}

class _DTHNumState extends State<DTHNum> {
  TextEditingController mycontroller = TextEditingController();
  final user = Hive.box('User');
  bool theme = false;
  bool isButtonActive = false;

  @override
  void initState() {
    super.initState();
    mycontroller.text = "";
    mycontroller.addListener(() {
      print(mycontroller);
      if (int.parse(mycontroller.text) > 999) {
        setState(() {
          isButtonActive = true;
        });
      } else {
        setState(() {
          isButtonActive = false;
        });
      }
    });
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.opr == "Dish TV") {
      widget.dis = 3;
      widget.ico = "assets/DTH/Dish.png";
    } else if (widget.opr == "Airtel TV") {
      widget.dis = 3;
      widget.ico = "assets/Prepaid/Airtel.png";
    } else if (widget.opr == "Tata Play") {
      widget.dis = 3;
      widget.ico = "assets/DTH/Tata.png";
    } else if (widget.opr == "D2h") {
      widget.dis = 3;
      widget.ico = "assets/DTH/D2h.jpg";
    } else if (widget.opr == "Sun TV") {
      widget.dis = 3;
      widget.ico = "assets/DTH/Sun.jpg";
    } else {
      _showDialog(context);
    }
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return DefaultTabController(
      length: 7,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(
          children: [
            Column(
              children: [
                Container(
                    child: Column(
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.20,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Icon(
                                        Icons.keyboard_arrow_left,
                                        color: Color(0xff3491FF),
                                      ),
                                      Text(
                                        "back",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff3491FF),
                                            fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                alignment: Alignment.center,
                                child: Text(
                                  "TV",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 20),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.20,
                                child: Text(
                                  "",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 20),
                                ),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(
                                  left: 20, top: 20, bottom: 20),
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                border: Border.all(
                                    color: const Color(0xff00CE19), width: 2),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Image(
                                  image: AssetImage(widget.ico),
                                  width: 40,
                                  height: 40,
                                ),
                              ),
                            ),
                            Container(
                                margin: const EdgeInsets.only(left: 15),
                                child: Center(
                                    child: Text(
                                  widget.opr,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: theme ? Colors.white : Colors.black,
                                  ),
                                ))),
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.90,
                          height: 40,
                          padding: const EdgeInsets.only(left: 20, right: 10),
                          decoration: BoxDecoration(
                              color: theme ? Colors.black : Colors.white,
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? Colors.black
                                      : const Color(0xffD4D4D4)),
                              borderRadius: BorderRadius.circular(5)),
                          child: TextField(
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff737373),
                                  fontSize: 15),
                              keyboardType: TextInputType.number,
                              controller: mycontroller,
                              decoration: InputDecoration(
                                  isDense: true,
                                  hintStyle: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff737373),
                                      fontSize: 15),
                                  border: InputBorder.none,
                                  hintText: "Enter your TV No.")),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                )),
                const SizedBox(
                  height: 100,
                ),
              ],
            ),
            Positioned(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: isButtonActive
                        ? () {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (BuildContext context) => DTHAmu(
                                        opr: widget.opr,
                                        num: mycontroller.text)));
                          }
                        : null,
                    child: Container(
                      alignment: Alignment.center,
                      width: MediaQuery.of(context).size.width * 0.90,
                      decoration: BoxDecoration(
                          color: isButtonActive
                              ? const Color(0xff00CE19)
                              : const Color.fromARGB(255, 112, 112, 112),
                          borderRadius: BorderRadius.circular(5)),
                      height: 40,
                      child: Text(
                        "Continue",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: theme ? Colors.black : Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ))),
    );
  }
}

_showDialog(context) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: CupertinoAlertDialog(
              title: const Text("Opps"),
              content: const Text("Internet is not connected please check."),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: const Text("OK"),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        );
      });
}
