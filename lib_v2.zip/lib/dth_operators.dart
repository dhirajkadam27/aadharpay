import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:newaadharpay/dth_num.dart';

class DTHOperators extends StatefulWidget {
  const DTHOperators({super.key});

  @override
  State<DTHOperators> createState() => _DTHOperatorsState();
}

class _DTHOperatorsState extends State<DTHOperators> {
  final user = Hive.box('User');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return Scaffold(
        body: SafeArea(
            child: Container(
      color: theme ? const Color(0xff161616) : Colors.white,
      child: ListView(
        children: [
          Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.20,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.keyboard_arrow_left,
                              color: Color(0xff3491FF),
                            ),
                            Text(
                              "back",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xff3491FF),
                                  fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Text(
                        "TV",
                        style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color:
                                theme ? Colors.white : const Color(0xff282828),
                            fontSize: 20),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.20,
                      child: Text(
                        "",
                        style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color: theme ? Colors.white : Colors.black,
                            fontSize: 20),
                      ),
                    ),
                  ],
                ),
              )),
          const SizedBox(
            height: 20,
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => DTHNum(opr: "Dish TV")));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: BoxDecoration(
                color: theme ? const Color(0xff161616) : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: theme
                        ? const Color(0xff121212)
                        : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/DTH/Dish.png"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Dish Tv",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: theme ? Colors.white : Colors.black,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => DTHNum(opr: "Airtel TV")));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: BoxDecoration(
                color: theme ? const Color(0xff161616) : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: theme
                        ? const Color(0xff121212)
                        : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/Prepaid/Airtel.png"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Airtel Digital TV",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: theme ? Colors.white : Colors.black,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => DTHNum(opr: "Tata Play")));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: BoxDecoration(
                color: theme ? const Color(0xff161616) : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: theme
                        ? const Color(0xff121212)
                        : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/DTH/Tata.png"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "TATA Play(Sky)",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: theme ? Colors.white : Colors.black,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => DTHNum(opr: "D2h")));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: BoxDecoration(
                color: theme ? const Color(0xff161616) : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: theme
                        ? const Color(0xff121212)
                        : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/DTH/D2h.jpg"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "Videocon D2H",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: theme ? Colors.white : Colors.black,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => DTHNum(opr: "Sun TV")));
            },
            child: Container(
              padding: const EdgeInsets.only(
                  left: 15, right: 15, top: 10, bottom: 10),
              decoration: BoxDecoration(
                color: theme ? const Color(0xff161616) : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: theme
                        ? const Color(0xff121212)
                        : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: const Image(
                            image: AssetImage("assets/DTH/Sun.jpg"),
                            width: 40,
                            height: 40,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            "SUN TV",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: theme ? Colors.white : Colors.black,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ]),
            ),
          ),
          const SizedBox(
            height: 100,
          )
        ],
      ),
    )));
  }
}
