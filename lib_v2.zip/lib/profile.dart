import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:newaadharpay/upi_app.dart';
import 'package:url_launcher/url_launcher.dart';
import 'splash.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final user = Hive.box('User');
  bool theme = false;
  String name = "";
  String email = "";
  String photo = "";
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('user_name') != null) {
      setState(() {
        name = user.get('user_name');
      });
    }
    if (user.get('user_email') != null) {
      setState(() {
        email = user.get('user_email');
      });
    }
    print(user.get('user_photo'));
    if (user.get('user_photo') != null) {
      setState(() {
        photo = user.get('user_photo');
      });
    }
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return Scaffold(
        body: SafeArea(
            child: Container(
      color: theme ? const Color(0xff161616) : Colors.white,
      child: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 30, left: 20),
            child: Text(
              "Profile",
              style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: theme ? Colors.white : const Color(0xff282828),
                  fontSize: 30),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Container(
            padding:
                const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
            decoration: BoxDecoration(
              color: theme ? Colors.black : Colors.white,
              border: Border(
                top: BorderSide(
                  color:
                      theme ? const Color(0xff121212) : const Color(0xffF0F0F0),
                  width: 1.0,
                ),
                bottom: BorderSide(
                  color:
                      theme ? const Color(0xff121212) : const Color(0xffF0F0F0),
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: const Color(0xff00CE19),
                        ),
                        child: photo.isEmpty
                            ? Text(
                                name[0].toUpperCase(),
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold),
                              )
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Image.network(photo)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              name,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: theme ? Colors.white : Colors.black,
                                  fontSize: 13),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              email,
                              style: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  color: theme
                                      ? Color.fromARGB(255, 161, 161, 161)
                                      : Color.fromARGB(255, 63, 63, 63),
                                  fontSize: 13),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ]),
          ),
          Column(children: [
            Container(
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.only(top: 10),
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: theme ? Colors.black : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: theme ? Colors.black : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                  bottom: BorderSide(
                    color: theme ? Colors.black : const Color(0xffF0F0F0),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Dark",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: theme ? Colors.white : Colors.black,
                        fontSize: 14),
                  ),
                  Switch(
                    // thumb color (round icon)
                    activeColor: Color(0xff3491FF),
                    activeTrackColor: Color.fromARGB(255, 163, 204, 255),
                    inactiveThumbColor: Color.fromARGB(255, 255, 255, 255),
                    inactiveTrackColor: Color.fromARGB(255, 136, 136, 136),
                    splashRadius: 50.0,
                    // boolean variable value
                    value: theme,
                    // changes the state of the switch
                    onChanged: (value) {
                      if (value) {
                        user.put("theme", "dark");
                      } else {
                        user.put("theme", "light");
                      }
                      setState(() {
                        theme = value;
                      });
                    },
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const UpiApps()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.only(top: 10),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: theme ? Colors.black : Colors.white,
                  border: Border(
                    top: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                    bottom: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "UPI Apps",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: theme ? Colors.white : Colors.black,
                          fontSize: 14),
                    ),
                    const Icon(
                      Icons.keyboard_arrow_right_outlined,
                      color: Color(0xff3491FF),
                    )
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () {
                launchUrl(
                  Uri.parse(
                      "https://mydukanpe.com/aadharpay/legal/privacypolicy.html"),
                  mode: LaunchMode.externalApplication,
                );
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.only(top: 10),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: theme ? Colors.black : Colors.white,
                  border: Border(
                    top: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                    bottom: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Privacy Policy",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: theme ? Colors.white : Colors.black,
                          fontSize: 14),
                    ),
                    const Icon(
                      Icons.keyboard_arrow_right_outlined,
                      color: Color(0xff3491FF),
                    )
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () {
                user.delete("user");
                user.delete("user_id");
                user.delete("user_name");

                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => const Splash()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.only(top: 10),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: theme ? Colors.black : Colors.white,
                  border: Border(
                    top: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                    bottom: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Logout",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: theme ? Colors.white : Colors.black,
                          fontSize: 14),
                    ),
                    const Icon(
                      Icons.keyboard_arrow_right_outlined,
                      color: Color(0xff3491FF),
                    )
                  ],
                ),
              ),
            )
          ]),
          const SizedBox(
            height: 100,
          )
        ],
      ),
    )));
  }
}
