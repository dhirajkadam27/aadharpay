import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:newaadharpay/contact.dart';
import 'package:newaadharpay/dth_operators.dart';
import 'package:http/http.dart' as http;
import 'package:newaadharpay/reponse.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final user = Hive.box('User');
  bool theme = false;
  String name = "";
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('user_name') != null) {
      setState(() {
        name = user.get('user_name');
      });
    }
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future<List<List<String>>> fetchAlbum() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v3/recent_transactions/?id=${user.get('user_id')}'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List<List<String>> planData = welcomeFromJson(response.body);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        showerror(context, "Something went wrong");
        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      showerror(context, "Internet is not Connected");

      throw Exception('Something Went Wrong');
    }
  }

  List<List<String>> welcomeFromJson(String str) => List<List<String>>.from(
      json.decode(str).map((x) => List<String>.from(x.map((x) => x))));

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return Scaffold(
        body: SafeArea(
            child: Container(
      color: theme ? const Color(0xff161616) : Colors.white,
      child: ListView(
        children: [
          Row(
            children: const [
              Padding(
                padding: EdgeInsets.only(top: 10, left: 20),
                child: Image(
                  image: AssetImage("assets/light_logo.png"),
                  width: 200,
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20, left: 20),
            child: Text(
              "Welcome,",
              style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: theme ? Colors.white : const Color(0xff282828),
                  fontSize: 30),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 5, left: 20),
            child: Text(
              name,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: theme ? Colors.white : const Color(0xff5B5B5B),
                  fontSize: 15),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              InkWell(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (BuildContext context) => Contacts()));
                },
                child: Padding(
                  padding: const EdgeInsets.only(top: 20, bottom: 20),
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 40,
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1,
                            color: theme
                                ? const Color(0xff121212)
                                : const Color(0xffD7D7D7)),
                        borderRadius: BorderRadius.circular(10),
                        color: theme ? Colors.black : Colors.white),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 15, right: 10),
                          child: Icon(
                            Icons.search,
                            color: theme
                                ? const Color.fromARGB(255, 255, 255, 255)
                                : const Color(0xff383838),
                            size: 20,
                          ),
                        ),
                        Text(
                          "Search your contact",
                          style: TextStyle(
                            fontSize: 15,
                            color: theme
                                ? const Color.fromARGB(255, 255, 255, 255)
                                : const Color(0xff383838),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          Padding(
              padding: const EdgeInsets.only(top: 20, bottom: 10, left: 20),
              child: Text(
                "Payments",
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: theme ? Colors.white : const Color(0xff282828),
                    fontSize: 30),
              )),
          Column(children: [
            InkWell(
              onTap: () {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => Contacts()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: theme ? Colors.black : Colors.white,
                  border: Border(
                    top: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                    bottom: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.local_phone,
                          color: Color(0xff3491FF),
                          size: 20,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Mobile Recharge",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: theme ? Colors.white : Colors.black,
                              fontSize: 14),
                        ),
                      ],
                    ),
                    const Icon(
                      Icons.keyboard_arrow_right_outlined,
                      color: Color(0xff3491FF),
                    )
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const DTHOperators()));
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: theme ? Colors.black : Colors.white,
                  border: Border(
                    top: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                    bottom: BorderSide(
                      color: theme ? Colors.black : const Color(0xffF0F0F0),
                      width: 1.0,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.tv,
                          color: Color(0xff3491FF),
                          size: 20,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          "TV Recharge",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: theme ? Colors.white : Colors.black,
                              fontSize: 14),
                        ),
                      ],
                    ),
                    const Icon(
                      Icons.keyboard_arrow_right_outlined,
                      color: Color(0xff3491FF),
                    )
                  ],
                ),
              ),
            )
          ]),
          Padding(
              padding: const EdgeInsets.only(top: 30, bottom: 10, left: 20),
              child: Text(
                "Recent",
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: theme ? Colors.white : const Color(0xff282828),
                    fontSize: 30),
              )),
          FutureBuilder<List<List<String>>>(
            future: fetchAlbum(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.isEmpty) {
                  return SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: 100,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: const [
                        Text("No Transactions Yet"),
                      ],
                    ),
                  );
                } else {
                  return ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: snapshot.data!.length,
                    shrinkWrap: true,
                    reverse: true,
                    itemBuilder: (BuildContext context, index) {
                      return Recent(
                        theme: theme,
                        amount: snapshot.data![index][3],
                        date: snapshot.data![index][4],
                        number: snapshot.data![index][1],
                        time: snapshot.data![index][5],
                        tranid: snapshot.data![index][0],
                        type: snapshot.data![index][2],
                        status: snapshot.data![index][6],
                      );
                    },
                  );
                }
              } else if (snapshot.hasError) {
                return SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height: 100,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Text("Something went wrong"),
                    ],
                  ),
                );
              }

              // By default, show a loading spinner.
              return SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 100,
                child: const Center(
                    child: SizedBox(
                  width: 30,
                  height: 30,
                  child: CircularProgressIndicator(
                    color: Color(0xff00CE19),
                  ),
                )),
              );
            },
          ),
          const SizedBox(
            height: 100,
          )
        ],
      ),
    )));
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}

class Recent extends StatelessWidget {
  bool theme;
  String tranid;
  String number;
  String type;
  String amount;
  String date;
  String time;
  String status;
  Recent(
      {super.key,
      required this.theme,
      required this.tranid,
      required this.number,
      required this.type,
      required this.amount,
      required this.date,
      required this.time,
      required this.status});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => Reponses(
                  amu: double.parse(amount),
                  num: number,
                  status: status,
                  type: type,
                  date: date,
                  time: time,
                  tranid: tranid,
                )));
      },
      child: Container(
        padding:
            const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
        decoration: BoxDecoration(
          color: theme ? const Color(0xff161616) : Colors.white,
          border: Border(
            top: BorderSide(
              color: theme ? const Color(0xff121212) : const Color(0xffF0F0F0),
              width: 1.0,
            ),
          ),
        ),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: status == "SUCCESS"
                      ? const Color(0xff00CE19)
                      : status == "REFUNDED"
                          ? Color.fromARGB(255, 255, 203, 31)
                          : const Color(0xffFF5F5F),
                ),
                child: RotationTransition(
                    turns: status == "SUCCESS"
                        ? const AlwaysStoppedAnimation(130 / 360)
                        : const AlwaysStoppedAnimation(-45 / 360),
                    child: const Icon(
                      Icons.keyboard_backspace,
                      color: Colors.white,
                      size: 30,
                    )),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "$type Recharge",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: theme ? Colors.white : Colors.black,
                          fontSize: 12),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      number,
                      style: TextStyle(
                          fontWeight: FontWeight.w400,
                          color: theme
                              ? const Color.fromARGB(255, 161, 161, 161)
                              : const Color.fromARGB(255, 63, 63, 63),
                          fontSize: 12),
                    )
                  ],
                ),
              ),
            ],
          ),
          Text(
            "₹$amount",
            style: const TextStyle(
                fontSize: 18,
                color: Color(0xff00CE19),
                fontWeight: FontWeight.w900),
          )
        ]),
      ),
    );
  }
}
