import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:newaadharpay/dth_num.dart';

import 'navigation.dart';

class Reponses extends StatefulWidget {
  String type;
  String status;
  String num;
  double amu;
  String date;
  String time;
  String tranid;
  Reponses(
      {super.key,
      required this.type,
      required this.status,
      required this.num,
      required this.amu,
      required this.date,
      required this.time,
      required this.tranid});

  @override
  State<Reponses> createState() => _ReponsesState();
}

class _ReponsesState extends State<Reponses> {
  final user = Hive.box('User');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }

    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: widget.status == "SUCCESS"
            ? const Color(0xff00BF63)
            : widget.status == "REFUNDED"
                ? const Color.fromARGB(255, 255, 203, 31)
                : const Color(0xffFF5F5F),
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light));
    return Scaffold(
        body: SafeArea(
            child: Container(
                color: theme ? const Color(0xff161616) : Colors.white,
                child: Stack(
                  children: [
                    Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 140,
                          color: widget.status == "SUCCESS"
                              ? const Color(0xff00BF63)
                              : widget.status == "REFUNDED"
                                  ? Color.fromARGB(255, 255, 203, 31)
                                  : const Color(0xffFF5F5F),
                          child: Row(
                            children: [
                              const SizedBox(
                                width: 20,
                              ),
                              SizedBox(
                                width: 100,
                                height: 100,
                                child: Stack(children: [
                                  Center(
                                    child: Container(
                                      width: 100,
                                      height: 100,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          color: Colors.white.withOpacity(0.3)),
                                    ),
                                  ),
                                  Center(
                                    child: Container(
                                      width: 75,
                                      height: 75,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          color: Colors.white.withOpacity(0.6)),
                                    ),
                                  ),
                                  Center(
                                    child: Container(
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          color: Colors.white.withOpacity(1)),
                                      child: Icon(
                                        widget.status == "FAILED"
                                            ? Icons.close_rounded
                                            : widget.status == "PENDING"
                                                ? Icons.error_outline_rounded
                                                : widget.status == "No internet"
                                                    ? Icons
                                                        .error_outline_rounded
                                                    : Icons.done_rounded,
                                        size: 40,
                                        color: widget.status == "SUCCESS"
                                            ? const Color(0xff00BF63)
                                            : widget.status == "REFUNDED"
                                                ? const Color.fromARGB(
                                                    255, 255, 203, 31)
                                                : const Color(0xffFF5F5F),
                                      ),
                                    ),
                                  )
                                ]),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 20),
                                child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.status,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 25,
                                            color: Colors.white),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      SizedBox(
                                        width: 150,
                                        child: Text(
                                          widget.status == "FAILED"
                                              ? "If the recharge gets failed we will refund your money within 6 hours back."
                                              : widget.status == "PENDING"
                                                  ? "Your Recharge will be complete soon. If the recharge gets failed we will refund your money within 6 hours back."
                                                  : widget.status ==
                                                          "No internet"
                                                      ? "No internet"
                                                      : "Transaction Successful",
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 8,
                                              color: Colors.white),
                                        ),
                                      )
                                    ]),
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Column(
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.90,
                              child: Text(
                                "${widget.type} Recharge",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff5B5B5B),
                                ),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: theme
                                        ? const Color(0xff121212)
                                        : const Color(0xffF0F0F0),
                                    width: 1.0,
                                  ),
                                ),
                              ),
                              child: Text(
                                widget.num.toString(),
                                style: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 18,
                                  color: theme ? Colors.white : Colors.black,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  child: Text(
                                    "Transaction ID",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff5B5B5B),
                                    ),
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffF0F0F0),
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    widget.tranid,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  child: Text(
                                    "Amount",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff5B5B5B),
                                    ),
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffF0F0F0),
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    widget.amu.toString(),
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  child: Text(
                                    "Date",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff5B5B5B),
                                    ),
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffF0F0F0),
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    widget.date,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  child: Text(
                                    "Time",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff5B5B5B),
                                    ),
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.40,
                                  padding: const EdgeInsets.only(
                                      top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffF0F0F0),
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    widget.time,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Column(
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.90,
                              child: Text(
                                "Messege",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff5B5B5B),
                                ),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.90,
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: theme
                                        ? const Color(0xff121212)
                                        : const Color(0xffF0F0F0),
                                    width: 1.0,
                                  ),
                                ),
                              ),
                              child: Text(
                                widget.status == "FAILED"
                                    ? "If the recharge gets failed we will refund your money within 6 hours back."
                                    : widget.status == "PENDING"
                                        ? "Your Recharge will be complete soon. If the recharge gets failed we will refund your money within 6 hours back."
                                        : widget.status == "No internet"
                                            ? "No internet"
                                            : "Transaction Successful",
                                style: TextStyle(
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: theme ? Colors.white : Colors.black),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Positioned(
                      bottom: 30,
                      left: MediaQuery.of(context).size.width * 0.05,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          const Navigation()));
                            },
                            child: Container(
                              alignment: Alignment.center,
                              width: MediaQuery.of(context).size.width * 0.90,
                              decoration: BoxDecoration(
                                  color: const Color(0xff00CE19),
                                  borderRadius: BorderRadius.circular(5)),
                              height: 40,
                              child: Text(
                                "Go Home",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: theme ? Colors.black : Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ))));
  }
}
