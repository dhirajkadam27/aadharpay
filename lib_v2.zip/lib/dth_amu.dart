import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:upi_india/upi_india.dart';

import 'proccessing.dart';

class DTHAmu extends StatefulWidget {
  String opr;
  int dis = 1;
  String ico = "";
  String num;
  DTHAmu({super.key, required this.opr, required this.num});

  @override
  State<DTHAmu> createState() => _DTHAmuState();
}

class _DTHAmuState extends State<DTHAmu> {
  TextEditingController amountcontroller = TextEditingController();
  final user = Hive.box('User');
  bool theme = false;
  String name = "Customer";
  String amu = "";
  bool isButtonActive = false;
  TextEditingController reEnterController = TextEditingController();
  bool isReEnterButtonActive = false;
  bool reenter = false;
  bool loader = false;
  bool billfetch = false;
  double discountamount = 1000;
  bool isOffer = false;

  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? AllUpiapps;
  UpiApp? hiveApp;
  bool isAppPresent = false;

  late int i;
  late int check = 0;
  late List str = [];

  @override
  void initState() {
    super.initState();
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        AllUpiapps = value;
      });
    }).catchError((e) {
      AllUpiapps = [];
    });
    amountcontroller.text = "";
    amountcontroller.addListener(() {
      if (int.parse(amountcontroller.text) > 70) {
        discountamount = double.parse((int.parse(amountcontroller.text) -
                int.parse(amountcontroller.text) * widget.dis / 100)
            .toStringAsFixed(2));
        setState(() {
          isButtonActive = true;
        });
      } else {
        setState(() {
          isButtonActive = false;
        });
      }
    });
    reEnterController.text = "";
    reEnterController.addListener(() {
      print(reEnterController);
      if (int.parse(reEnterController.text) > 999) {
        print(reEnterController);
        setState(() {
          isReEnterButtonActive = true;
        });
      } else {
        setState(() {
          isReEnterButtonActive = false;
        });
      }
    });
    billFetch();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future checkApp() async {
    var upiapps = user.get('upi');
    if (upiapps == 'Gpay') {
      hiveApp = UpiApp.googlePay;
    } else if (upiapps == 'Paytm') {
      hiveApp = UpiApp.paytm;
    } else if (upiapps == 'Bhim') {
      hiveApp = UpiApp.bhim;
    } else if (upiapps == 'upi') {}

    print(hiveApp?.name);
    var i;
    int isUpiApp = 0;
    for (i = 0; i < AllUpiapps?.length; i++) {
      print(AllUpiapps?[i].name);
      if (hiveApp?.packageName == AllUpiapps?[i].packageName) {
        print(AllUpiapps?[i].name);
        isUpiApp = 1;
      }
    }
    if (isUpiApp == 1) {
      print("App present");
      setState(() {
        loader = true;
      });
      UPIFetch(hiveApp);
    } else {
      print("not App present");
      setState(() {
        isAppPresent = true;
      });
    }
    return;
  }

  Future billFetch() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v3/DTHBiller/?vc=${widget.num}&opr=${widget.opr}'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        var planDataJson = json.decode(response.body);
        var planData = json.decode(planDataJson);
        print(planData['records'][0]);
        if (planData['records'][0]['customerName'] == null) {
          showreenter(context);
          setState(() {
            billfetch = true;
          });
        } else {
          setState(() {
            billfetch = true;
            name = planData['records'][0]['customerName'];
            amu = planData['records'][0]['lastrechargeamount'];
          });
        }
        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        showerror(context, "Something went wrong");
        setState(() {
          billfetch = true;
        });
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      showerror(context, "Something went wrong");
      setState(() {
        billfetch = true;
      });
    }
  }

  Future UPIFetch(appid) async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/aadharpay/api/v3/upi_id'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          setState(() {
            loader = false;
          });
          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => Proccessing(
                    userid: user.get('user_id'),
                    type: 'Mobile',
                    amount: int.parse(amountcontroller.text),
                    discountamount: discountamount,
                    number: widget.num,
                    opr: widget.opr,
                    upiid: reponse['upi'],
                    upiAppID: appid,
                  )));
        } else if (reponse['success'] == "N") {
          setState(() {
            loader = false;
          });
          showerror(context, reponse['msg']);
        } else {
          setState(() {
            loader = false;
          });
          showerror(context, "Something went wrong");
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        setState(() {
          loader = false;
        });
        showerror(context, "Something went wrong");
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
      });
      showerror(context, "Interner is not Connected");
    }
  }

  Widget displayUpiApps() {
    if (AllUpiapps == null) {
      return Center(child: CircularProgressIndicator());
    } else if (AllUpiapps!.length == 0) {
      return const Center(
        child: Text(
          "No apps found to handle transaction.",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return Center(
        child: Wrap(
          children: AllUpiapps!.map<Widget>((UpiApp app) {
            if (app.name == "PhonePe") {
              return const Text('');
            } else {
              return GestureDetector(
                onTap: () {
                  // upi(app);
                  UPIFetch(app);
                  setState(() {
                    isAppPresent = false;
                  });
                },
                child: Container(
                  height: 100,
                  width: 100,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.memory(
                        app.icon,
                        height: 40,
                        width: 40,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          app.name,
                          style: TextStyle(
                            color:
                                theme ? Colors.white : const Color(0xff282828),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
          }).toList(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.opr == "Dish TV") {
      widget.dis = 3;
      widget.ico = "assets/DTH/Dish.png";
    } else if (widget.opr == "Airtel TV") {
      widget.dis = 3;
      widget.ico = "assets/Prepaid/Airtel.png";
    } else if (widget.opr == "Tata Play") {
      widget.dis = 3;
      widget.ico = "assets/DTH/Tata.png";
    } else if (widget.opr == "D2h") {
      widget.dis = 3;
      widget.ico = "assets/DTH/D2h.jpg";
    } else if (widget.opr == "Sun TV") {
      widget.dis = 3;
      widget.ico = "assets/DTH/Sun.jpg";
    } else {
      showerror(context, "Something went wrong");
    }
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return DefaultTabController(
      length: 7,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(
          children: [
            Column(
              children: [
                Container(
                    child: Column(
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.20,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Icon(
                                        Icons.keyboard_arrow_left,
                                        color: Color(0xff3491FF),
                                      ),
                                      Text(
                                        "back",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff3491FF),
                                            fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                alignment: Alignment.center,
                                child: Text(
                                  "TV",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 20),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.20,
                                child: Text(
                                  "",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 20),
                                ),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(
                                  left: 20, top: 20, bottom: 20),
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                border: Border.all(
                                    color: const Color(0xff00CE19), width: 2),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Image(
                                  image: AssetImage(widget.ico),
                                  width: 40,
                                  height: 40,
                                ),
                              ),
                            ),
                            Container(
                                margin: const EdgeInsets.only(left: 15),
                                child: Center(
                                    child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.opr,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color:
                                            theme ? Colors.white : Colors.black,
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      widget.num.toString(),
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: theme
                                            ? Colors.white
                                            : Color.fromARGB(255, 66, 66, 66),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Name : " + name,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: theme
                                            ? Colors.white
                                            : Color.fromARGB(255, 66, 66, 66),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      "Amount : " + amu,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: theme
                                            ? Colors.white
                                            : Color.fromARGB(255, 66, 66, 66),
                                      ),
                                    )
                                  ],
                                ))),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.90,
                          height: 40,
                          padding: const EdgeInsets.only(left: 20, right: 10),
                          decoration: BoxDecoration(
                              color: theme ? Colors.black : Colors.white,
                              border: Border.all(
                                  width: 1,
                                  color: theme
                                      ? Colors.black
                                      : const Color(0xffD4D4D4)),
                              borderRadius: BorderRadius.circular(5)),
                          child: TextField(
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff737373),
                                  fontSize: 15),
                              keyboardType: TextInputType.number,
                              controller: amountcontroller,
                              decoration: InputDecoration(
                                  isDense: true,
                                  hintStyle: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff737373),
                                      fontSize: 15),
                                  border: InputBorder.none,
                                  hintText: "Enter your Amu")),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                )),
                const SizedBox(
                  height: 100,
                ),
              ],
            ),
            Positioned(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: billfetch
                        ? isButtonActive
                            ? () {
                                setState(() {
                                  isOffer = true;
                                });
                              }
                            : null
                        : null,
                    child: Container(
                      alignment: Alignment.center,
                      width: MediaQuery.of(context).size.width * 0.90,
                      decoration: BoxDecoration(
                          color: isButtonActive
                              ? const Color(0xff00CE19)
                              : const Color.fromARGB(255, 112, 112, 112),
                          borderRadius: BorderRadius.circular(5)),
                      height: 40,
                      child: loader
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              "Continue",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: theme ? Colors.black : Colors.white),
                            ),
                    ),
                  ),
                ],
              ),
            ),
            Visibility(
              visible: isAppPresent,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0x4d0097A7),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: theme ? const Color(0xff161616) : Colors.white,
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(5),
                            topRight: Radius.circular(5)),
                      ),
                      padding: EdgeInsets.only(top: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8, left: 20),
                            child: Text(
                              "Select Payment App",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff282828),
                                  fontSize: 25),
                            ),
                          ),
                          displayUpiApps(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Visibility(
              visible: isOffer,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0x4d0097A7),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: theme ? const Color(0xff161616) : Colors.white,
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(5),
                            topRight: Radius.circular(5)),
                      ),
                      padding: EdgeInsets.only(top: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(bottom: 10, left: 20),
                            child: Text(
                              "Offers",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff282828),
                                  fontSize: 25),
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(bottom: 10, left: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Column(
                                  children: [
                                    Text(
                                      "₹${amountcontroller.text}",
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: theme
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                          decoration:
                                              TextDecoration.lineThrough,
                                          decorationColor:
                                              const Color(0xff00CE19),
                                          decorationThickness: 3),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      "Orignal Price",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color:
                                            theme ? Colors.white : Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text(
                                      "₹$discountamount",
                                      style: const TextStyle(
                                        fontSize: 25,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xff00CE19),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      "Aadharpay Price",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color:
                                            theme ? Colors.white : Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Center(
                            child: InkWell(
                              onTap: billfetch
                                  ? isButtonActive
                                      ? () {
                                          setState(() {
                                            loader = true;
                                            isOffer = false;
                                          });
                                          checkApp();
                                        }
                                      : null
                                  : null,
                              child: Container(
                                alignment: Alignment.center,
                                width: MediaQuery.of(context).size.width * 0.90,
                                decoration: BoxDecoration(
                                    color: isReEnterButtonActive
                                        ? const Color(0xff00CE19)
                                        : const Color.fromARGB(
                                            255, 112, 112, 112),
                                    borderRadius: BorderRadius.circular(5)),
                                height: 40,
                                child: Text(
                                  "Continue",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color:
                                          theme ? Colors.black : Colors.white),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ))),
    );
  }

  showreenter(context) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            return WillPopScope(
              onWillPop: () async => false,
              child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Re-enter",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Your VC No.",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              reenter
                                  ? const Padding(
                                      padding:
                                          EdgeInsets.only(bottom: 20, left: 20),
                                      child: Text(
                                        "Incorrect VC No.",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.red,
                                            fontSize: 10),
                                      ),
                                    )
                                  : const Padding(
                                      padding:
                                          EdgeInsets.only(bottom: 20, left: 20),
                                      child: Text(
                                        "",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.red,
                                            fontSize: 10),
                                      ),
                                    ),
                              Center(
                                child: Container(
                                  color: theme
                                      ? const Color(0xff161616)
                                      : Colors.white,
                                  padding: const EdgeInsets.only(bottom: 20),
                                  child: Container(
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    height: 40,
                                    padding: const EdgeInsets.only(
                                        left: 20, right: 10),
                                    decoration: BoxDecoration(
                                        color:
                                            theme ? Colors.black : Colors.white,
                                        border: Border.all(
                                            width: 1,
                                            color: theme
                                                ? Colors.black
                                                : const Color(0xffD4D4D4)),
                                        borderRadius: BorderRadius.circular(5)),
                                    child: TextField(
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: theme
                                                ? Colors.white
                                                : const Color(0xff737373),
                                            fontSize: 15),
                                        onChanged: ((value) {
                                          if (int.parse(value) > 999) {
                                            setState(() {
                                              isReEnterButtonActive = true;
                                            });
                                          } else {
                                            setState(() {
                                              isReEnterButtonActive = false;
                                            });
                                          }
                                        }),
                                        controller: reEnterController,
                                        decoration: InputDecoration(
                                            isDense: true,
                                            hintStyle: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: theme
                                                    ? Colors.white
                                                    : const Color(0xff737373),
                                                fontSize: 15),
                                            border: InputBorder.none,
                                            hintText: "Enter your VC No.")),
                                  ),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: isReEnterButtonActive
                                      ? () {
                                          if (widget.num ==
                                              reEnterController.text) {
                                            Navigator.pop(context);
                                          } else {
                                            setState(() {
                                              reEnterController.text = "";
                                              reenter = true;
                                            });
                                          }
                                        }
                                      : null,
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: isReEnterButtonActive
                                            ? const Color(0xff00CE19)
                                            : const Color.fromARGB(
                                                255, 112, 112, 112),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Continue",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                  padding: EdgeInsets.only(
                                      bottom: MediaQuery.of(context)
                                          .viewInsets
                                          .bottom))
                            ],
                          )),
                    ],
                  ),
                ),
              ),
            );
          });
        });
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
