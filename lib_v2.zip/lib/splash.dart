import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:newaadharpay/google.dart';
import 'package:newaadharpay/navigation.dart';
import 'package:newaadharpay/privacy.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  final user = Hive.box('User');
  bool theme = false;
  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 2), () async {
      if (user.get('user') == null) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const Privacy()));
      } else {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const Navigation()));
      }
    });
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: theme ? const Color(0xff161616) : Colors.white,
      statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
      statusBarBrightness: theme ? Brightness.light : Brightness.dark,
    ));
    return Scaffold(
        body: SafeArea(
            child: Container(
      color: theme ? const Color(0xff161616) : Colors.white,
      child: const Center(
        child: Image(
          image: AssetImage("assets/splash.png"),
          width: 200,
          height: 200,
        ),
      ),
    )));
  }
}
