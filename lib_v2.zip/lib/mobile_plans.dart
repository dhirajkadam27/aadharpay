import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:newaadharpay/mobile_plan_view.dart';

List<Album> albumFromJson(String str) =>
    List<Album>.from(json.decode(str).map((x) => Album.fromJson(x)));

class Album {
  Album({
    required this.type,
    required this.data,
  });

  String type;
  List<Datum> data;

  factory Album.fromJson(Map<String, dynamic> json) => Album(
        type: json["type"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "type": type,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    required this.rs,
    required this.decs,
    required this.val,
    required this.data,
    required this.sms,
  });

  int rs;
  String decs;
  String val;
  String data;
  String sms;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        rs: json["rs"],
        decs: json["decs"],
        val: json["val"],
        data: json["data"],
        sms: json["sms"],
      );

  Map<String, dynamic> toJson() => {
        "rs": rs,
        "decs": decs,
        "val": val,
        "data": data,
        "sms": sms,
      };
}

class MobilePlans extends StatefulWidget {
  String opr;
  int dis = 0;
  String num;
  String name = "";
  String ico = "";

  MobilePlans(
      {super.key, required this.num, required this.opr, required this.name});

  @override
  State<MobilePlans> createState() => _MobilePlansState();
}

class _MobilePlansState extends State<MobilePlans> {
  late Future<List<Album>> futureAlbum;
  final GlobalKey _widgetKey = GlobalKey();
  double height = 0;
  final user = Hive.box('User');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    futureAlbum = fetchAlbum();
    sync();
    WidgetsBinding.instance.addPostFrameCallback(_getWidgetInfo);
  }

  void _getWidgetInfo(_) {
    final RenderBox renderBox =
        _widgetKey.currentContext?.findRenderObject() as RenderBox;

    final Size size = renderBox.size; // or _widgetKey.currentContex

    setState(() {
      height = size.height;
    });
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future<List<Album>> fetchAlbum() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v3/Plans/${widget.opr}.json'));

      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        List<Album> planData = albumFromJson(response.body);
        return planData;
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        showerror(context);
        throw Exception('Something Went Wrong');
      }
    } on SocketException catch (_) {
      showerror(context);

      throw Exception('Something Went Wrong');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.opr == "Airtel") {
      widget.dis = 2;
      widget.ico = "assets/Prepaid/Airtel.png";
    } else if (widget.opr == "JIO") {
      widget.dis = 2;
      widget.ico = "assets/Prepaid/JIO.png";
    } else if (widget.opr == "VI") {
      widget.dis = 2;
      widget.ico = "assets/Prepaid/VI.png";
    } else if (widget.opr == "BSNL") {
      widget.dis = 3;
      widget.ico = "assets/Prepaid/BSNL.png";
    } else {
      showerror(context);
    }
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return DefaultTabController(
      length: 7,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: ListView(
          children: [
            Container(
                key: _widgetKey,
                child: Column(
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: SizedBox(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.20,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Icon(
                                        Icons.keyboard_arrow_left,
                                        color: Color(0xff3491FF),
                                      ),
                                      Text(
                                        "back",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff3491FF),
                                            fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                alignment: Alignment.center,
                                child: Text(
                                  "Mobile",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 20),
                                ),
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.20,
                                child: Text(
                                  "",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 20),
                                ),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: const EdgeInsets.only(
                                  top: 30, bottom: 10, left: 40, right: 15),
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                border: Border.all(
                                    color: const Color(0xff00CE19), width: 2),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Image(
                                  image: AssetImage(widget.ico),
                                  width: 40,
                                  height: 40,
                                ),
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    margin: const EdgeInsets.only(
                                        top: 15, bottom: 10),
                                    child: Text(
                                      widget.name,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                          color: theme
                                              ? Colors.white
                                              : Colors.black),
                                    )),
                                Text(widget.num,
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: theme
                                            ? const Color.fromARGB(
                                                255, 100, 100, 100)
                                            : Colors.black)),
                              ],
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          margin: const EdgeInsets.only(
                              top: 10, left: 40, right: 40),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.only(
                                    top: 8, bottom: 8, left: 20, right: 20),
                                decoration: BoxDecoration(
                                    color: theme ? Colors.black : Colors.white,
                                    border: Border.all(
                                        width: 1,
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffD7D7D7)),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(20))),
                                child: Text(
                                  "Prepaid",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 12),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.only(
                                    top: 8, bottom: 8, left: 20, right: 20),
                                decoration: BoxDecoration(
                                    color: theme ? Colors.black : Colors.white,
                                    border: Border.all(
                                        width: 1,
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffD7D7D7)),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(20))),
                                child: Text(
                                  widget.opr,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: TabBar(
                          indicatorWeight: 4,
                          indicatorColor: const Color(0xff00CE19),
                          isScrollable: true,
                          tabs: [
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 0),
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 1),
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 2),
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 3),
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 4),
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 5),
                            TitleTab(
                                futureAlbum: futureAlbum, theme: theme, i: 6),
                          ]),
                    ),
                  ],
                )),
            SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height - height - 30,
                child: TabBarView(children: [
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 0,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 1,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 2,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 3,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 4,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 5,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                  Tabs(
                    futureAlbum: futureAlbum,
                    theme: theme,
                    i: 6,
                    dis: widget.dis,
                    name: widget.name,
                    opr: widget.opr,
                    num: widget.num,
                  ),
                ])),
            const SizedBox(
              height: 100,
            )
          ],
        ),
      ))),
    );
  }

  showerror(context) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  "Something Went Wrong!",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}

class discountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}

class TitleTab extends StatelessWidget {
  Future<List<Album>> futureAlbum;
  bool theme;
  int i;
  TitleTab(
      {super.key,
      required this.futureAlbum,
      required this.theme,
      required this.i});

  @override
  Widget build(BuildContext context) {
    return Tab(
      child: FutureBuilder<List<Album>>(
        future: futureAlbum,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Text(
                i == 4
                    ? snapshot.data!.length > 4
                        ? snapshot.data![4].type
                        : 'Special Offers'
                    : i == 5
                        ? snapshot.data!.length > 5
                            ? snapshot.data![5].type
                            : 'Popular'
                        : i == 6
                            ? snapshot.data!.length > 6
                                ? snapshot.data![6].type
                                : 'Offers'
                            : snapshot.data![i].type,
                style: TextStyle(
                    color: theme ? Colors.white : Colors.black,
                    fontWeight: FontWeight.bold));
          } else if (snapshot.hasError) {
            return Text('${snapshot.error}',
                style: TextStyle(color: theme ? Colors.white : Colors.black));
          }
          return Text(".",
              style: TextStyle(color: theme ? Colors.white : Colors.black));
        },
      ),
    );
  }
}

class Tabs extends StatelessWidget {
  Future<List<Album>> futureAlbum;
  bool theme;
  int i;
  int dis;
  String name;
  String opr;
  String num;
  Tabs(
      {super.key,
      required this.futureAlbum,
      required this.theme,
      required this.i,
      required this.dis,
      required this.name,
      required this.opr,
      required this.num});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: FutureBuilder<List<Album>>(
        future: futureAlbum,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.length > i) {
              return ListView.builder(
                itemCount: snapshot.data![i].data.length,
                itemBuilder: (BuildContext context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => MobilePlansView(
                              name: name,
                              opr: opr,
                              num: num,
                              val: snapshot.data![i].data[index].val,
                              data: snapshot.data![i].data[index].data,
                              decs: snapshot.data![i].data[index].decs,
                              rs: snapshot.data![i].data[index].rs)));
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          color: theme ? const Color(0xff161616) : Colors.white,
                          border: Border(
                              bottom: BorderSide(
                            width: 1,
                            color: theme
                                ? const Color(0xff121212)
                                : const Color(0xffF0F0F0),
                          ))),
                      padding: const EdgeInsets.only(top: 5, bottom: 10),
                      child: Row(
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.75,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin:
                                      const EdgeInsets.only(left: 20, top: 20),
                                  child: Text(
                                    snapshot.data![i].data[index].val,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                        color: theme
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                                ),
                                Container(
                                  margin:
                                      const EdgeInsets.only(left: 20, top: 5),
                                  child: Text(
                                    snapshot.data![i].data[index].data,
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: theme
                                            ? const Color.fromARGB(
                                                255, 185, 185, 185)
                                            : const Color.fromARGB(
                                                255, 92, 92, 92)),
                                  ),
                                ),
                                Container(
                                    margin:
                                        const EdgeInsets.only(left: 20, top: 5),
                                    child: Text(
                                      snapshot.data![i].data[index].decs,
                                      maxLines: 2,
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: theme
                                              ? const Color.fromARGB(
                                                  255, 185, 185, 185)
                                              : const Color.fromARGB(
                                                  255, 92, 92, 92)),
                                    )),
                                TextButton(
                                    onPressed: () {},
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.black,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      margin: const EdgeInsets.only(
                                          left: 12, top: 5),
                                      padding: const EdgeInsets.only(
                                          top: 6,
                                          bottom: 6,
                                          left: 10,
                                          right: 10),
                                      child: const Text(
                                        "Show More",
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ))
                              ],
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.25,
                            height: 100,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(bottom: 3),
                                  child: Text(
                                    "₹${snapshot.data![i].data[index].rs}",
                                    style: TextStyle(
                                        fontSize: 18,
                                        color:
                                            theme ? Colors.white : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        decoration: TextDecoration.lineThrough,
                                        decorationColor:
                                            const Color(0xff00CE19),
                                        decorationThickness: 3),
                                  ),
                                ),
                                Text(
                                  "₹${(snapshot.data![i].data[index].rs - snapshot.data![i].data[index].rs * dis / 100).toStringAsFixed(2)}",
                                  style: const TextStyle(
                                    fontSize: 18,
                                    color: Color(0xff00CE19),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.25,
                                  margin: const EdgeInsets.only(top: 3),
                                  child: ClipPath(
                                    clipper: discountClip(),
                                    child: Container(
                                      padding: const EdgeInsets.only(
                                          top: 6,
                                          bottom: 6,
                                          left: 15,
                                          right: 5),
                                      color: const Color(0xff00CE19),
                                      child: Text(
                                        "₹${(snapshot.data![i].data[index].rs * dis / 100).toStringAsFixed(2)} OFF",
                                        style: const TextStyle(
                                          fontSize: 10,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                },
              );
            } else {
              return Text(
                "No plans found",
                style: TextStyle(color: theme ? Colors.white : Colors.black),
              );
            }
          } else if (snapshot.hasError) {
            return Text(
              '${snapshot.error}',
              style: TextStyle(color: theme ? Colors.white : Colors.black),
            );
          }

          // By default, show a loading spinner.
          return const CircularProgressIndicator();
        },
      ),
    );
  }
}
