import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:newaadharpay/dth_num.dart';
import 'package:url_launcher/url_launcher.dart';

class Updates extends StatefulWidget {
  const Updates({super.key});

  @override
  State<Updates> createState() => _UpdatesState();
}

class _UpdatesState extends State<Updates> {
  final user = Hive.box('User');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.20,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Text(
                                  "",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xff3491FF),
                                      fontSize: 13),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            child: Text(
                              "Alert",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff282828),
                                  fontSize: 20),
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.20,
                            child: Text(
                              "",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme ? Colors.white : Colors.black,
                                  fontSize: 20),
                            ),
                          ),
                        ],
                      ),
                    )),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20, left: 20),
                  child: Text(
                    "Update",
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: theme ? Colors.white : const Color(0xff282828),
                        fontSize: 30),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 5, left: 20),
                  child: Text(
                    "Apps Need To Be Update.",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: theme ? Colors.white : const Color(0xff5B5B5B),
                        fontSize: 15),
                  ),
                ),
                const SizedBox(
                  height: 100,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.system_security_update_outlined,
                      color: theme ? Colors.white : const Color(0xff5B5B5B),
                      size: 200,
                    )
                  ],
                )
              ],
            ),
            Positioned(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      launchUrl(
                        Uri.parse(
                            "https://play.google.com/store/apps/details?id=com.aadharpay.app"),
                        mode: LaunchMode.externalApplication,
                      );
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: MediaQuery.of(context).size.width * 0.90,
                      decoration: BoxDecoration(
                          color: const Color(0xff00CE19),
                          borderRadius: BorderRadius.circular(5)),
                      height: 40,
                      child: Text(
                        "Continue",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: theme ? Colors.black : Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ))),
    );
  }
}
