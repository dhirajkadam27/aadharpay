import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:newaadharpay/proccessing.dart';
import 'package:http/http.dart' as http;
import 'package:upi_india/upi_india.dart';

class MobilePlansView extends StatefulWidget {
  int dis = 0;
  String num;
  String name = "";
  String ico = "";
  String opr = "";
  String val = "";
  String data = "";
  String decs = "";
  int rs;

  MobilePlansView(
      {super.key,
      required this.num,
      required this.opr,
      required this.name,
      required this.val,
      required this.data,
      required this.decs,
      required this.rs});

  @override
  State<MobilePlansView> createState() => _MobilePlansViewState();
}

class _MobilePlansViewState extends State<MobilePlansView> {
  final user = Hive.box('User');
  bool theme = false;
  bool loader = false;

  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? AllUpiapps;
  UpiApp? hiveApp;
  bool isAppPresent = false;

  late int i;
  late int check = 0;
  late List str = [];

  @override
  void initState() {
    super.initState();
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        AllUpiapps = value;
      });
    }).catchError((e) {
      AllUpiapps = [];
    });
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future checkApp() async {
    var upiapps = user.get('upi');
    if (upiapps == 'Gpay') {
      hiveApp = UpiApp.googlePay;
    } else if (upiapps == 'Paytm') {
      hiveApp = UpiApp.paytm;
    } else if (upiapps == 'Bhim') {
      hiveApp = UpiApp.bhim;
    } else if (upiapps == 'upi') {}

    print(hiveApp?.name);
    var i;
    int isUpiApp = 0;
    for (i = 0; i < AllUpiapps?.length; i++) {
      print(AllUpiapps?[i].name);
      if (hiveApp?.packageName == AllUpiapps?[i].packageName) {
        print(AllUpiapps?[i].name);
        isUpiApp = 1;
      }
    }
    if (isUpiApp == 1) {
      print("App present");
      setState(() {
        loader = true;
      });
      billFetch(hiveApp);
    } else {
      print("not App present");
      setState(() {
        isAppPresent = true;
      });
    }
    return;
  }

  Future billFetch(appid) async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/aadharpay/api/v3/upi_id'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          setState(() {
            loader = false;
          });
          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => Proccessing(
                    userid: user.get('user_id'),
                    type: 'Mobile',
                    amount: widget.rs,
                    discountamount: double.parse(
                        (widget.rs - widget.rs * widget.dis / 100)
                            .toStringAsFixed(2)),
                    number: widget.num,
                    opr: widget.opr,
                    upiid: reponse['upi'],
                    upiAppID: appid,
                  )));
        } else if (reponse['success'] == "N") {
          setState(() {
            loader = false;
          });
          showerror(context, reponse['msg']);
        } else {
          setState(() {
            loader = false;
          });
          showerror(context, "Something went wrong");
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        setState(() {
          loader = false;
        });
        showerror(context, "Something went wrong");
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
      });
      showerror(context, "Interner is not Connected");
    }
  }

  Widget displayUpiApps() {
    if (AllUpiapps == null) {
      return Center(child: CircularProgressIndicator());
    } else if (AllUpiapps!.length == 0) {
      return const Center(
        child: Text(
          "No apps found to handle transaction.",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return Center(
        child: Wrap(
          children: AllUpiapps!.map<Widget>((UpiApp app) {
            if (app.name == "PhonePe") {
              return const Text('');
            } else {
              return GestureDetector(
                onTap: () {
                  // upi(app);
                  billFetch(app);
                  setState(() {
                    isAppPresent = false;
                  });
                },
                child: Container(
                  height: 100,
                  width: 100,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.memory(
                        app.icon,
                        height: 40,
                        width: 40,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          app.name,
                          style: TextStyle(
                            color:
                                theme ? Colors.white : const Color(0xff282828),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
          }).toList(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.opr == "Airtel") {
      widget.dis = 2;
      widget.ico = "assets/Prepaid/Airtel.png";
    } else if (widget.opr == "JIO") {
      widget.dis = 2;
      widget.ico = "assets/Prepaid/JIO.png";
    } else if (widget.opr == "VI") {
      widget.dis = 2;
      widget.ico = "assets/Prepaid/VI.png";
    } else if (widget.opr == "BSNL") {
      widget.dis = 3;
      widget.ico = "assets/Prepaid/BSNL.png";
    } else {
      _showDialog(context);
    }
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return DefaultTabController(
      length: 7,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(
          children: [
            Column(
              children: [
                SizedBox(
                    child: Column(
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: SizedBox(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.20,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Icon(
                                        Icons.keyboard_arrow_left,
                                        color: Color(0xff3491FF),
                                      ),
                                      Text(
                                        "back",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff3491FF),
                                            fontSize: 13),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                alignment: Alignment.center,
                                child: Text(
                                  "Mobile",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 20),
                                ),
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.20,
                                child: Text(
                                  "",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 20),
                                ),
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: const EdgeInsets.only(
                                  top: 30, bottom: 10, left: 40, right: 15),
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                border: Border.all(
                                    color: const Color(0xff00CE19), width: 2),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Image(
                                  image: AssetImage(widget.ico),
                                  width: 40,
                                  height: 40,
                                ),
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    margin: const EdgeInsets.only(
                                        top: 15, bottom: 10),
                                    child: Text(
                                      widget.name,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                          color: theme
                                              ? Colors.white
                                              : Colors.black),
                                    )),
                                Text(widget.num,
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: theme
                                            ? const Color.fromARGB(
                                                255, 100, 100, 100)
                                            : Colors.black)),
                              ],
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          margin: const EdgeInsets.only(
                              top: 10, left: 40, right: 40),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.only(
                                    top: 8, bottom: 8, left: 20, right: 20),
                                decoration: BoxDecoration(
                                    color: theme ? Colors.black : Colors.white,
                                    border: Border.all(
                                        width: 1,
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffD7D7D7)),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(20))),
                                child: Text(
                                  "Prepaid",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 12),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.only(
                                    top: 8, bottom: 8, left: 20, right: 20),
                                decoration: BoxDecoration(
                                    color: theme ? Colors.black : Colors.white,
                                    border: Border.all(
                                        width: 1,
                                        color: theme
                                            ? const Color(0xff121212)
                                            : const Color(0xffD7D7D7)),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(20))),
                                child: Text(
                                  widget.opr,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color:
                                          theme ? Colors.white : Colors.black,
                                      fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Tabs(
                      val: widget.val,
                      data: widget.data,
                      decs: widget.decs,
                      rs: widget.rs,
                      dis: widget.dis,
                      theme: theme,
                    )
                  ],
                )),
                const SizedBox(
                  height: 100,
                ),
              ],
            ),
            Positioned(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      setState(() {
                        loader = true;
                      });
                      checkApp();
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: MediaQuery.of(context).size.width * 0.90,
                      decoration: BoxDecoration(
                          color: const Color(0xff00CE19),
                          borderRadius: BorderRadius.circular(5)),
                      height: 40,
                      child: loader
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              "Continue",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: theme ? Colors.black : Colors.white),
                            ),
                    ),
                  ),
                ],
              ),
            ),
            Visibility(
              visible: isAppPresent,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: const Color(0x4d0097A7),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: theme ? const Color(0xff161616) : Colors.white,
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(5),
                            topRight: Radius.circular(5)),
                      ),
                      padding: EdgeInsets.only(top: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8, left: 20),
                            child: Text(
                              "Select Payment App",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff282828),
                                  fontSize: 25),
                            ),
                          ),
                          displayUpiApps(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ))),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}

class discountClip extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(10, size.height / 2);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}

class Tabs extends StatelessWidget {
  String val;
  bool theme;
  String data;
  String decs;
  int rs;
  int dis;
  Tabs(
      {super.key,
      required this.val,
      required this.theme,
      required this.data,
      required this.decs,
      required this.rs,
      required this.dis});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: theme ? Colors.black : Colors.white,
          border: Border(
              top: BorderSide(
                width: 1,
                color:
                    theme ? const Color(0xff121212) : const Color(0xffF0F0F0),
              ),
              bottom: BorderSide(
                width: 1,
                color:
                    theme ? const Color(0xff121212) : const Color(0xffF0F0F0),
              ))),
      padding: const EdgeInsets.only(top: 5, bottom: 10),
      child: Row(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.75,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 20, top: 20),
                  child: Text(
                    val,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        color: theme ? Colors.white : Colors.black),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(left: 20, top: 5),
                  child: Text(
                    data,
                    style: TextStyle(
                        fontSize: 12,
                        color: theme
                            ? const Color.fromARGB(255, 185, 185, 185)
                            : const Color.fromARGB(255, 92, 92, 92)),
                  ),
                ),
                Container(
                    margin: const EdgeInsets.only(left: 20, top: 5),
                    child: Text(
                      decs,
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 12,
                          color: theme
                              ? const Color.fromARGB(255, 185, 185, 185)
                              : const Color.fromARGB(255, 92, 92, 92)),
                    )),
              ],
            ),
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.25,
            height: 100,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    "₹$rs",
                    style: TextStyle(
                        fontSize: 18,
                        color: theme ? Colors.white : Colors.black,
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.lineThrough,
                        decorationColor: const Color(0xff00CE19),
                        decorationThickness: 3),
                  ),
                ),
                Text(
                  "₹${(rs - rs * dis / 100).toStringAsFixed(2)}",
                  style: const TextStyle(
                    fontSize: 18,
                    color: Color(0xff00CE19),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.25,
                  margin: const EdgeInsets.only(top: 3),
                  child: ClipPath(
                    clipper: discountClip(),
                    child: Container(
                      padding: const EdgeInsets.only(
                          top: 6, bottom: 6, left: 15, right: 5),
                      color: const Color(0xff00CE19),
                      child: Text(
                        "₹${(rs * dis / 100).toStringAsFixed(2)} OFF",
                        style: const TextStyle(
                          fontSize: 10,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

_showDialog(context) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: CupertinoAlertDialog(
              title: const Text("Opps"),
              content: const Text("Internet is not connected please check."),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: const Text("OK"),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        );
      });
}
