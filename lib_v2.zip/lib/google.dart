import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:newaadharpay/upi_app.dart';
import 'navigation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class Google extends StatefulWidget {
  const Google({super.key});

  @override
  State<Google> createState() => _GoogleState();
}

class _GoogleState extends State<Google> {
  TextEditingController nameController = TextEditingController();
  String email = "";
  String photo = "";
  final user = Hive.box('User');
  bool theme = false;
  bool loader = false;
  bool google_sign_completed = false;
  @override
  void initState() {
    super.initState();
    googleLogin();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }

    return;
  }

  Future billFetch() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v3/sigin/?name=${nameController.text}&email=${email}'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          setState(() {
            loader = false;
            nameController.text = "";
          });
          user.put("user", "Y");
          user.put("user_id", reponse['id']);
          user.put("user_name", reponse['name']);
          user.put("user_email", email);
          user.put("user_photo", photo);

          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => const UpiApps()));
        } else if (reponse['success'] == "F") {
          setState(() {
            loader = false;
            nameController.text = "";
          });
          showerror(context, reponse['msg']);
        } else if (reponse['success'] == "N") {
          setState(() {
            loader = false;
            nameController.text = "";
          });
          showerror(context, reponse['msg']);
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        setState(() {
          loader = false;
          nameController.text = "";
        });
        showerror(context, "Something went wrong");
        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {
      setState(() {
        loader = false;
        nameController.text = "";
      });
      showerror(context, "Interner is not Connected");
    }
  }

  googleLogin() async {
    print("googleLogin method Called");
    GoogleSignIn _googleSignIn = GoogleSignIn();
    try {
      var reslut = await _googleSignIn.signIn();
      if (reslut == null) {
        return;
      }

      final userData = await reslut.authentication;
      final credential = GoogleAuthProvider.credential(
          accessToken: userData.accessToken, idToken: userData.idToken);
      var finalResult =
          await FirebaseAuth.instance.signInWithCredential(credential);
      setState(() {
        google_sign_completed = true;
        email = reslut.email;
        photo = reslut.photoUrl!;
        nameController.text = reslut.displayName!;
      });
      if (reslut.displayName == null) {
        showerror(context, "Something went wrong");
      }
    } catch (error) {
      showerror(context, "Something went wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(children: [
          Positioned(
            top: 10,
            left: MediaQuery.of(context).size.width * 0.05,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Image(
                  image: AssetImage("assets/light_logo.png"),
                  width: 200,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20, bottom: 20),
                  child: Text(
                    "Sign In",
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: theme ? Colors.white : const Color(0xff282828),
                        fontSize: 30),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: 40,
                    padding: const EdgeInsets.only(left: 20, right: 10),
                    decoration: BoxDecoration(
                        color: theme ? Colors.black : Colors.white,
                        border: Border.all(
                            width: 1,
                            color:
                                theme ? Colors.black : const Color(0xffD4D4D4)),
                        borderRadius: BorderRadius.circular(5)),
                    child: TextField(
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color:
                                theme ? Colors.white : const Color(0xff737373),
                            fontSize: 15),
                        controller: nameController,
                        decoration: InputDecoration(
                            isDense: true,
                            hintStyle: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: theme
                                    ? Colors.white
                                    : const Color(0xff737373),
                                fontSize: 15),
                            border: InputBorder.none,
                            hintText: "Enter your Name")),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 30,
            left: MediaQuery.of(context).size.width * 0.05,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      loader = true;
                    });
                    billFetch();
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: MediaQuery.of(context).size.width * 0.90,
                    decoration: BoxDecoration(
                        color: const Color(0xff00CE19),
                        borderRadius: BorderRadius.circular(5)),
                    height: 40,
                    child: loader
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : Text(
                            "Continue",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: theme ? Colors.black : Colors.white),
                          ),
                  ),
                ),
              ],
            ),
          ),
          google_sign_completed
              ? Text("")
              : InkWell(
                  onTap: () {
                    googleLogin();
                  },
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Colors.black.withOpacity(0.2),
                    child: const Center(
                        child: SizedBox(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                        strokeWidth: 4,
                        color: Colors.white,
                      ),
                    )),
                  ),
                )
        ]),
      ))),
    );
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    googleLogin();
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
