import 'dart:convert';
import 'dart:io';
import 'package:intl/intl.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:newaadharpay/reponse.dart';
import 'package:newaadharpay/upi_app.dart';
import 'package:simple_ripple_animation/simple_ripple_animation.dart';
import 'package:upi_india/upi_india.dart';

class Proccessing extends StatefulWidget {
  String userid;
  String type;
  double discountamount;
  int amount;
  String number;
  String opr;
  String upiid;
  UpiApp upiAppID;
  Proccessing(
      {super.key,
      required this.userid,
      required this.type,
      required this.discountamount,
      required this.amount,
      required this.number,
      required this.opr,
      required this.upiid,
      required this.upiAppID});

  @override
  State<Proccessing> createState() => _ProccessingState();
}

class _ProccessingState extends State<Proccessing> {
  final user = Hive.box('User');
  bool theme = false;
  UpiIndia _upiIndia = UpiIndia();
  final now = DateTime.now();
  @override
  void initState() {
    super.initState();
    sync();
    widget.discountamount = (widget.discountamount > 99)
        ? (widget.discountamount + 1)
        : widget.discountamount;
    upi(widget.upiAppID);
    // billFetch();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future<String> upi(apppack) async {
    _upiIndia
        .startTransaction(
            app: apppack,
            receiverName: 'Dhiraj Dattatray Kadam',
            receiverUpiId: widget.upiid,
            transactionRefId: 'IQR20220823',
            amount: widget.discountamount)
        .then((value) => {
              if (value.status == UpiPaymentStatus.SUCCESS)
                {
                  print(widget.discountamount + 1),
                  billFetch(),
                }
              else if (value.status == UpiPaymentStatus.FAILURE)
                {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => Reponses(
                            amu: widget.discountamount,
                            num: widget.number,
                            status: "FAILED",
                            type: widget.type,
                            date:
                                DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            time: DateFormat('kk:mm').format(DateTime.now()),
                            tranid: "null",
                          ))),
                }
              else if (value.status == UpiPaymentStatus.SUBMITTED)
                {
                  PaymentPending(),
                }
              else
                {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => Reponses(
                            amu: widget.discountamount,
                            num: widget.number,
                            status: "FAILED",
                            type: widget.type,
                            date:
                                DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            time: DateFormat('kk:mm').format(DateTime.now()),
                            tranid: "null",
                          ))),
                }
            })
        .onError((error, stackTrace) => {
              if (error.runtimeType == UpiIndiaAppNotInstalledException)
                {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (BuildContext context) => const UpiApps())),
                }
              else if (error.runtimeType == UpiIndiaUserCancelledException)
                {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => Reponses(
                            amu: widget.discountamount,
                            num: widget.number,
                            status: "FAILED",
                            type: widget.type,
                            date:
                                DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            time: DateFormat('kk:mm').format(DateTime.now()),
                            tranid: "null",
                          ))),
                }
              else if (error.runtimeType == UpiIndiaNullResponseException)
                {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => Reponses(
                            amu: widget.discountamount,
                            num: widget.number,
                            status: "FAILED",
                            type: widget.type,
                            date:
                                DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            time: DateFormat('kk:mm').format(DateTime.now()),
                            tranid: "null",
                          ))),
                }
              else if (error.runtimeType == UpiIndiaInvalidParametersException)
                {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => Reponses(
                            amu: widget.discountamount,
                            num: widget.number,
                            status: "FAILED",
                            type: widget.type,
                            date:
                                DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            time: DateFormat('kk:mm').format(DateTime.now()),
                            tranid: "null",
                          ))),
                }
              else
                {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => Reponses(
                            amu: widget.discountamount,
                            num: widget.number,
                            status: "FAILED",
                            type: widget.type,
                            date:
                                DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            time: DateFormat('kk:mm').format(DateTime.now()),
                            tranid: "null",
                          ))),
                }
            });

    return 'reponse';
  }

  Future PaymentPending() async {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (BuildContext context) => Reponses(
              amu: widget.discountamount,
              num: widget.number,
              status: "PENDING",
              type: widget.type,
              date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
              time: DateFormat('kk:mm').format(DateTime.now()),
              tranid: "null",
            )));
  }

  Future billFetch() async {
    try {
      final fetch = await http.get(Uri.parse(
          'https://mydukanpe.com/aadharpay/api/v3/payment/?user_id=${widget.userid}&type=${widget.type}&amount=${widget.amount}&discount_amount=${widget.discountamount}&number=${widget.number}&opr=${widget.opr}'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['success'] == "Y") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Reponses(
                    amu: widget.discountamount,
                    num: widget.number,
                    status: "SUCCESS",
                    type: widget.type,
                    date: reponse['date'],
                    time: reponse['time'],
                    tranid: reponse['tranid'],
                  )));
        } else if (reponse['success'] == "F") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Reponses(
                    amu: widget.discountamount,
                    num: widget.number,
                    status: "FAILED",
                    type: widget.type,
                    date: reponse['date'],
                    time: reponse['time'],
                    tranid: reponse['tranid'],
                  )));
        } else if (reponse['success'] == "P") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Reponses(
                    amu: widget.discountamount,
                    num: widget.number,
                    status: "PENDING",
                    type: widget.type,
                    date: reponse['date'],
                    time: reponse['time'],
                    tranid: reponse['tranid'],
                  )));
        } else if (reponse['success'] == "N") {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => Reponses(
                    amu: widget.discountamount,
                    num: widget.number,
                    status: "No internet",
                    type: widget.type,
                    date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
                    time: DateFormat('kk:mm').format(DateTime.now()),
                    tranid: "null",
                  )));
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.
        showerror(context, "Something went wrong");
        //throw Exception('FAILED to load album');
      }
    } on SocketException catch (_) {
      showerror(context, "Interner is not Connected");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return Scaffold(
        body: SafeArea(
      child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(
          children: [
            Center(
              child: SizedBox(
                height: 200,
                width: 200,
                child: RippleAnimation(
                  repeat: true,
                  color: const Color(0xff00CE19),
                  minRadius: 100,
                  ripplesCount: 5,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Image(
                        width: 100,
                        height: 100,
                        image: AssetImage("assets/logo.png"),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Please Wait",
                    style: TextStyle(
                        fontWeight: FontWeight.w400,
                        color: theme ? Colors.white : const Color(0xff161616),
                        fontSize: 15),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Payment Proccessing",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: theme ? Colors.white : const Color(0xff161616),
                        fontSize: 20),
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ));
  }

  showerror(context, msg) {
    showDialog(
        barrierColor: Colors.white.withOpacity(0),
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Material(
                color: Colors.white.withOpacity(0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: const Color(0x4d0097A7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color:
                                theme ? const Color(0xff161616) : Colors.white,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                          ),
                          padding: const EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 5, left: 20),
                                child: Text(
                                  "Opps...",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 30),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 20, left: 20),
                                child: Text(
                                  msg,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: theme
                                          ? Colors.white
                                          : const Color(0xff282828),
                                      fontSize: 15),
                                ),
                              ),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: MediaQuery.of(context).size.width *
                                        0.90,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff00CE19),
                                        borderRadius: BorderRadius.circular(5)),
                                    height: 40,
                                    child: Text(
                                      "Okay",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: theme
                                              ? Colors.black
                                              : Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ],
                  ),
                )),
          );
        });
  }
}
