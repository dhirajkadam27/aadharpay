import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:newaadharpay/dth_num.dart';
import 'package:url_launcher/url_launcher.dart';

import 'google.dart';

class Privacy extends StatefulWidget {
  const Privacy({super.key});

  @override
  State<Privacy> createState() => _PrivacyState();
}

class _PrivacyState extends State<Privacy> {
  final user = Hive.box('User');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    FirebaseAuth.instance.authStateChanges().listen((User? user) async {
      if (user == null) {
        print('User is currently signed out!');
      } else {
        await GoogleSignIn().disconnect();
        FirebaseAuth.instance.signOut();
      }
    });
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          body: SafeArea(
              child: Container(
        color: theme ? const Color(0xff161616) : Colors.white,
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.20,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Text(
                                  "",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xff3491FF),
                                      fontSize: 13),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            child: Text(
                              "Legal",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme
                                      ? Colors.white
                                      : const Color(0xff282828),
                                  fontSize: 20),
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.20,
                            child: Text(
                              "",
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: theme ? Colors.white : Colors.black,
                                  fontSize: 20),
                            ),
                          ),
                        ],
                      ),
                    )),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20, left: 20),
                  child: Text(
                    "Privacy Policy",
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: theme ? Colors.white : const Color(0xff282828),
                        fontSize: 30),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 5, left: 20),
                  child: Text(
                    "Click on below link to read the privacy policy.",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: theme ? Colors.white : const Color(0xff5B5B5B),
                        fontSize: 13),
                  ),
                ),
                InkWell(
                  onTap: () {
                    launchUrl(
                      Uri.parse(
                          "https://mydukanpe.com/aadharpay/legal/privacypolicy.html"),
                      mode: LaunchMode.externalApplication,
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(top: 5, left: 20),
                    child: Text(
                      "Privacy Policy.",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 50, 115, 255),
                          fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 100,
                ),
              ],
            ),
            Positioned(
              bottom: 30,
              left: MediaQuery.of(context).size.width * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) => const Google()));
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: MediaQuery.of(context).size.width * 0.90,
                      decoration: BoxDecoration(
                          color: const Color(0xff00CE19),
                          borderRadius: BorderRadius.circular(5)),
                      height: 40,
                      child: Text(
                        "Agree and Continue",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: theme ? Colors.black : Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ))),
    );
  }
}
