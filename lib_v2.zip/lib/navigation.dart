import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:newaadharpay/history.dart';
import 'package:newaadharpay/home.dart';
import 'package:http/http.dart' as http;
import 'package:newaadharpay/update.dart';

import 'profile.dart';

class Navigation extends StatefulWidget {
  const Navigation({super.key});

  @override
  State<Navigation> createState() => _NavigationState();
}

class _NavigationState extends State<Navigation> {
  bool theme = false;
  int index = 0;
  final screens = const [Home(), History(), Profile()];

  final user = Hive.box('User');
  @override
  void initState() {
    super.initState();
    sync();
    UPIFetch();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  Future UPIFetch() async {
    try {
      final fetch = await http
          .get(Uri.parse('https://mydukanpe.com/aadharpay/api/v3/version/'));

      if (fetch.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.

        var reponse = json.decode(fetch.body);
        if (reponse['version'] == "1.00") {
          print("up to date");
        } else {
          print(" not up to date");
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => const Updates()));
        }

        return "Success";
      } else {
        // If the server did not return a 200 OK response,
        // then throw an exception.

        //throw Exception('Failed to load album');
      }
    } on SocketException catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return Scaffold(
        body: SafeArea(
            child: Stack(
      children: [
        screens[index],
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            child: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  color: theme
                      ? Colors.black.withOpacity(0.3)
                      : Colors.white.withOpacity(0.3),
                  padding: const EdgeInsets.only(top: 2, bottom: 2),
                  child: BottomNavigationBar(
                    elevation: 0, // to
                    selectedItemColor: const Color(0xff00CE19),
                    unselectedItemColor:
                        theme ? const Color(0xffFFFFFF) : Color(0xff383838),
                    unselectedLabelStyle: const TextStyle(
                        fontWeight: FontWeight.w400, fontSize: 10),
                    selectedLabelStyle: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 10),
                    selectedFontSize: 12,
                    backgroundColor: Colors.white.withOpacity(0.0),
                    type: BottomNavigationBarType.fixed,
                    currentIndex: index,
                    onTap: (index) => setState(() {
                      this.index = index;
                    }),
                    items: const [
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                            padding: EdgeInsets.only(bottom: 2),
                            child: Icon(Icons.home),
                          ),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.home_outlined)),
                          label: "Watchlist"),
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.article_rounded)),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.article_outlined)),
                          label: "History"),
                      BottomNavigationBarItem(
                          activeIcon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.account_circle)),
                          icon: Padding(
                              padding: EdgeInsets.only(bottom: 2),
                              child: Icon(Icons.account_circle_outlined)),
                          label: "Profile"),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    )));
  }
}
