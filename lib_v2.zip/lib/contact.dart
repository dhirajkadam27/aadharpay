import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:fast_contacts/fast_contacts.dart';
import 'package:newaadharpay/mobile_operator.dart';
import 'package:permission_handler/permission_handler.dart';

class Contacts extends StatefulWidget {
  const Contacts({super.key});

  @override
  State<Contacts> createState() => _ContactsState();
}

class _ContactsState extends State<Contacts> {
  List<Contact> contacts = const [];
  List<Contact> contactlist = const [];
  List<Contact> contactssrc = const [];
  TextEditingController editingController = TextEditingController();
  final user = Hive.box('User');
  bool theme = false;

  @override
  void initState() {
    super.initState();
    getContact();
    sync();
  }

  Future sync() async {
    if (user.get('theme') == "dark") {
      setState(() {
        theme = true;
      });
    }
    return;
  }

  void getContact() async {
    try {
      await Permission.contacts.request();
      contacts = await FastContacts.allContacts;
      contactlist = await FastContacts.allContacts;
      contactssrc = await FastContacts.allContacts;
      // print(contacts);
      setState(() {});
    } on PlatformException catch (e) {
      // _text = 'Failed to get contacts:\n${e.details}';
    }
  }

  void filterSearchResults(String query) {
    contactssrc.clear();
    for (var item in contactlist) {
      if (item.displayName
          .toLowerCase()
          .toString()
          .contains(query.toLowerCase())) {
        setState(() {
          contactssrc.add(item);
        });
      }
    }
    setState(() {
      contacts.clear();
      contacts.addAll(contactssrc);
    });
    //print(contacts);
    return;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: theme ? const Color(0xff161616) : Colors.white,
        statusBarIconBrightness: theme ? Brightness.light : Brightness.dark,
        statusBarBrightness: theme ? Brightness.light : Brightness.dark));
    return Scaffold(
        body: SafeArea(
            child: Container(
      color: theme ? const Color(0xff161616) : Colors.white,
      child: ListView(
        children: [
          Padding(
              padding: const EdgeInsets.only(top: 20),
              child: SizedBox(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width * 0.20,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(
                              Icons.keyboard_arrow_left,
                              color: Color(0xff3491FF),
                            ),
                            Text(
                              "back",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xff3491FF),
                                  fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Text(
                        "Contact",
                        style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color:
                                theme ? Colors.white : const Color(0xff282828),
                            fontSize: 20),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.20,
                      child: Text(
                        "",
                        style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color: theme ? Colors.white : Colors.black,
                            fontSize: 20),
                      ),
                    ),
                  ],
                ),
              )),
          const SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.90,
                height: 40,
                padding: const EdgeInsets.only(left: 20, right: 10),
                decoration: BoxDecoration(
                    color: theme ? Colors.black : Colors.white,
                    border: Border.all(
                        width: 1,
                        color: theme ? Colors.black : const Color(0xffD4D4D4)),
                    borderRadius: BorderRadius.circular(5)),
                child: TextField(
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: theme ? Colors.white : const Color(0xff737373),
                        fontSize: 15),
                    onChanged: (value) {
                      filterSearchResults(value);
                    },
                    controller: editingController,
                    decoration: InputDecoration(
                        isDense: true,
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color:
                                theme ? Colors.white : const Color(0xff737373),
                            fontSize: 15),
                        border: InputBorder.none,
                        hintText: "Enter your Name or Number")),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            color: theme ? const Color(0xff161616) : Colors.white,
            child: (contacts == null)
                ? const Center(child: CircularProgressIndicator())
                : (contacts.isEmpty)
                    ? ListTile(
                        leading: const CircleAvatar(
                            backgroundColor: Color(0xff00CE19),
                            child: Icon(
                              Icons.person,
                              color: Colors.white,
                            )),
                        title: Text(
                          "New Number",
                          style: TextStyle(
                            color: theme ? Colors.white : Colors.black,
                          ),
                        ),
                        subtitle: Text(
                          editingController.text,
                          style: TextStyle(
                            color: theme ? Colors.white : Colors.black,
                          ),
                        ),
                        onTap: () {
                          if (editingController.text.isNotEmpty) {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        MobileOperators(
                                            num: editingController.text,
                                            name: "New User")));
                          }
                        })
                    : ListView.builder(
                        itemCount: contacts.length,
                        itemBuilder: (BuildContext context, int index) {
                          Future<Uint8List?> image =
                              FastContacts.getContactImage(contacts[0].id,
                                  size: ContactImageSize.fullSize);
                          String num = (contacts[index].phones.isNotEmpty)
                              ? (contacts[index].phones.first.number).toString()
                              : "No. not found";

                          return ListTile(
                              leading: FutureBuilder<Uint8List?>(
                                future: image,
                                builder: (context, snapshot) => Container(
                                  child: snapshot.hasData
                                      ? CircleAvatar(
                                          child: Image.memory(snapshot.data!,
                                              gaplessPlayback: true),
                                        )
                                      : const CircleAvatar(
                                          backgroundColor: Color(0xff00CE19),
                                          child: Icon(
                                            Icons.person,
                                            color: Colors.white,
                                          )),
                                ),
                              ),
                              title: Text(
                                contacts[index].displayName,
                                style: TextStyle(
                                  color: theme ? Colors.white : Colors.black,
                                ),
                              ),
                              subtitle: Text(
                                num,
                                style: TextStyle(
                                  color: theme ? Colors.white : Colors.black,
                                ),
                              ),
                              onTap: () {
                                if (contacts[index].phones.isNotEmpty) {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (context) => MobileOperators(
                                          num: num,
                                          name: contacts[index].displayName)));
                                }
                              });
                        },
                      ),
          ),
          const SizedBox(
            height: 100,
          )
        ],
      ),
    )));
  }
}
